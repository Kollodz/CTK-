# Changelog — Ajustes solicitados

## ⚠️ Passos manuais no Supabase (obrigatórios)

Rode no **SQL Editor** do Supabase, nesta ordem, antes de testar:

1. `sql/004_discovery_gravacoes_storage.sql` — cria o bucket `discovery-gravacoes`
   e as políticas de acesso, e a coluna `gravacaoUrl` em `rpa_discovery`.
2. `sql/005_chamados.sql` — cria a tabela `rpa_chamados` (Help Desk) com RLS.
3. `sql/007_fix_status_historico_data.sql` — adiciona a coluna `data` que
   faltava em `rpa_status_historico` (ver item 5 abaixo).

Todos os scripts são idempotentes (podem rodar mais de uma vez sem problema).

---

## 5. Erro 400 ao salvar histórico de status (`rpa_status_historico`)

**Causa raiz:** `StatusHistory.log()` (`storage.js`) grava, para cada mudança
de status de projeto, um registro com os campos `projeto_id`,
`status_anterior`, `status_novo`, `data` e `usuario`. A tabela
`rpa_status_historico` no Supabase nunca teve a coluna `data` criada — só as
outras quatro existiam. O PostgREST rejeitava o insert inteiro com
`Could not find the 'data' column of 'rpa_status_historico' in the schema
cache`, e o console mostrava dois erros em cascata (o POST 400 e o aviso do
`Store` sem conseguir salvar).

**Correção:** `sql/007_fix_status_historico_data.sql` adiciona a coluna que
faltava (`data timestamptz`). Nenhum código em `storage.js` precisou mudar —
o problema era só a tabela estar desalinhada com o que o app sempre enviou.

---

## 6. Discovery: administrador, gestor e desenvolvedor sem editar/ver detalhes/excluir

**Causa raiz:** a listagem de ideias em `discovery.js` só tinha a ação
"Converter em Projeto" — não existia botão de ver detalhes, editar ou
excluir uma ideia enviada.

**Correção:** adicionada uma coluna "Ações" na tabela de ideias (visível para
Administrador, Gestor e Desenvolvedor — os mesmos três perfis que já tinham
permissão de edição no restante do sistema) com:
- 🔍 **Ver detalhes** — abre modal somente leitura com todos os campos do
  formulário de Discovery.
- ✏️ **Editar** — abre modal com os principais campos editáveis (nome da
  ideia, área, solicitante, status, volume, tempo médio, descrição e
  comentários) e salva no Supabase.
- 🗑️ **Excluir** — remove a ideia (com confirmação e registro em auditoria).

---

## 1. Cálculos zerados (Dashboard, Business Case, Priorização, Relatórios)

**Causa raiz:** a conversão de nomes de campo do Supabase (snake_case:
`horas_economizadas`, `execucoes_semana`...) para os nomes que `calc.js` usa
(camelCase: `horasPorExecucao`, `execucoesPorSemana`...) só existia dentro do
modal de detalhes (`projects.js → viewDetails`). Em todo o resto do sistema o
cálculo recebia os campos crus e `horasPorExecucao`/`execucoesPorSemana`
chegavam `undefined` → economia e ROI zerados.

**Correção:** a conversão agora acontece uma única vez, de forma central, em
`storage.js` (`Store._writeCache`), no momento em que os dados chegam do
Supabase. Qualquer tela que chame `Store.get('projects')` já recebe os dados
prontos para o `Calc`. Removida a duplicação em `projects.js`.

Também protegido: os campos "espelho" camelCase nunca são reenviados ao
Supabase (só os campos snake_case reais das colunas) — evita erro de "coluna
não existe" ao salvar/editar um projeto.

**Bug relacionado encontrado e corrigido:** `discovery.js → convertToProject()`
criava projetos usando só os nomes camelCase, então todo projeto nascido de
uma ideia do Discovery salvava a economia **vazia** no banco (o problema que
você reportou, só que pela porta de entrada do Discovery). Agora usa as
mesmas colunas snake_case que o formulário de Projetos usa.

## 2. Gravação de tela no Discovery

Adicionado um bloco no topo do wizard (visível em todas as etapas) com botão
"🎥 Gravar tela do processo". Usa a API nativa do navegador
(`getDisplayMedia` + `MediaRecorder`), sem dependências externas. Ao parar a
gravação, o vídeo é enviado automaticamente para o Supabase Storage (bucket
`discovery-gravacoes`) e a URL fica anexada ao registro da ideia — aparece
como link "▶ Ver" na listagem de ideias.

Requer HTTPS (ou `localhost`) para funcionar — é uma exigência do navegador
para `getDisplayMedia`, não uma limitação do código.

## 3. Tela de Chamados (Help Desk)

Novo módulo `js/chamados.js` + item "Chamados" no menu.

- Qualquer usuário logado pode abrir um chamado (título, categoria,
  prioridade, descrição).
- Cada usuário só vê os próprios chamados abertos.
- Administrador, Gestor e Desenvolvedor (mesmo grupo que já edita projetos —
  novo flag `podeResponderChamados` em `auth.js`, espelhando os mesmos
  perfis de `podeEditar`) veem e respondem **todos** os chamados, e podem
  mudar o status (Aberto → Em Andamento → Resolvido/Fechado).
- O solicitante também pode adicionar mensagens no próprio chamado (para dar
  mais contexto), mas não pode alterar o status nem ver chamados de outras
  pessoas.
- Perfil "Usuário Solicitante" (que antes só enxergava Discovery) agora
  também enxerga e usa a tela de Chamados.

## 4. Telas cortadas em zoom normal (Discovery, Sincronização, Relatórios)

O menu lateral tinha `height: 100vh` fixo, sem rolagem, e cresceu para 15
itens ao longo do projeto. Corrigido: o sidebar virou uma coluna flexível —
a logo fica fixa no topo e a lista de navegação (`.sidebar-nav`) rola por
dentro dela quando não cabe tudo na tela. Nenhum item fica mais inacessível.

## Bônus: função `toast()` que não existia

Vários módulos (`risks.js`, `capacity.js`, `discovery.js`, `governance.js`,
`kanban.js`...) chamavam uma função global `toast(...)` para mostrar
notificações — mas essa função nunca foi implementada no projeto (só o CSS e
o container HTML existiam). Isso quebrava silenciosamente (`ReferenceError`)
ações como salvar um risco, mover um card no Kanban ou registrar uma
aprovação. Implementada em `app.js`.

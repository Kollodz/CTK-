# Documentação Técnica — RPA Governance

## 1. Visão geral da arquitetura

Aplicação **SPA (Single Page Application)** estática, sem back-end, sem build step e sem dependências de pacote (`npm`). Toda a lógica roda no navegador, em JavaScript puro (ES6+), com persistência em `LocalStorage`.

```
┌───────────────────────────── index.html ─────────────────────────────┐
│  Tela de Login  →  App Shell (Sidebar + Topbar + Container de Módulo) │
└─────────────────────────────────────────────────────────────────────┘
        │                         │                         │
   js/auth.js                js/storage.js              js/calc.js
 (sessão, RBAC,           (LocalStorage, ofuscação,     (ICE/RICE/Score,
  troca de senha)          sanitização, auditoria)        Business Case)
        │                         │                         │
        └────────────── js/app.js (orquestrador) ────────────┘
                                  │
        ┌──────────┬─────────────┼─────────────┬──────────────┬─────────┐
   dashboard.js  projects.js  priorization.js  capacity.js   kanban.js  users.js
   roadmap.js  governance.js   risks.js       audit.js  reports.js/export.js

   js/charts.js — motor de gráficos Canvas 2D nativo, usado por dashboard.js
```

Cada módulo expõe um objeto com um método `render(container)` que popula a `<div id="module-container">`. A navegação (`App.navigate`) apenas troca qual módulo é renderizado — não há reload de página nem roteamento por URL, mantendo o sistema utilizável a partir de um único `index.html` local.

## 2. Persistência de dados

- **LocalStorage** do navegador, por origem (por isso os dados não são compartilhados entre diferentes usuários/máquinas — cada instalação local tem seu próprio "banco de dados").
- Todas as chaves são prefixadas com `rpa_gov_` e armazenadas como strings ofuscadas (ver seção 4).
- Coleções principais: `projects`, `team`, `risks`, `users`, `audit_log`, `settings`, `session`.
- Não há paginação/índices — adequado para portfólios de até alguns milhares de registros (limite prático do LocalStorage é ~5–10MB por origem).

## 3. Motor de priorização e cálculo financeiro (`calc.js`)

- **ICE** = Impacto × Confiança(normalizada 0–5) × Facilidade(6 − Esforço, capado 1–5).
- **RICE** = (Reach × Impacto × Confiança) ÷ Esforço.
- **Score Corporativo** (0–100): combinação ponderada de Impacto (20%), Urgência (15%), Volume (15%), Risco invertido (15%), Alinhamento Estratégico (15%) e ROI normalizado (20%). Classificação automática: Crítica ≥75, Alta ≥55, Média ≥35, Baixa <35.
- **Business Case**: execuções projetadas (dia × 21 dias úteis × 12 meses), horas e FTE economizados, TCO (custo base por complexidade + 15% de manutenção anual), Benefício Líquido, ROI, Payback e VPL simplificado (3 anos, taxa de desconto de 10% a.a.).
- Todas as fórmulas e pesos estão isolados em `calc.js` e podem ser recalibrados alterando as constantes no topo do arquivo, sem tocar nos módulos de UI.

## 3B. Identidade visual (marca)

A paleta de cores da área (Deep Blue `#000E19`, True Navy `#3c547c`, Flowing Blue `#C3CEE1`, Clean Gray `#e3e0de`, Off White `#FFFAF1`, Sustainable Green `#69aa02`, Safety Green `#BEF91B`) está centralizada como variáveis CSS no topo de `css/styles.css` (bloco `:root`). Para ajustar qualquer cor da marca no futuro, basta alterar o valor da variável correspondente — botões, sidebar, badges e demais componentes são atualizados automaticamente. As cores dos gráficos em `dashboard.js` são a única exceção: são passadas explicitamente a cada chamada do `MiniChart`, pois não é possível usar variáveis CSS dentro do Canvas 2D.

A logo (`assets/logo.jpg`) é referenciada em dois pontos do `index.html`: na tela de login (`.login-logo-img`) e na barra lateral (`.sidebar-logo-img`). Para trocá-la, basta substituir o arquivo `assets/logo.jpg` por uma nova imagem com o mesmo nome, ou atualizar o caminho `src` nas duas tags `<img>`.

## 4. Segurança da informação — o que está implementado e suas limitações

Este é um ponto importante para uso corporativo responsável: **por ser um sistema 100% client-side (sem servidor), qualquer "segurança" aplicada aqui tem limitações estruturais que não existiriam em uma arquitetura com back-end.** Documentamos isso com transparência:

| Controle | Implementação atual | Limitação |
|---|---|---|
| Autenticação | Login com **PBKDF2-SHA256 (150.000 iterações) + sal aleatório por usuário**, via `crypto.subtle` nativo do navegador (sem biblioteca externa). Contas criadas antes desta atualização usam um hash fraco legado e são migradas automaticamente para o esquema novo no próximo login bem-sucedido. Mensagens de erro genéricas ("Usuário ou senha inválidos") para não revelar se o login existe. Troca de senha self-service exige a senha atual. | O hash (mesmo o seguro) e os dados de todos os usuários residem no LocalStorage do navegador — e, como a equipe optou por sincronizar login/senha via Excel compartilhado (ver Base de Dados Compartilhada), também no `Banco_RPA.xlsx` salvo na rede. PBKDF2 com sal torna a quebra por força bruta muito mais cara que o esquema anterior, mas ainda não equivale a um servidor de autenticação de verdade — qualquer pessoa com acesso à pasta de rede vê a lista de logins (não as senhas em si). |
| Controle de acesso (RBAC) | Permissões por perfil (`Administrador/Gestor/Desenvolvedor/Visualizador`) aplicadas na camada de UI, incluindo o novo módulo de **Gestão de Usuários** (item de menu oculto e módulo bloqueado para quem não é Administrador) | Como todo o código roda no cliente, um usuário tecnicamente habilidoso poderia contornar as checagens via console do navegador. RBAC client-side é adequado para **governança e organização do fluxo de trabalho**, não para proteger dados de um usuário malicioso determinado. |
| Gestão de usuários | Tela dedicada (`users.js`, só Administrador) para criar, editar (nome/perfil/senha) e excluir usuários. Salvaguardas: não é possível excluir o próprio usuário logado nem o último Administrador do sistema. | As mesmas limitações de um sistema client-side descritas acima se aplicam. |
| Criptografia dos dados salvos | Ofuscação reversível XOR + Base64 (`storage.js`) | A chave está no próprio código-fonte JavaScript entregue ao navegador — isso **não é criptografia forte**, é uma barreira contra leitura casual. Não deve ser usada como única proteção para dados sensíveis reais. |
| Sanitização de inputs / proteção XSS | Função `Sanitize.html()` escapa HTML antes de qualquer inserção via `innerHTML`; `Sanitize.input()` remove tags `<script>` e é aplicada a todos os campos de texto livre no momento do salvamento (projetos, riscos, equipe, usuários) | Reduz significativamente o risco de XSS armazenado a partir dos próprios formulários do sistema. |
| Proteção contra Injection | Não há banco de dados relacional/SQL neste sistema (persistência é objeto JSON em LocalStorage), portanto SQL Injection não se aplica; validação de tipos é aplicada nos formulários. | — |
| Auditoria | Toda ação relevante (login, tentativas de login falhas, CRUD, aprovações, gestão de usuários, exportações) é registrada em `audit_log` com usuário, perfil, data, hora e detalhe | O log também está no LocalStorage do próprio navegador — não é um log central imutável. |
| LGPD | Tela de consentimento/retenção configurável em `settings`, exportação de dados do titular (usuário logado) | Não há mecanismo de exclusão automática por prazo de retenção nem base legal centralizada — indicado para simular o fluxo, não para compliance formal. |

**Recomendação para uso corporativo real:** se o sistema precisar proteger dados sensíveis de verdade (dados de RH, financeiros, PII de terceiros) ou impedir usuários mal-intencionados de burlar o RBAC, ele deve evoluir para uma arquitetura com back-end (API + banco de dados + autenticação server-side, ex.: OAuth2/JWT), mantendo o front-end atual como camada de apresentação.

## 5. Bibliotecas externas

**Nenhuma.** O sistema não depende de nenhuma biblioteca externa ou CDN:

- **Gráficos**: implementados em `charts.js`, um motor próprio sobre Canvas 2D (barras, doughnut, linha, dispersão), sem nenhuma dependência.
- **Exportação Excel**: implementada em `export.js` usando o formato nativo do Excel (HTML + namespaces `mso-application`), que o Excel abre diretamente como pasta de trabalho com múltiplas abas — sem SheetJS nem qualquer outra biblioteca.

Isso elimina uma falha real observada em campo: em redes corporativas que bloqueiam domínios externos (comum quando o sistema é aberto a partir de um drive de rede sem saída para a internet), a dependência de CDN fazia os gráficos do Dashboard ficarem em branco, pois a variável global da biblioteca externa nunca chegava a existir. Com o motor nativo, o Dashboard funciona 100% offline, sempre.

## 6. Extensibilidade

- **Novo módulo**: crie `js/novomodulo.js` com um objeto `{ render(container) {...} }`, adicione o `<script>` no `index.html`, registre em `renderers` (`app.js`) e adicione um botão `.nav-item` na sidebar.
- **Novos campos em projetos**: adicione o campo no formulário (`projects.js` → `openForm`) e, se necessário, use-o em `calc.js`.
- **Integração futura com back-end real**: a camada `storage.js` foi propositalmente isolada (`Store.get/set/remove`) para que possa ser substituída por chamadas a uma API REST sem alterar os módulos de UI.

## 7. Tooltips nos gráficos

`charts.js` registra, para cada elemento desenhado (barra, fatia, ponto), uma "região de acerto" em coordenadas CSS do canvas. Um único listener de `mousemove`/`mouseleave` por gráfico localiza a região sob o cursor e atualiza uma única `<div class="chart-tooltip">` compartilhada (criada uma vez, reaproveitada por todos os gráficos). `dashboard.js` fornece o conteúdo de cada tooltip via a função `tooltip(i)`, incluindo — para gráficos onde cada elemento representa um projeto — nome, área, status, complexidade, score, ROI, economia anual, horas economizadas/mês e data de criação (helper `projectTooltipRows()`).

## 8. Discovery Self-Service (`discovery.js`)

Wizard de 4 etapas com estado mantido em `Discovery.draft`/`Discovery.step`. Ao final, `Calc.discoveryViabilidade()` e `Calc.discoveryROI()` (em `calc.js`) calculam o score de viabilidade e a estimativa financeira, seguindo as fórmulas:

```
Frequência anual = 260 (diário) | 52 (semanal) | 12 (mensal) | 260 × vezes/dia (várias vezes/dia)
Horas Economizadas/ano = (Volume × Tempo Médio × Frequência) ÷ 60
Economia Anual = Horas Economizadas × Valor Hora (parametrizado em Configurações)
ROI (%) = (Economia Anual − Custo Projeto) ÷ Custo Projeto × 100
Score de Viabilidade = +25 processo padronizado, +25 regras definidas, +20 usa sistemas,
                        +15 usa Excel, +15 não exige julgamento humano  (máx. 100)
```

As submissões ficam em `Store.get('discovery')`. Um usuário com permissão de edição pode "Converter em Projeto", que cria um registro em `projects` pré-preenchido a partir dos dados do Discovery (status inicial "Triagem").

**Limitação importante e deliberada**: o "feedback automático por e-mail" do documento original é exibido **na tela**, não enviado por e-mail de verdade — este é um sistema client-side sem servidor, e não existe forma de uma página HTML/JS local disparar e-mails reais sem um back-end/serviço de e-mail transacional. Anexos de evidência (Etapa 4) têm apenas o **nome do arquivo** registrado, não o conteúdo — o LocalStorage tem cota de poucos MB por origem, insuficiente para armazenar arquivos binários de forma confiável.

## 9. Base de Dados Compartilhada (`sync.js` + `export.js`)

Gera/lê um arquivo **`Banco_RPA.xlsx` real** (binário OOXML, não um truque de HTML), usando a biblioteca **SheetJS** carregada via CDN (`js/export.js`). Abas: `TB_PROJETOS`, `TB_DISCOVERY`, `TB_USUARIOS`, `TB_STATUS_HISTORICO`, `TB_PARAMETROS`, `TB_CAPACIDADE`, `TB_RISCOS`.

**Por que trocamos do formato HTML-disfarçado para .xlsx real**: a primeira versão gerava um `.xls` que era na verdade HTML com um truque específico do Excel (`mso-application`) para simular várias abas. Isso funcionava bem quando o próprio Microsoft Excel abria o arquivo, mas outras ferramentas de leitura — incluindo o SheetJS, quando a equipe passou a precisar ler arquivos genuinamente editados no Excel — não entendem esse truque e misturavam o conteúdo de todas as abas em uma só. Gerando um `.xlsx` binário de verdade (via `XLSX.utils.book_new()` / `json_to_sheet()` / `writeFile()`), o arquivo é interpretado da mesma forma por qualquer ferramenta, inclusive depois de editado e salvo de novo pelo próprio Excel.

**Dependência externa**: diferente do resto do sistema (gráficos nativos, etc.), esta função específica depende da SheetJS via CDN — decisão confirmada com a equipe, que tem acesso à internet no ambiente de uso. Cada função relacionada a Excel checa `typeof XLSX === 'undefined'` antes de operar e mostra um aviso claro (não trava silenciosamente) se a biblioteca não carregar; CSV, JSON e PDF continuam funcionando independentemente disso. Para eliminar essa dependência de internet no futuro, baixe `https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js`, salve como `js/vendor/xlsx.full.min.js` no projeto, e troque a tag `<script>` correspondente no `index.html` para apontar para o arquivo local.

**Datas do Excel**: a importação usa `XLSX.read(data, { cellDates: true })`, que faz o SheetJS devolver células de data como objetos `Date` reais em vez de números de série ambíguos. A função `normalizeExcelDate()` (`export.js`) converte esse `Date` (ou, defensivamente, um número de série ou texto em outros formatos) para o formato `AAAA-MM-DD` exigido pelos campos `<input type="date">`. Isso corrige um bug em que projetos editados no Excel — que reconhece automaticamente texto parecido com data e o converte para seu tipo de data interno — voltavam com as datas em branco ao reimportar.

**Sincronização de usuários**: `TB_USUARIOS` inclui `passwordHash` e `passwordSalt` (esquema PBKDF2-SHA256 seguro — ver seção de segurança) e **é** reimportada, permitindo logar com a mesma conta em qualquer computador. Usuários existentes localmente têm login/senha atualizados pelos do arquivo; usuários novos do arquivo são criados automaticamente. Essa decisão foi tomada com a equipe cientes do trade-off: mesmo com hash seguro, qualquer pessoa com acesso à pasta de rede onde o arquivo fica salvo consegue ver a lista de logins (não as senhas em si, que continuam protegidas pelo hash).

**Fluxo de importação em duas etapas**: `Exporter.parseDatabaseFile(file)` lê e valida o arquivo sem gravar nada ainda; a tela mostra um resumo (quantos projetos, riscos, usuários etc. o arquivo contém) e só grava de fato (`Exporter.commitDatabaseImport()`) depois de confirmação explícita. Isso evita tanto importar o arquivo errado sem perceber quanto gravação parcial caso uma aba esteja malformada.

Isso resolve o pedido de "quando outro usuário abrir o sistema ele veja os mesmos projetos" da forma mais robusta possível **sem servidor**: exportar → salvar em pasta de rede → outro usuário importa o mesmo arquivo. É uma sincronização manual, não em tempo real (ver aviso na própria tela) — sem servidor, não há como eliminar esse passo manual nem resolver de verdade a concorrência entre edições simultâneas (ver roadmap).

## 9B. Nova lógica de datas e previsão de finalização

O campo **Previsão de Finalização** (`dataPrevisaoFinalizacao`, opcional) foi adicionado ao cadastro de projetos e passou a alimentar o Roadmap: quando preenchido, a barra do projeto usa essa data real em vez da estimativa automática de 90 dias. Barras sem previsão cadastrada aparecem com um padrão listrado no Roadmap para deixar claro que são uma estimativa, não um compromisso real.

## 10. Execuções por Semana e nova lógica de economia

O campo **Execuções por Semana** (obrigatório, inteiro, mínimo 1) passou a ser o principal direcionador de frequência no Business Case, substituindo o antigo cálculo baseado em dias úteis/ano (252 dias). Nova fórmula, em `calc.js`:

```
Execuções/Ano = Execuções por Semana × 52
Horas Economizadas/Ano = Horas por Execução × Execuções por Semana × 52
Economia Anual = Horas Economizadas/Ano × Valor Hora
ROI (%) = (Economia Anual − Custo do Projeto) ÷ Custo do Projeto × 100
```

**Compatibilidade com projetos existentes**: registros criados antes desta atualização não têm `execucoesPorSemana` salvo. Para não quebrá-los, `Calc.businessCase()` aplica um fallback automático: se o campo não existir, deriva um valor equivalente a partir do antigo `execucoesPorDia × 5` (mínimo 1). Isso foi validado com testes garantindo que nenhum projeto existente passa a exibir economia zerada ou `NaN`. O campo é exportado na Base de Dados Compartilhada como a coluna `execucoesPorSemana` da aba `TB_PROJETOS`.

## 11. Exclusão de registros (Capacidade e Riscos)

Ambas as telas seguem o mesmo padrão já usado em Projetos: botão 🗑️ visível apenas para o perfil **Administrador** (`Auth.permissao('podeExcluir')`), modal de confirmação com o texto *"Tem certeza que deseja excluir este registro? Esta ação não poderá ser desfeita."*, remoção do registro do array em memória e do LocalStorage (`Store.set`), atualização automática da tela, e registro na Auditoria com o nome do módulo prefixado na ação (`"Capacidade: Membro excluído"` / `"Riscos: Risco excluído"`) — a trilha de auditoria já registra automaticamente usuário, perfil, data e hora para cada entrada.

## 12. Roadmap futuro (migração para back-end/SQL)

Caminho sugerido caso o projeto evolua para um ambiente corporativo real, com múltiplos usuários simultâneos e dados sensíveis:

1. **Back-end + banco relacional**: substituir `storage.js` (`Store.get/set`) por chamadas a uma API REST/GraphQL sobre um banco SQL (PostgreSQL/SQL Server), mantendo o mesmo contrato de funções para minimizar mudanças nos módulos de UI.
2. **Autenticação server-side**: login com JWT/OAuth2 e hash de senha real (bcrypt/argon2) no servidor, substituindo o hash simplificado local.
3. **Sincronização em tempo real**: substituir o export/import manual de Excel por WebSocket ou polling contra a API, eliminando o risco de sobrescrita entre usuários.
4. **E-mail transacional real**: integrar um serviço (SMTP corporativo, SendGrid, Amazon SES etc.) para o feedback automático do Discovery.
5. **Armazenamento de anexos**: mover os uploads de evidência para um bucket de arquivos (S3, Azure Blob) referenciado por URL no banco, em vez de apenas o nome do arquivo.
6. **Auditoria centralizada e imutável**: mover os logs para uma tabela server-side com proteção contra alteração, em vez do LocalStorage do navegador.

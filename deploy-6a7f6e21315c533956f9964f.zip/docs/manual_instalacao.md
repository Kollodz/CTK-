# Manual de Instalação — RPA Governance

## 1. Requisitos

- Nenhuma instalação de servidor, banco de dados ou dependências é necessária.
- Um navegador moderno: Google Chrome, Microsoft Edge, Firefox ou Safari (versões atualizadas).
- **Conexão com a internet é necessária para os recursos de Excel** (Relatórios → Exportar Excel, e a Base de Dados Compartilhada), que usam a biblioteca SheetJS via CDN — decisão confirmada com a equipe, que tem internet disponível no ambiente de uso. Os gráficos do Dashboard (motor `charts.js`, Canvas 2D nativo) continuam 100% offline, sem depender de nada externo. Se a internet cair, os botões de Excel mostram um aviso claro em vez de travar — CSV, JSON e PDF continuam funcionando normalmente. Veja `DOCUMENTACAO_TECNICA.md` para instruções de hospedar a biblioteca localmente, se um dia for preciso eliminar essa dependência.

## 2. Estrutura de pastas

```
rpa-governance/
├── index.html                 → Ponto de entrada do sistema
├── assets/
│   └── logo.jpg                → Logo da área (COE Supply Chain — Automations Management)
├── css/
│   ├── styles.css             → Estilos principais (tema claro)
│   └── dark-theme.css         → Sobrescrita para o tema escuro
├── js/
│   ├── data-seed.js           → Dados de exemplo carregados na primeira execução
│   ├── storage.js             → Camada de persistência (LocalStorage) e segurança
│   ├── auth.js                → Login, sessão, perfis de acesso e troca de senha
│   ├── calc.js                → Motor de cálculo (priorização e business case)
│   ├── charts.js              → Motor de gráficos nativo (Canvas 2D), sem dependências
│   ├── app.js                 → Núcleo da aplicação e navegação
│   ├── dashboard.js           → Módulo 1
│   ├── projects.js            → Módulo 2
│   ├── priorization.js        → Módulo 3
│   ├── businesscase.js        → Módulo 4
│   ├── capacity.js            → Módulo 5
│   ├── roadmap.js             → Módulo 6
│   ├── kanban.js               → Módulo 7
│   ├── governance.js          → Módulo 8
│   ├── risks.js               → Módulo 10
│   ├── audit.js               → Módulo 9 (tela de auditoria/LGPD)
│   ├── users.js               → Gestão de Usuários (cadastro e nível de permissão)
│   ├── discovery.js           → Discovery Self-Service (wizard de 4 etapas)
│   ├── sync.js                → Base de Dados Compartilhada (export/import Banco_RPA.xls)
│   ├── reports.js             → Módulo 12
│   └── export.js              → Módulo 11 (Excel/CSV/JSON/PDF, tudo nativo)
├── data/
│   ├── sample-projects.json   → Referência de formato (não é carregado via fetch)
│   ├── sample-team.json
│   └── sample-risks.json
└── docs/
    ├── MANUAL_INSTALACAO.md
    ├── MANUAL_USUARIO.md
    └── DOCUMENTACAO_TECNICA.md
```

## 3. Como executar

1. Extraia todos os arquivos mantendo a estrutura de pastas acima intacta (o `index.html` precisa continuar na raiz, ao lado das pastas `css/` e `js/`).
2. Dê duplo clique em `index.html` — ele abrirá diretamente no seu navegador padrão.
3. Faça login com um dos usuários pré-cadastrados (usuário e senha listados no `MANUAL_USUARIO.md` — por segurança, eles não aparecem na tela de login).
4. Pronto — todo o sistema roda localmente. Os dados ficam salvos no LocalStorage do navegador, no computador do usuário.
5. **Recomendado:** troque a senha padrão de cada usuário pré-cadastrado assim que possível, usando o botão "🔑 Alterar Senha" no topo do sistema, ou crie usuários novos em **Usuários** (menu lateral, visível apenas para Administradores) e remova os de demonstração.

## 4. Por que os arquivos `.json` em `/data` não são carregados automaticamente

Navegadores bloqueiam requisições `fetch()` para arquivos locais abertos via `file://` por política de CORS. Por isso, os dados de exemplo estão embutidos diretamente em `js/data-seed.js` (que é executado como um script normal, sem restrição). Os arquivos em `/data/*.json` são mantidos apenas como referência de formato, úteis caso você queira futuramente importar dados de outra fonte ou de um sistema real de RPA.

## 5. Resetar os dados para o estado inicial

No navegador, abra o DevTools (F12) → aba **Application/Aplicativo** → **Local Storage** → selecione o domínio/arquivo → exclua as chaves que começam com `rpa_gov_`. Ao recarregar a página, o sistema recriará os dados de exemplo automaticamente.

## 6. Publicação opcional (sem back-end)

Como o sistema é 100% estático, ele também pode ser publicado em qualquer hospedagem de arquivos estáticos (GitHub Pages, Netlify, S3, um servidor IIS/Apache interno etc.) apenas copiando a pasta inteira — sem necessidade de build, servidor de aplicação ou banco de dados.

# Manual do Usuário — RPA Governance

## 1. Login e perfis de acesso

| Perfil | Pode ver | Pode editar | Pode aprovar | Pode excluir | Vê Auditoria | Gerencia Usuários |
|---|---|---|---|---|---|---|
| Administrador | Tudo | Sim | Sim | Sim | Sim | Sim |
| Gestor | Tudo | Sim | Sim | Não | Sim | Não |
| Desenvolvedor | Tudo | Sim (projetos/equipe/riscos) | Não | Não | Não | Não |
| Visualizador | Tudo | Não | Não | Não | Não | Não |
| Usuário Solicitante | Só Discovery | Não | Não | Não | Não | Não |

Usuários pré-cadastrados (troque a senha após o primeiro acesso): `admin/admin123`, `gestor/gestor123`, `dev/dev123`, `visualizador/view123`, `solicitante/solic123`.

Qualquer usuário pode trocar a própria senha a qualquer momento pelo botão **🔑 Alterar Senha** no topo do sistema (exige a senha atual).

## 2. Dashboard Executivo

Visão geral do portfólio: cartões de indicadores (total de projetos, economia, ROI, payback, taxa de sucesso) e gráficos (status, área, economia, evolução mensal, pipeline e complexidade x benefício). Os valores são recalculados automaticamente a cada alteração nos projetos.

## 3. Cadastro de Projetos

- **+ Novo Projeto**: abre um formulário com os dados gerais, status, complexidade, tecnologia, critérios de priorização e variáveis do business case.
- **Execuções por Semana** (novo, obrigatório): quantas vezes o processo roda por semana — número inteiro, mínimo 1. É o principal dado usado para calcular horas economizadas, economia anual e ROI.
- **Previsão de Finalização** (opcional): data real esperada de entrega, usada para desenhar o Roadmap com mais precisão (ver seção 18).
- Use os filtros de busca, área e status para localizar projetos.
- Ícones na tabela: 🔍 ver detalhes e histórico, ✏️ editar, 🗑️ excluir (conforme seu perfil).

## 4. Priorização Automática

Mostra o ranking de todos os projetos ativos ordenados pelo **Score Corporativo** (0–100), junto com os scores ICE e RICE. A classificação (Crítica/Alta/Média/Baixa) é calculada automaticamente a partir do score — não é preciso classificar manualmente.

## 5. Business Case

Selecione um projeto no seletor para ver a análise financeira completa: execuções projetadas, horas e FTE economizados, custo de desenvolvimento e manutenção (TCO), benefício líquido, ROI, payback e VPL simplificado (3 anos, 10% a.a.).

## 6. Capacidade da Equipe

Mostra cartões de calor (heatmap) e uma tabela com o percentual de alocação de cada membro. Verde = disponível, amarelo = no limite (≥85%), vermelho = sobrecarregado (>100%). Administradores, Gestores e Desenvolvedores podem cadastrar ou editar membros. O ícone 🗑️ (somente Administrador) exclui um registro, com uma confirmação antes de apagar de vez.

## 7. Kanban

Arraste os cartões entre as colunas para atualizar o status do projeto — a alteração é salva automaticamente e registrada no histórico do projeto e na auditoria. Perfis sem permissão de edição visualizam o quadro sem poder arrastar.

## 8. Roadmap

Cronograma visual (estilo Gantt) com barras coloridas por situação: planejado, em execução, concluído ou atrasado. Use o filtro de área para focar em uma parte do portfólio.

## 9. Governança

Controle das cinco aprovações obrigatórias por projeto (Sponsor, TI, Segurança, Compliance, LGPD). Clique no ícone para alternar entre aprovado/pendente (somente Administrador e Gestor). O status geral mostra quantas aprovações já foram concedidas.

## 10. Riscos

Cadastre riscos vinculados a um projeto (probabilidade e impacto de 1 a 5). O sistema calcula o nível automaticamente (Baixo/Médio/Alto/Crítico) e monta a matriz de riscos do portfólio. O ícone 🗑️ (somente Administrador) exclui um risco, com uma confirmação antes de apagar de vez.

## 11. Auditoria

Disponível para Administradores e Gestores. Mostra todas as ações relevantes realizadas no sistema (usuário, data, hora, ação) e permite exportar os dados pessoais do próprio usuário logado (LGPD).

## 11B. Usuários

Visível apenas para o perfil **Administrador**. Permite:

- **+ Novo Usuário**: cadastra login, nome, perfil de acesso e senha inicial.
- ✏️ **Editar**: altera nome, perfil de acesso e, opcionalmente, redefine a senha (deixe o campo de senha em branco para mantê-la).
- 🗑️ **Excluir**: remove o usuário. Por segurança, não é possível excluir o próprio usuário logado nem o único Administrador restante do sistema.

Cada alteração (criação, edição, exclusão) é registrada na Auditoria.

## 12. Relatórios Executivos

Consolida pipeline, economia, ranking, capacidade e riscos críticos em um único relatório, com botões para exportar em **Excel** (.xls, compatível nativamente, sem dependências externas), **CSV**, **JSON** ou **PDF** (impressão do navegador).

## 13. Tema claro/escuro

O botão no topo alterna entre os temas. A preferência é salva localmente para as próximas visitas.

## 14. Discovery Self-Service

Qualquer usuário logado pode enviar uma ideia de automação em 4 etapas rápidas (Identificação → Entendimento do Processo → Esforço Atual → Análise de Automação). Ao final:

- O sistema calcula automaticamente um **Score de Viabilidade** (0–100, com base em processo padronizado, regras definidas, uso de sistemas, uso de Excel e ausência de julgamento humano) e classifica em 🟢 Alta / 🟡 Média / 🔴 Baixa Viabilidade.
- Calcula uma **estimativa de ROI, economia anual e horas economizadas/ano**, usando o valor-hora parametrizado no sistema.
- Mostra na tela uma mensagem de **Pré-Aprovado** (viabilidade Alta/Média) ou **Não Elegível** (viabilidade Baixa). ⚠️ Essa mensagem aparece só na tela — o sistema não envia e-mail de verdade, pois não existe servidor de e-mail em um ambiente 100% local.
- Arquivos anexados na Etapa 4 têm apenas o **nome** registrado (não o conteúdo), por limitação de espaço do armazenamento local do navegador.

Na aba **📋 Todas as Ideias** (visível a quem pode editar), é possível clicar em **Converter em Projeto** para transformar uma ideia aprovada em um projeto real no pipeline (status inicial "Triagem"), já com os campos de esforço/economia pré-preenchidos a partir do Discovery.

## 15. Perfil "Usuário Solicitante"

Um colaborador com esse perfil só enxerga a tela de Discovery — ideal para quem só precisa enviar ideias, sem acesso ao resto do sistema. Tabela de permissões atualizada:

| Perfil | Acesso | Edita dados | Aprova | Exclui | Gerencia Usuários |
|---|---|---|---|---|---|
| Administrador | Tudo | Sim | Sim | Sim | Sim |
| Gestor | Tudo | Sim | Sim | Não | Não |
| Desenvolvedor | Tudo | Sim (projetos/equipe/riscos) | Não | Não | Não |
| Visualizador | Tudo (leitura) | Não | Não | Não | Não |
| Usuário Solicitante | Só Discovery | Não | Não | Não | Não |

## 16. Base de Dados Compartilhada (🔄 menu lateral)

Como o sistema não tem servidor, cada computador guarda seus próprios dados no navegador. Para que pessoas em computadores diferentes vejam os **mesmos dados**, use esta tela (visível a quem pode editar; a importação é restrita a Administrador/Gestor):

1. **📤 Exportar** gera o arquivo `Banco_RPA.xlsx` (Excel de verdade) com todas as abas (Projetos, Discovery, Usuários, Histórico de Status, Parâmetros, Capacidade, Riscos).
2. Salve esse arquivo em uma pasta de rede compartilhada pela equipe. Pode abrir e editar no Excel se precisar — é um arquivo real, então continua funcionando normalmente depois de editado e salvo de novo.
3. A outra pessoa abre o sistema no computador dela e usa **📥 Importar**, selecionando o mesmo arquivo — o sistema mostra um resumo do que o arquivo contém antes de aplicar. Confirmando, os dados dela são **substituídos** pelos do arquivo.

⚠️ É uma sincronização **manual**, não em tempo real — combine com a equipe uma ordem para evitar que uma importação sobrescreva o trabalho de outra pessoa entre as sincronizações.

🔑 **Login e senha são sincronizados** (com hash seguro, não em texto puro), justamente para permitir logar com a mesma conta em qualquer computador da equipe.

## 17. Tooltips nos gráficos do Dashboard

Passe o mouse sobre qualquer barra, fatia, ponto de linha ou ponto de dispersão nos gráficos do Dashboard para ver os detalhes completos (nome, área, status, complexidade, score, ROI, economia anual, horas economizadas e data de criação, conforme o tipo de gráfico).

## 18. Previsão de Finalização e Roadmap

No cadastro de projetos, o campo **Previsão de Finalização** (opcional) define uma data real de entrega esperada. Preenchendo esse campo, o Roadmap passa a mostrar a barra do projeto usando essa data em vez de uma estimativa automática de 90 dias — barras sem previsão cadastrada aparecem com um padrão listrado no Roadmap, indicando que são só uma estimativa.

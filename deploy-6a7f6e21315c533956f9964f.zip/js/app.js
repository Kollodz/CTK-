/**
 * Application Main Controller (app.js)
 * Gerenciador principal de rotas, navegação e ciclo de vida da aplicação.
 */

// Garantia global para exibição e fechamento de modais (Novo Projeto, Edição, Detalhes)
window.Modal = window.Modal || {
  triggerElement: null,

  open(title, htmlContent) {
    this.triggerElement = document.activeElement;
    let overlay = document.getElementById('global-modal-overlay');
    
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'global-modal-overlay';
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `
        <div class="modal-container" role="dialog" aria-modal="true">
          <div class="modal-header">
            <h3 id="global-modal-title"></h3>
            <button type="button" class="modal-close" onclick="Modal.close()">&times;</button>
          </div>
          <div class="modal-body" id="global-modal-body"></div>
        </div>
      `;
      document.body.appendChild(overlay);

      // Fecha o modal ao clicar no fundo escuro (overlay)
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          Modal.close();
        }
      });
    }

    const titleEl = document.getElementById('global-modal-title');
    const bodyEl = document.getElementById('global-modal-body');

    if (titleEl) titleEl.innerText = title;
    if (bodyEl) bodyEl.innerHTML = htmlContent;

    // Ativa o modal e exibe na tela
    overlay.removeAttribute('inert');
    overlay.classList.add('active');
    overlay.setAttribute('aria-hidden', 'false');

    // Mover o foco para o botão de fechar dentro do modal
    const closeBtn = overlay.querySelector('.modal-close');
    if (closeBtn) {
      closeBtn.focus();
    }
  },

  close() {
    // 1. Remove o foco ativo antes de esconder (evita alerta de acessibilidade)
    if (document.activeElement && typeof document.activeElement.blur === 'function') {
      document.activeElement.blur();
    }

    // 2. Oculta o Modal Global
    const overlay = document.getElementById('global-modal-overlay');
    if (overlay) {
      overlay.classList.remove('active');
      overlay.setAttribute('aria-hidden', 'true');
      overlay.setAttribute('inert', '');
    }

    // 3. Fecha outros modais específicos
    document.querySelectorAll('.modal, .modal-overlay, .custom-modal').forEach(m => {
      m.classList.remove('active');
      m.setAttribute('aria-hidden', 'true');
      m.setAttribute('inert', '');
    });

    // 4. Retorna o foco ao elemento de origem
    if (this.triggerElement && typeof this.triggerElement.focus === 'function') {
      this.triggerElement.focus();
      this.triggerElement = null;
    }
  }
};

// Listener global para fechar modais ao pressionar a tecla ESC
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    Modal.close();
  }
});

/**
 * Notificação "toast" — usada em quase todo o app (risks.js, capacity.js,
 * discovery.js, governance.js, kanban.js, storage.js etc.) mas a função em
 * si nunca existia no projeto: só o CSS (.toast, .toast-container) e o
 * container no index.html estavam prontos. Qualquer chamada direta (sem o
 * guard "typeof toast === 'function'") quebrava a tela com ReferenceError —
 * por isso ações como salvar um risco ou mover um card no Kanban podiam
 * falhar silenciosamente no console.
 */
function toast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) { console.warn(`[toast:${type}]`, message); return; }

  const el = document.createElement('div');
  el.className = `toast${type && type !== 'info' ? ' toast-' + type : ''}`;
  el.setAttribute('role', 'status');
  el.textContent = message;
  container.appendChild(el);

  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 250);
  }, 3200);
}
window.toast = toast;

const App = {
  currentModule: null,
  initialized: false,

  async init() {
    try {
      this.bindEvents();

      // Restaura a sessão real do Supabase Auth (sobrevive a F5/nova aba).
      // Sem isso o app podia achar que "tem sessão" (via sessionStorage)
      // mesmo sem token válido, e todo acesso ao banco seria barrado pelo RLS.
      if (typeof Auth !== 'undefined' && Auth.restoreSession) {
        await Auth.restoreSession();
      }

      if (typeof Auth !== 'undefined' && Auth.requireLogin()) {
        // Aquece o cache local com os dados reais do Supabase antes de
        // renderizar qualquer módulo (settings, projetos, equipe, etc.)
        if (typeof Store !== 'undefined' && Store.warmUp) {
          await Store.warmUp();
        }
        this.showApp();
        await this.boot();
      } else {
        this.showLogin();
      }
    } catch (error) {
      console.error('Erro na inicialização da aplicação:', error);
    }
  },

  showApp() {
    const loginScreen = document.getElementById('login-screen');
    const appShell = document.getElementById('app-shell');

    if (loginScreen) loginScreen.classList.add('hidden');
    if (appShell) appShell.classList.remove('hidden');

    this.updateUserHeader();
  },

  showLogin() {
    const loginScreen = document.getElementById('login-screen');
    const appShell = document.getElementById('app-shell');

    if (loginScreen) loginScreen.classList.remove('hidden');
    if (appShell) appShell.classList.add('hidden');
  },

  updateUserHeader() {
    if (typeof Auth === 'undefined') return;
    const user = Auth.currentUser();
    if (!user) return;

    const nameEl = document.getElementById('user-display-name');
    const roleEl = document.getElementById('user-display-role');

    const nome = typeof user === 'object' ? (user.nome || user.username || 'Usuário') : user;
    const perfil = typeof user === 'object' ? (user.perfil || user.role || '') : '';

    if (nameEl) nameEl.textContent = nome;
    if (roleEl) roleEl.textContent = perfil;
  },

  bindEvents() {
    if (this.initialized) return;
    this.initialized = true;

    const sidebarNav = document.getElementById('sidebar-nav');
    if (sidebarNav) {
      sidebarNav.addEventListener('click', (e) => {
        const button = e.target.closest('.nav-item');
        if (button) {
          e.preventDefault();
          const moduleName = button.dataset.module;
          if (moduleName) {
            this.navigate(moduleName);
          }
        }
      });
    }

    const loginForm = document.getElementById('login-form');
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const userEl = document.getElementById('login-user');
        const passEl = document.getElementById('login-pass');
        const errEl = document.getElementById('login-error');

        if (errEl) {
          errEl.textContent = '';
          errEl.classList.add('hidden');
        }

        const userVal = userEl ? userEl.value.trim() : '';
        const passVal = passEl ? passEl.value : '';

        if (typeof Auth !== 'undefined') {
          const res = await Auth.login(userVal, passVal);
          if (res && res.ok) {
            if (typeof Store !== 'undefined' && Store.warmUp) {
              await Store.warmUp();
            }
            this.showApp();
            await this.boot();
          } else if (errEl) {
            errEl.textContent = (res && res.msg) || 'Falha na autenticação.';
            errEl.classList.remove('hidden');
          }
        }
      });
    }

    const logoutBtn = document.getElementById('btn-logout');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (typeof Auth !== 'undefined') {
          Auth.logout();
        }
      });
    }
  },

  async boot() {
    // Se a conta foi criada por um Administrador com senha temporária, a
    // pessoa é obrigada a trocar a senha antes de usar qualquer parte do
    // sistema — sem essa trava, a senha escolhida pelo Administrador (que
    // ele conhece) poderia continuar valendo para sempre.
    const currentUser = typeof Auth !== 'undefined' ? Auth.currentUser() : null;
    if (currentUser && currentUser.precisaTrocarSenha) {
      this.forcarTrocaSenha();
      return;
    }

    document.querySelectorAll('.nav-item').forEach(b => {
      b.style.display = 'block';
    });

    if (typeof Auth !== 'undefined' && typeof Auth.permissao === 'function' && Auth.permissao('apenasDiscovery')) {
      // "Usuário Solicitante" só enxerga Discovery e Chamados (pode abrir
      // chamado de suporte, mas continua sem acesso ao resto do sistema).
      document.querySelectorAll('.nav-item').forEach(b => {
        if (b.dataset.module !== 'discovery' && b.dataset.module !== 'chamados' && b.dataset.module !== 'users') {
          b.style.display = 'none';
        }
      });
      await this.navigate('discovery', true);
    } else {
      await this.navigate('dashboard', true);
    }
  },

  // Tela obrigatória de troca de senha — sem botão de cancelar, sem acesso
  // ao resto do sistema até a senha ser trocada com sucesso.
  forcarTrocaSenha() {
    this.showApp();
    document.querySelectorAll('.nav-item').forEach(b => { b.style.display = 'none'; });
    const container = document.getElementById('module-container');
    if (container) {
      container.innerHTML = `
        <div class="modal-forced-wrap">
          <div class="wizard-card" style="max-width:420px;margin:60px auto">
            <div class="wizard-step-title">Defina uma nova senha</div>
            <p class="form-hint">Por segurança, você precisa trocar a senha temporária antes de continuar.</p>
            <form id="forced-pass-form" class="form-grid">
              <label class="full">Senha temporária atual<input type="password" name="current" required></label>
              <label class="full">Nova senha (mín. 6 caracteres)<input type="password" name="new" required minlength="6"></label>
              <div id="forced-pass-error" class="login-error hidden"></div>
              <div class="form-actions"><button type="submit" class="btn btn-primary">Salvar e continuar</button></div>
            </form>
          </div>
        </div>
      `;
    }

    const form = document.getElementById('forced-pass-form');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fd = new FormData(form);
        const errEl = document.getElementById('forced-pass-error');
        if (errEl) errEl.classList.add('hidden');

        const result = await Auth.changeOwnPassword(fd.get('current'), fd.get('new'));
        if (!result.ok) {
          if (errEl) { errEl.textContent = result.msg; errEl.classList.remove('hidden'); }
          return;
        }
        if (typeof toast === 'function') toast('Senha alterada com sucesso.');
        await this.boot();
      });
    }
  },

  async navigate(moduleName, force = false) {
    if (this.currentModule === moduleName && !force) return;
    this.currentModule = moduleName;

    Modal.close();

    document.querySelectorAll('.nav-item').forEach(b => {
      b.classList.toggle('active', b.dataset.module === moduleName);
    });

    const container = document.getElementById('module-container');
    if (!container) return;

    container.innerHTML = '<div class="loading-state" style="padding: 20px; text-align: center;"><p>Carregando...</p></div>';

    const renderers = {
      dashboard: typeof Dashboard !== 'undefined' ? Dashboard : null,
      projects: typeof Projects !== 'undefined' ? Projects : null,
      priorization: typeof Priorization !== 'undefined' ? Priorization : null,
      businesscase: typeof BusinessCase !== 'undefined' ? BusinessCase : null,
      capacity: typeof Capacity !== 'undefined' ? Capacity : null,
      kanban: typeof Kanban !== 'undefined' ? Kanban : null,
      roadmap: typeof Roadmap !== 'undefined' ? Roadmap : null,
      governance: typeof Governance !== 'undefined' ? Governance : null,
      risks: typeof Risks !== 'undefined' ? Risks : null,
      audit: typeof AuditView !== 'undefined' ? AuditView : null,
      users: typeof Users !== 'undefined' ? Users : null,
      discovery: typeof Discovery !== 'undefined' ? Discovery : null,
      sync: typeof Sync !== 'undefined' ? Sync : null,
      reports: typeof Reports !== 'undefined' ? Reports : null,
      chamados: typeof Chamados !== 'undefined' ? Chamados : null,
      chatkb: typeof ChatKB !== 'undefined' ? ChatKB : null,
      chatattendance: typeof ChatAttendance !== 'undefined' ? ChatAttendance : null
    };

    const targetModule = renderers[moduleName];

    if (targetModule && typeof targetModule.render === 'function') {
      try {
        await targetModule.render(container);
      } catch (err) {
        console.error(`Erro crítico ao renderizar o módulo "${moduleName}":`, err);
        container.innerHTML = `
          <div class="info-box danger" style="margin: 20px; padding: 20px; border: 1px solid #f5c6cb; background-color: #f8d7da; color: #721c24; border-radius: 8px;">
            <h3 style="margin-top: 0; font-size: 1.1rem;">Erro ao carregar o módulo</h3>
            <p style="margin: 8px 0;">Ocorreu uma falha ao processar a interface do módulo <strong>${moduleName}</strong>.</p>
            <p style="margin: 0;"><small><strong>Detalhe:</strong> ${err.message || err}</small></p>
          </div>`;
      }
    } else {
      container.innerHTML = `<p class="empty-state" style="padding: 26px; text-align: center;">Módulo "${moduleName}" não encontrado ou em desenvolvimento.</p>`;
    }
  }
};

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
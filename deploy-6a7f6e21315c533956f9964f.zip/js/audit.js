/* ============================================================================
   audit.js (view)
   Módulo 9 (parte) - Tela de Auditoria
   ============================================================================ */

const AuditView = {
  // Helper defensivo para obter as configurações com valores padrão seguros
  getSettings() {
    const defaultSettings = { lgpd: { retencaoDias: 365 } };
    const settings = Store.get('settings', defaultSettings);
    
    if (!settings || typeof settings !== 'object') {
      return defaultSettings;
    }
    
    return {
      ...defaultSettings,
      ...settings,
      lgpd: {
        ...defaultSettings.lgpd,
        ...(settings.lgpd || {})
      }
    };
  },

  render(container) {
    if (!container) return;

    const currentUser = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : {};
    const canView = (typeof Auth !== 'undefined' && Auth.permissao && Auth.permissao('vePainelSeguranca')) || (currentUser && currentUser.perfil === 'Gestor');

    if (!canView) {
      container.innerHTML = `<div class="module-header"><h2>Auditoria</h2></div><p class="empty-state">Acesso restrito a Administradores e Gestores.</p>`;
      return;
    }

    const logs = (typeof Audit !== 'undefined' && Array.isArray(Audit.all())) ? Audit.all() : [];
    const settings = this.getSettings();
    const retencaoDias = settings.lgpd.retencaoDias;

    container.innerHTML = `
      <div class="module-header">
        <h2>Auditoria e Segurança</h2>
        <p class="module-subtitle">Registro de ações realizadas no sistema (usuário, data, hora e ação)</p>
      </div>

      <div class="info-box">
        <strong>Controles de segurança ativos:</strong> autenticação local com senha hasheada,
        controle de acesso por perfil (RBAC), sanitização de inputs contra XSS,
        dados armazenados localmente com ofuscação reversível, e trilha de auditoria completa.
        Consulte a Documentação Técnica para detalhes e limitações de um sistema 100% client-side.
      </div>

      <div class="info-box">
        <strong>LGPD:</strong> consentimento de uso de dados ativo, retenção configurada em
        ${retencaoDias} dias. Você pode exportar os dados pessoais e
        logs associados ao seu usuário a qualquer momento.
        <button class="btn btn-secondary" id="btn-lgpd-export" style="margin-left:12px">Exportar meus dados (LGPD)</button>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Data</th><th>Hora</th><th>Usuário</th><th>Perfil</th><th>Ação</th><th>Detalhes</th></tr></thead>
          <tbody>
            ${logs.map(l => {
              if (!l) return '';
              return `<tr>
                <td>${Sanitize.html(l.data || '')}</td>
                <td>${Sanitize.html(l.hora || '')}</td>
                <td>${Sanitize.html(l.usuario || '')}</td>
                <td>${Sanitize.html(l.perfil || '')}</td>
                <td>${Sanitize.html(l.acao || '')}</td>
                <td>${Sanitize.html(l.detalhes || '')}</td>
              </tr>`;
            }).join('') || `<tr><td colspan="6" class="empty-state">Nenhum evento registrado ainda.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;

    const btnExport = document.getElementById('btn-lgpd-export');
    if (btnExport) {
      btnExport.addEventListener('click', () => {
        if (typeof Exporter !== 'undefined' && Exporter.exportLGPD) {
          Exporter.exportLGPD();
        }
      });
    }
  }
};
/* ============================================================================
   auth.js
   Autenticação via Supabase Auth real (signInWithPassword), controle de
   sessão e perfis de acesso (RBAC).

   Por que mudou: o login antigo comparava senha em texto puro direto na
   tabela rpa_usuarios. Isso é inseguro E é a causa raiz do storage.js não
   sincronizar: o Supabase nunca via uma sessão "authenticated" de verdade,
   então as políticas de RLS (auth.role() = 'authenticated') bloqueavam
   toda leitura/escrita silenciosamente.
   ============================================================================ */

const PERFIS = {
  Administrador: { podeEditar: true, podeAprovar: true, podeExcluir: true, vePainelSeguranca: true, podeGerenciarUsuarios: true, apenasDiscovery: false, podeResponderChamados: true },
  Gestor: { podeEditar: true, podeAprovar: true, podeExcluir: false, vePainelSeguranca: false, podeGerenciarUsuarios: false, apenasDiscovery: false, podeResponderChamados: true },
  Desenvolvedor: { podeEditar: true, podeAprovar: false, podeExcluir: false, vePainelSeguranca: false, podeGerenciarUsuarios: false, apenasDiscovery: false, podeResponderChamados: true },
  Visualizador: { podeEditar: false, podeAprovar: false, podeExcluir: false, vePainelSeguranca: false, podeGerenciarUsuarios: false, apenasDiscovery: false, podeResponderChamados: false },
  'Usuário Solicitante': { podeEditar: false, podeAprovar: false, podeExcluir: false, vePainelSeguranca: false, podeGerenciarUsuarios: false, apenasDiscovery: true, podeResponderChamados: false }
};

const AUTH_EMAIL_DOMAIN = 'rpa.local';
function usernameToEmail(username) {
  return `${String(username).trim().toLowerCase()}@${AUTH_EMAIL_DOMAIN}`;
}

const Auth = {
  _profileCache: null,

  currentUser() {
    if (this._profileCache) return this._profileCache;
    const raw = sessionStorage.getItem('rpa_session');
    try {
      const parsed = raw ? JSON.parse(raw) : null;
      this._profileCache = parsed;
      return parsed;
    } catch (e) {
      return null;
    }
  },

  permissao(chave) {
    const user = this.currentUser();
    if (!user) return false;
    return !!(PERFIS[user.perfil] && PERFIS[user.perfil][chave]);
  },

  async _loadProfile(username) {
    const client = window.supabaseClient;
    if (!client) return null;

    const { data: found, error } = await client
      .from('rpa_usuarios')
      .select('username, nome, perfil, precisaTrocarSenha')
      .eq('username', username)
      .maybeSingle();

    if (error || !found) return null;
    return this._saveProfileSession(found);
  },

  async _loadProfileByEmail(email) {
    const client = window.supabaseClient;
    if (!client) return null;

    const { data: found, error } = await client
      .from('rpa_usuarios')
      .select('username, nome, perfil, precisaTrocarSenha')
      .eq('email', email)
      .maybeSingle();

    if (error || !found) return null;
    return this._saveProfileSession(found);
  },

  _saveProfileSession(found) {
    const sessionObj = {
      username: found.username,
      nome: found.nome || found.username,
      perfil: found.perfil,
      loginEm: new Date().toISOString(),
      precisaTrocarSenha: !!found.precisaTrocarSenha
    };
    sessionStorage.setItem('rpa_session', JSON.stringify(sessionObj));
    this._profileCache = sessionObj;
    return sessionObj;
  },

  async restoreSession() {
    const client = window.supabaseClient;
    if (!client) return false;

    try {
      const { data: { session } } = await client.auth.getSession();
      if (!session || !session.user) {
        sessionStorage.removeItem('rpa_session');
        this._profileCache = null;
        return false;
      }

      const profile = await this._loadProfileByEmail(session.user.email);
      return !!profile;
    } catch (e) {
      console.error('Erro ao restaurar sessão do Supabase:', e);
      return false;
    }
  },

  async login(username, password) {
    if (!username || !password) return { ok: false, msg: 'Informe usuário e senha.' };

    const client = window.supabaseClient;
    if (!client) {
      return { ok: false, msg: 'Cliente do banco de dados não inicializado.' };
    }

    try {
      // Descobre o e-mail associado ao username (pode ser o sintético
      // usuario@rpa.local, gerado pelo sistema, ou um e-mail real cadastrado
      // manualmente/pelo formulário de usuários — os dois funcionam).
      const { data: lookedUpEmail, error: lookupErr } = await client.rpc('rpa_lookup_email', {
        p_username: username.trim()
      });

      const email = (!lookupErr && lookedUpEmail) ? lookedUpEmail : usernameToEmail(username);

      const { data, error } = await client.auth.signInWithPassword({ email, password });

      if (error || !data?.user) {
        return { ok: false, msg: 'Usuário ou senha inválidos.' };
      }

      const profile = await this._loadProfileByEmail(email);
      if (!profile) {
        await client.auth.signOut();
        return { ok: false, msg: 'Usuário autenticado, mas sem cadastro de perfil. Contate um administrador.' };
      }

      if (typeof Audit !== 'undefined' && Audit.log) {
        Audit.log('Login realizado', 'perfil: ' + profile.perfil);
      }
      return { ok: true };
    } catch (e) {
      console.error('Erro na autenticação:', e);
      return { ok: false, msg: 'Erro ao conectar com o banco de dados.' };
    }
  },

  async logout() {
    if (typeof Audit !== 'undefined' && Audit.log) {
      await Audit.log('Logout realizado');
    }
    const client = window.supabaseClient;
    if (client) {
      try { await client.auth.signOut(); } catch (e) { /* ignora */ }
    }
    sessionStorage.removeItem('rpa_session');
    this._profileCache = null;

    // Limpa o cache local de dados (projetos, usuários, chamados etc.) —
    // sem isso, num computador compartilhado, a próxima pessoa a abrir o
    // navegador ainda enxergaria esses dados mesmo sem estar logada.
    Object.keys(localStorage)
      .filter(k => k.startsWith('rpa_'))
      .forEach(k => localStorage.removeItem(k));

    window.location.reload();
  },

  requireLogin() {
    return this.currentUser() !== null;
  },

  async changeOwnPassword(currentPassword, newPassword) {
  const user = this.currentUser();
  if (!user) return { ok: false, msg: 'Sessão expirada. Faça login novamente.' };
  if (!newPassword || newPassword.length < 6) {
    return { ok: false, msg: 'A nova senha deve ter ao menos 6 caracteres.' };
  }

  const client = window.supabaseClient;
  if (!client) return { ok: false, msg: 'Cliente do banco de dados não inicializado.' };

  const { data: lookedUpEmail } = await client.rpc('rpa_lookup_email', { p_username: user.username });
  const email = lookedUpEmail || usernameToEmail(user.username);

  const { error: reauthErr } = await client.auth.signInWithPassword({ email, password: currentPassword });
  if (reauthErr) return { ok: false, msg: 'Senha atual incorreta.' };

  const { error: updateErr } = await client.auth.updateUser({ password: newPassword });
  if (updateErr) return { ok: false, msg: 'Erro ao atualizar a senha: ' + updateErr.message };

  // Marca no banco que o usuário não precisa mais trocar a senha
  try {
    await client
      .from('rpa_usuarios')
      .update({ precisaTrocarSenha: false })
      .eq('username', user.username);

    // Atualiza a sessão local com a flag limpa
    const updated = { ...user, precisaTrocarSenha: false };
    sessionStorage.setItem('rpa_session', JSON.stringify(updated));
    this._profileCache = updated;
  } catch (e) {
    // Se der erro aqui, não bloqueia a troca de senha,
    // só deixa a flag possivelmente desatualizada.
    console.warn('Erro ao atualizar flag precisaTrocarSenha:', e);
  }

  if (typeof Audit !== 'undefined' && Audit.log) {
    await Audit.log('Senha alterada pelo próprio usuário', user.username);
  }

  return { ok: true };
}
};

if (window.supabaseClient) {
  window.supabaseClient.auth.onAuthStateChange((event) => {
    if (event === 'SIGNED_OUT') {
      sessionStorage.removeItem('rpa_session');
      Auth._profileCache = null;
    }
  });
}

/* ============================================================================
   businesscase.js
   Módulo 4 - Business Case Financeiro
   ============================================================================ */

const BusinessCase = {
  render(container) {
    const projects = Store.get('projects', []);

    container.innerHTML = `
      <div class="module-header">
        <h2>Business Case</h2>
        <p class="module-subtitle">Análise financeira detalhada por projeto</p>
      </div>

      <div class="filter-bar">
        <select id="bc-select">
          ${projects.length ? projects.map(p => `<option value="${Sanitize.html(p.id)}">${Sanitize.html(p.id)} — ${Sanitize.html(p.nome)}</option>`).join('') : '<option value="">Nenhum projeto disponível</option>'}
        </select>
      </div>

      <div id="bc-content"></div>
    `;

    const selectEl = document.getElementById('bc-select');
    if (projects.length) {
      selectEl.addEventListener('change', (e) => this.renderCase(e.target.value));
      this.renderCase(projects[0].id);
    } else {
      document.getElementById('bc-content').innerHTML = '<p class="empty-state">Nenhum projeto cadastrado.</p>';
    }
  },

  renderCase(id) {
    const p = Store.get('projects', []).find(x => x.id === id);
    const el = document.getElementById('bc-content');
    if (!p) { el.innerHTML = '<p class="empty-state">Selecione um projeto válido.</p>'; return; }

    const bc = Calc.businessCase(p);

    el.innerHTML = `
      <div class="kpi-grid">
        ${kpiCard('Execuções / Dia', p.execucoesPorDia || 0, '🔁')}
        ${kpiCard('Execuções / Semana', bc.execSemana, '📆')}
        ${kpiCard('Execuções / Mês', bc.execMes, '🗓️')}
        ${kpiCard('Execuções / Ano', bc.execAno, '📊')}
        ${kpiCard('Horas Economizadas/Mês', bc.horasEconomizadasMes, '⏱️')}
        ${kpiCard('Horas Economizadas/Ano', bc.horasEconomizadasAno, '⏳')}
        ${kpiCard('FTE Economizado', bc.fteEconomizado, '👤')}
        ${kpiCard('Economia Mensal', formatBRL(bc.economiaMensal), '💰', 'kpi-green')}
        ${kpiCard('Economia Anual', formatBRL(bc.economiaAnual), '💵', 'kpi-green')}
        ${kpiCard('Custo de Desenvolvimento', formatBRL(bc.custoBase), '🏗️')}
        ${kpiCard('Manutenção Anual', formatBRL(bc.custoManutencaoAnual), '🔧')}
        ${kpiCard('TCO (ano 1)', formatBRL(bc.tco), '📦')}
        ${kpiCard('Benefício Líquido', formatBRL(bc.beneficioLiquido), '➕', bc.beneficioLiquido >= 0 ? 'kpi-green' : 'kpi-red')}
        ${kpiCard('ROI', (bc.roiPercent ?? 0) + '%', '📈', bc.roiPercent >= 0 ? 'kpi-green' : 'kpi-red')}
        ${kpiCard('Payback', (bc.paybackMeses ?? '-') + ' meses', '⏲️')}
        ${kpiCard('VPL (3 anos, 10% a.a.)', formatBRL(bc.vpl), '🧮', bc.vpl >= 0 ? 'kpi-green' : 'kpi-red')}
      </div>

      <div class="info-box">
        <strong>Metodologia:</strong> Execuções mensais/anuais estimadas a partir de execuções/dia × 21 dias úteis × 12 meses.
        TCO considera custo de desenvolvimento (baseado na complexidade) + 15% de manutenção anual.
        VPL simplificado projeta 3 anos de fluxo de caixa (economia − manutenção) descontados a 10% a.a.
      </div>
    `;
  }
};
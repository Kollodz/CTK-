/* ============================================================================
   calc.js
   Motor de cálculo: priorização (ICE/RICE/Score Corporativo) e Business Case
   financeiro. Mantido isolado do DOM para ser reutilizável e testável.
   ============================================================================ */

const Calc = {

  /* --------------------------- Priorização ------------------------------- */

  // ICE: Impact x Confidence x Ease  (escala 1-5, resultado 1-125)
  scoreICE(p) {
    const impacto = Number(p.impacto) || 0;
    const confidence = Number(p.confidence) || 0; // 0-100
    const ease = 6 - (Number(p.effort) || 5); // effort 1(fácil)-8(difícil) invertido, capado em 1-5
    const easeNorm = Math.max(1, Math.min(5, ease));
    const confNorm = (confidence / 100) * 5;
    return round1(impacto * confNorm * easeNorm);
  },

  // RICE: (Reach x Impact x Confidence) / Effort
  scoreRICE(p) {
    const reach = Number(p.reach) || 0;
    const impacto = Number(p.impacto) || 0;
    const confidence = (Number(p.confidence) || 0) / 100;
    const effort = Math.max(0.5, Number(p.effort) || 1);
    return round1((reach * impacto * confidence) / effort);
  },

  // Score Corporativo: combina impacto, urgência, volume, risco (invertido),
  // alinhamento estratégico e ROI estimado do business case, normalizado 0-100.
  scoreCorporativo(p) {
    const impacto = Number(p.impacto) || 0;      // 1-5
    const urgencia = Number(p.urgencia) || 0;     // 1-5
    const volume = Number(p.volume) || 0;         // 1-5
    const riscoInv = 6 - (Number(p.riscoScore) || 3); // risco 1-5 invertido (menor risco = melhor)
    const alinhamento = Number(p.alinhamento) || 0; // 1-5
    const roi = Calc.businessCase(p).roiPercent;
    const roiNorm = Math.max(0, Math.min(5, roi / 40)); // cada 40% de ROI ~ 1 ponto, capado em 5

    const pesos = { impacto: 0.20, urgencia: 0.15, volume: 0.15, risco: 0.15, alinhamento: 0.15, roi: 0.20 };
    const somaPonderada =
      impacto * pesos.impacto +
      urgencia * pesos.urgencia +
      volume * pesos.volume +
      riscoInv * pesos.risco +
      alinhamento * pesos.alinhamento +
      roiNorm * pesos.roi;

    // Normaliza de escala 1-5 para 0-100
    return round1((somaPonderada / 5) * 100);
  },

  classificacaoPrioridade(scoreCorporativo) {
    if (scoreCorporativo >= 75) return 'Crítica';
    if (scoreCorporativo >= 55) return 'Alta';
    if (scoreCorporativo >= 35) return 'Média';
    return 'Baixa';
  },

  /* --------------------------- Business Case ------------------------------ */

  businessCase(p) {
    const horasAtuais = Number(p.horasAtuais) || 0; // horas/execução manual atual (contexto informativo)
    const horasPorExecucao = Number(p.horasPorExecucao) || 0;
    const valorHora = Number(p.valorHora) || 0;

    // "Execuções por Semana" passou a ser o campo principal de frequência (nova lógica).
    // Fallback para registros antigos que ainda não tinham esse campo: deriva a partir
    // de execucoesPorDia × 5 (aproximação de dias úteis/semana), com mínimo de 1.
    const execSemana = Number(p.execucoesPorSemana) || Math.max(1, Math.round((Number(p.execucoesPorDia) || 0) * 5));
    const execDia = round1(execSemana / 5);
    const execMes = round1(execSemana * 4.33); // ~52 semanas / 12 meses
    const execAno = execSemana * 52;

    // Horas Economizadas por Ano = (Tempo Médio × Volume por Execução × Execuções por Semana × 52) ÷ 60
    // horasPorExecucao já representa "tempo médio × volume" combinados, em horas.
    const horasEconomizadasAno = horasPorExecucao * execSemana * 52;
    const horasEconomizadasMes = horasEconomizadasAno / 12;

    const economiaAnual = horasEconomizadasAno * valorHora;
    const economiaMensal = economiaAnual / 12;

    const fteEconomizado = round2(horasEconomizadasMes / 160); // 160h = 1 FTE/mês

    // Custo de desenvolvimento estimado a partir da complexidade (TCO simplificado)
    const custoBase = { 'Baixa': 70, 'Média': 70, 'Alta': 70, 'Muito Alta': 70 }[p.complexidade] || 70;
    const custoManutencaoAnual = custoBase * 0.15;
    const tco = custoBase + custoManutencaoAnual; // TCO ano 1

    const beneficioLiquido = economiaAnual - tco;
    const roiPercent = tco > 0 ? round1((beneficioLiquido / tco) * 100) : 0;
    const paybackMeses = economiaMensal > 0 ? round1(custoBase / economiaMensal) : null;

    // VPL simplificado (3 anos, taxa de desconto 10% a.a., fluxo anual = economia - manutenção)
    const taxa = 0.10;
    let vpl = -custoBase;
    for (let ano = 1; ano <= 3; ano++) {
      const fluxo = economiaAnual - custoManutencaoAnual;
      vpl += fluxo / Math.pow(1 + taxa, ano);
    }

    return {
      execSemana, execMes, execAno, execDia,
      horasEconomizadasMes: round1(horasEconomizadasMes),
      horasEconomizadasAno: round1(horasEconomizadasAno),
      economiaMensal: round0(economiaMensal),
      economiaAnual: round0(economiaAnual),
      fteEconomizado,
      custoBase, custoManutencaoAnual: round0(custoManutencaoAnual),
      tco: round0(tco),
      beneficioLiquido: round0(beneficioLiquido),
      roiPercent,
      paybackMeses,
      vpl: round0(vpl),
      horasAtuais
    };
  },

  /* --------------------------- Riscos ------------------------------------ */

  nivelRisco(probabilidade, impacto) {
    const score = Number(probabilidade) * Number(impacto);
    if (score >= 16) return 'Crítico';
    if (score >= 10) return 'Alto';
    if (score >= 5) return 'Médio';
    return 'Baixo';
  },

  /* --------------------------- Discovery self-service --------------------- */

  // Frequência anual de ocorrências do processo, conforme a opção escolhida.
  discoveryFrequenciaAnual(d) {
    const mapa = { 'Várias vezes por dia': 260, 'Diariamente': 260, 'Semanalmente': 52, 'Mensalmente': 12 };
    const base = mapa[d.frequencia] || 12;
    if (d.frequencia === 'Várias vezes por dia') {
      return base * Math.max(1, Number(d.vezesPorDia) || 1);
    }
    return base;
  },

  // Horas Economizadas = (Volume × Tempo Médio × Frequência) ÷ 60
  // Economia Anual = Horas Economizadas × Valor Hora
  // ROI = (Economia Anual - Custo Projeto) ÷ Custo Projeto × 100
  discoveryROI(d) {
    const frequenciaAnual = this.discoveryFrequenciaAnual(d);
    const volume = Number(d.volumeCasos) || 0;
    const tempoMedioMin = Number(d.tempoMedioMin) || 0;
    const valorHora = Number(Store.get('settings', {}).valorHoraPadrao) || 65;
    const custoProjeto = Number(Store.get('settings', {}).custoProjetoPadrao) || 20000;

    const horasEconomizadasAno = round1((volume * tempoMedioMin * frequenciaAnual) / 60);
    const economiaAnual = round0(horasEconomizadasAno * valorHora);
    const roiPercent = custoProjeto > 0 ? round1(((economiaAnual - custoProjeto) / custoProjeto) * 100) : 0;
    const fteEconomizado = round2((horasEconomizadasAno / 12) / 160);

    return { frequenciaAnual, horasEconomizadasAno, economiaAnual, roiPercent, fteEconomizado, custoProjeto, valorHora };
  },

  // Score de viabilidade (0-100) com base nas respostas do Discovery.
  discoveryViabilidade(d) {
    let score = 0;
    if (d.processoPadronizado === 'Sim') score += 25;
    if (d.regrasDefinidas === 'Sim') score += 25;
    if (d.usaSistemas === 'Sim') score += 20;
    if (d.usaExcel === 'Sim') score += 15;
    if (d.exigeJulgamentoHumano === 'Não') score += 15;

    let classificacao, selo;
    if (score >= 80) { classificacao = 'Alta Viabilidade'; selo = '🟢'; }
    else if (score >= 50) { classificacao = 'Média Viabilidade'; selo = '🟡'; }
    else { classificacao = 'Baixa Viabilidade'; selo = '🔴'; }

    return { score, classificacao, selo };
  }
};

function round0(n) { return Math.round(n); }
function round1(n) { return Math.round(n * 10) / 10; }
function round2(n) { return Math.round(n * 100) / 100; }

function formatBRL(n) {
  return (Number(n) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

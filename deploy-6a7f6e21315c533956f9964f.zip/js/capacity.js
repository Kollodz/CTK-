/* ============================================================================
   capacity.js
   Módulo 5 - Capacidade da Equipe
   ============================================================================ */

const Capacity = {
  // Helper defensivo para garantir que 'team' venha sempre como Array
  getTeamArray() {
    const raw = Store.get('team', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.team)) return raw.team;
    return [];
  },

  render(container) {
    if (!container) return;

    const team = this.getTeamArray();

    container.innerHTML = `
      <div class="module-header">
        <h2>Capacidade da Equipe</h2>
        <p class="module-subtitle">Alocação e consumo de horas por membro da equipe</p>
        <div class="header-actions">
          ${Auth.permissao('podeEditar') ? '<button class="btn btn-primary" id="btn-new-member">+ Novo Membro</button>' : ''}
        </div>
      </div>

      <div class="heatmap-grid">
        ${team.map(m => this.memberCard(m)).join('') || '<p class="empty-state">Nenhum membro cadastrado.</p>'}
      </div>

      <div class="table-wrap" style="margin-top:24px">
        <table class="data-table">
          <thead><tr><th>Nome</th><th>Papel</th><th>Disponível (h)</th><th>Alocado (h)</th><th>Consumido (h)</th><th>% Alocação</th><th>Status</th>${(Auth.permissao('podeEditar') || Auth.permissao('podeExcluir')) ? '<th>Ações</th>' : ''}</tr></thead>
          <tbody>
            ${team.map(m => {
              if (!m) return '';
              const calcPct = m.horasDisponiveis ? ((m.horasAlocadas || 0) / m.horasDisponiveis) * 100 : 0;
              const pct = typeof round1 === 'function' ? round1(calcPct) : Math.round(calcPct);
              const status = pct > 100 ? 'sobrecarregado' : pct >= 85 ? 'nolimite' : 'disponivel';
              const statusLabel = pct > 100 ? 'Sobrecarregado' : pct >= 85 ? 'No Limite' : 'Disponível';
              return `<tr>
                <td>${Sanitize.html(m.nome || 'Sem nome')}</td>
                <td>${Sanitize.html(m.papel || '-')}</td>
                <td>${m.horasDisponiveis ?? 0}</td>
                <td>${m.horasAlocadas ?? 0}</td>
                <td>${m.horasConsumidas ?? 0}</td>
                <td>${pct}%</td>
                <td><span class="badge badge-capacity-${status}">${statusLabel}</span></td>
                ${(Auth.permissao('podeEditar') || Auth.permissao('podeExcluir')) ? `<td class="row-actions">
                  ${Auth.permissao('podeEditar') ? `<button class="icon-btn" data-edit="${m.id}" title="Editar">✏️</button>` : ''}
                  ${Auth.permissao('podeExcluir') ? `<button class="icon-btn" data-del="${m.id}" title="Excluir">🗑️</button>` : ''}
                </td>` : ''}
              </tr>`;
            }).join('') || '<tr><td colspan="8" class="empty-state">Nenhum membro cadastrado.</td></tr>'}
          </tbody>
        </table>
      </div>
    `;

    if (Auth.permissao('podeEditar')) {
      const btnNew = document.getElementById('btn-new-member');
      if (btnNew) btnNew.addEventListener('click', () => this.openForm());
      container.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => this.openForm(b.dataset.edit)));
    }
    if (Auth.permissao('podeExcluir')) {
      container.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => this.deleteMember(b.dataset.del)));
    }
  },

  memberCard(m) {
    if (!m) return '';
    const calcPct = m.horasDisponiveis ? ((m.horasAlocadas || 0) / m.horasDisponiveis) * 100 : 0;
    const roundVal = typeof round1 === 'function' ? round1(calcPct) : Math.round(calcPct);
    const pct = Math.min(130, roundVal);
    let heatClass = 'heat-ok';
    if (pct > 100) heatClass = 'heat-over';
    else if (pct >= 85) heatClass = 'heat-warn';
    return `
      <div class="heat-card ${heatClass}">
        <div class="heat-name">${Sanitize.html(m.nome || 'Sem nome')}</div>
        <div class="heat-role">${Sanitize.html(m.papel || '-')}</div>
        <div class="heat-bar"><div class="heat-bar-fill" style="width:${Math.min(100, pct)}%"></div></div>
        <div class="heat-pct">${pct}% alocado</div>
      </div>
    `;
  },

  openForm(id = null) {
    const team = this.getTeamArray();
    const m = id ? (team.find(x => x && x.id === id) || {}) : {};
    const isEdit = !!id;

    Modal.open(isEdit ? 'Editar Membro' : 'Novo Membro', `
      <form id="member-form" class="form-grid">
        <label>Nome<input required name="nome" value="${Sanitize.html(m.nome || '')}"></label>
        <label>Papel
          <select name="papel">
            ${['Desenvolvedor', 'Analista', 'Product Owner', 'Gestor'].map(r => `<option ${m.papel === r ? 'selected' : ''}>${r}</option>`).join('')}
          </select>
        </label>
        <label>Horas Disponíveis (mês)<input type="number" min="0" name="horasDisponiveis" value="${m.horasDisponiveis ?? 160}"></label>
        <label>Horas Alocadas<input type="number" min="0" name="horasAlocadas" value="${m.horasAlocadas ?? 0}"></label>
        <label>Horas Consumidas<input type="number" min="0" name="horasConsumidas" value="${m.horasConsumidas ?? 0}"></label>
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" id="btn-cancel-member">Cancelar</button>
          <button type="submit" class="btn btn-primary">Salvar</button>
        </div>
      </form>
    `);

    document.getElementById('btn-cancel-member').addEventListener('click', Modal.close);
    document.getElementById('member-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const data = {};
      fd.forEach((v, k) => data[k] = Sanitize.input(String(v)));
      ['horasDisponiveis', 'horasAlocadas', 'horasConsumidas'].forEach(k => data[k] = Number(data[k]) || 0);

      const list = this.getTeamArray();
      if (isEdit) {
        const target = list.find(x => x && x.id === m.id);
        if (target) {
          Object.assign(target, data);
          Audit.log('Membro de equipe editado', target.nome);
        }
      } else {
        const newMember = Object.assign({ id: 'MEM-' + Date.now() }, data);
        list.push(newMember);
        Audit.log('Membro de equipe criado', data.nome);
      }
      Store.set('team', list);
      Modal.close();
      toast('Dados da equipe salvos.');
      const container = document.getElementById('module-container');
      if (container) Capacity.render(container);
    });
  },

  deleteMember(id) {
    const list = this.getTeamArray();
    const target = list.find(x => x && x.id === id);
    if (!target) return;

    if (!confirm('Tem certeza que deseja excluir este registro? Esta ação não poderá ser desfeita.')) return;

    const updated = list.filter(x => x && x.id !== id);
    Store.set('team', updated);
    Audit.log('Capacidade: Membro excluído', (target.nome || '') + ' (' + (target.papel || '') + ')');
    toast('Registro excluído.', 'warn');
    const container = document.getElementById('module-container');
    if (container) Capacity.render(container);
  }
};
/* ============================================================================
   chamados.js
   Tela de Chamados (Help Desk) — qualquer usuário logado pode abrir um
   chamado de suporte; cada um só enxerga os próprios chamados. Administrador,
   Gestor e Desenvolvedor (o mesmo grupo que já edita projetos hoje, via
   Auth.permissao('podeEditar')) enxergam e respondem todos os chamados.
   ============================================================================ */

const CATEGORIA_CHAMADO = ['Dúvida', 'Problema / Erro no sistema', 'Solicitação de Acesso', 'Sugestão de Melhoria', 'Outro'];
const PRIORIDADE_CHAMADO = ['Baixa', 'Média', 'Alta'];
const STATUS_CHAMADO = ['Aberto', 'Em Andamento', 'Resolvido', 'Fechado'];

const Chamados = {
  filtroStatus: '',

  // Quem responde chamados é o mesmo grupo que já edita projetos hoje
  // (Administrador, Gestor, Desenvolvedor). O flag "podeResponderChamados"
  // em auth.js espelha esses mesmos valores — assim fica explícito na
  // permissão o que ela controla, mesmo reaproveitando o mesmo grupo de perfis.
  podeResponder() {
    return typeof Auth !== 'undefined' && Auth.permissao && Auth.permissao('podeResponderChamados');
  },

  getArray() {
    const raw = Store.get('chamados', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.chamados)) return raw.chamados;
    return [];
  },

  render(container) {
    if (!container) return;
    const podeResponder = this.podeResponder();

    container.innerHTML = `
      <div class="module-header">
        <h2>🎫 Chamados</h2>
        <p class="module-subtitle">${podeResponder ? 'Suporte aos usuários do sistema' : 'Solicite suporte ao time de RPA — acompanhe aqui suas solicitações'}</p>
        <div class="header-actions">
          <button class="btn btn-primary" id="btn-new-ticket">+ Abrir Chamado</button>
        </div>
      </div>

      ${podeResponder ? `
        <div class="filter-bar">
          <select id="f-status-chamado">
            <option value="">Todos os Status</option>
            ${STATUS_CHAMADO.map(s => `<option ${s === this.filtroStatus ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </div>
      ` : ''}

      <div class="table-wrap">
        <table class="data-table" id="chamados-table"></table>
      </div>
    `;

    document.getElementById('btn-new-ticket').addEventListener('click', () => this.openForm());

    const fStatus = document.getElementById('f-status-chamado');
    if (fStatus) fStatus.addEventListener('change', (e) => { this.filtroStatus = e.target.value; this.renderTable(); });

    this.renderTable();
  },

  renderTable() {
    const table = document.getElementById('chamados-table');
    if (!table) return;

    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;
    const podeResponder = this.podeResponder();

    let list = this.getArray().slice().sort((a, b) => new Date(b.criadoEm || 0) - new Date(a.criadoEm || 0));
    if (!podeResponder && user) list = list.filter(c => c && c.solicitante === user.username);
    if (podeResponder && this.filtroStatus) list = list.filter(c => c && c.status === this.filtroStatus);

    const statusBadge = (s) => {
      const map = { 'Aberto': 'badge-status-cancelado', 'Em Andamento': 'badge-perfil-gestor', 'Resolvido': 'badge-capacity-disponivel', 'Fechado': 'badge-capacity-disponivel' };
      return `<span class="badge ${map[s] || 'badge-status-cancelado'}">${Sanitize.html(s || 'Aberto')}</span>`;
    };

    table.innerHTML = `
      <thead><tr>
        <th>ID</th><th>Título</th><th>Categoria</th><th>Prioridade</th>${podeResponder ? '<th>Solicitante</th>' : ''}<th>Status</th><th>Aberto em</th><th>Ações</th>
      </tr></thead>
      <tbody>
        ${list.map(c => {
          if (!c) return '';
          return `
          <tr>
            <td>${Sanitize.html(c.id || '')}</td>
            <td>${Sanitize.html(c.titulo || '')}</td>
            <td>${Sanitize.html(c.categoria || '')}</td>
            <td>${Sanitize.html(c.prioridade || '')}</td>
            ${podeResponder ? `<td>${Sanitize.html(c.solicitanteNome || c.solicitante || '')}</td>` : ''}
            <td>${statusBadge(c.status)}</td>
            <td>${formatDateBR(c.criadoEm)}</td>
            <td class="row-actions">
              <button class="icon-btn" data-view="${c.id}" title="Ver / Responder">💬</button>
              ${Auth.permissao('podeExcluir') ? `<button class="icon-btn" data-del="${c.id}" title="Excluir">🗑️</button>` : ''}
            </td>
          </tr>`;
        }).join('') || `<tr><td colspan="${podeResponder ? 8 : 7}" class="empty-state">${podeResponder ? 'Nenhum chamado aberto no momento.' : 'Você ainda não abriu nenhum chamado.'}</td></tr>`}
      </tbody>
    `;

    table.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => this.viewThread(b.dataset.view)));
    table.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => this.deleteTicket(b.dataset.del)));
  },

  openForm() {
    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;

    Modal.open('Abrir Chamado', `
      <form id="ticket-form" class="form-grid">
        <label class="full">Título<input required name="titulo" placeholder="Ex.: Não consigo salvar um projeto"></label>
        <label>Categoria
          <select name="categoria">${CATEGORIA_CHAMADO.map(c => `<option>${Sanitize.html(c)}</option>`).join('')}</select>
        </label>
        <label>Prioridade
          <select name="prioridade">${PRIORIDADE_CHAMADO.map(p => `<option ${p === 'Média' ? 'selected' : ''}>${Sanitize.html(p)}</option>`).join('')}</select>
        </label>
        <label class="full">Descreva o que está acontecendo
          <textarea required name="descricao" rows="4" placeholder="Quanto mais detalhe, mais rápido conseguimos ajudar."></textarea>
        </label>
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" id="btn-cancel-ticket">Cancelar</button>
          <button type="submit" class="btn btn-primary">Enviar Chamado</button>
        </div>
      </form>
    `);

    document.getElementById('btn-cancel-ticket').addEventListener('click', Modal.close);

    document.getElementById('ticket-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const raw = {};
      fd.forEach((v, k) => raw[k] = Sanitize.input(String(v)));

      const list = this.getArray();
      const now = new Date().toISOString();
      const novo = {
        id: 'TCK-' + String(list.length + 1).padStart(4, '0'),
        titulo: raw.titulo,
        categoria: raw.categoria,
        prioridade: raw.prioridade,
        descricao: raw.descricao,
        status: 'Aberto',
        solicitante: user ? user.username : 'desconhecido',
        solicitanteNome: user ? user.nome : 'Desconhecido',
        criadoEm: now,
        atualizadoEm: now,
        mensagens: []
      };

      list.push(novo);
      const sucesso = await Store.set('chamados', list);
      if (!sucesso) {
        notifyTicket('Erro ao salvar o chamado no Supabase. Verifique se a tabela rpa_chamados existe (sql/005_chamados.sql).', 'warn');
        return;
      }

      if (typeof Audit !== 'undefined' && Audit.log) Audit.log('Chamado aberto', novo.id + ' - ' + novo.titulo);
      Modal.close();
      notifyTicket('Chamado enviado. Acompanhe por aqui.', 'success');
      const container = document.getElementById('module-container');
      if (container) Chamados.render(container);
    });
  },

  viewThread(id) {
    const list = this.getArray();
    const c = list.find(x => x && x.id === id);
    if (!c) return;

    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;
    const podeResponder = this.podeResponder();
    const ehDono = user && c.solicitante === user.username;
    if (!podeResponder && !ehDono) return; // proteção extra: nunca abre chamado de outro usuário

    const mensagens = Array.isArray(c.mensagens) ? c.mensagens : [];
    const fmtDataHora = (iso) => {
      if (!iso) return '-';
      const d = new Date(iso);
      if (isNaN(d.getTime())) return iso;
      return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    };

    Modal.open(`${c.id} — ${Sanitize.html(c.titulo)}`, `
      <div class="detail-grid">
        <div><strong>Categoria:</strong> ${Sanitize.html(c.categoria || '—')}</div>
        <div><strong>Prioridade:</strong> ${Sanitize.html(c.prioridade || '—')}</div>
        <div><strong>Solicitante:</strong> ${Sanitize.html(c.solicitanteNome || c.solicitante || '')}</div>
        <div><strong>Aberto em:</strong> ${fmtDataHora(c.criadoEm)}</div>
      </div>

      ${podeResponder ? `
        <label style="display:block;margin-top:14px">Status do chamado
          <select id="ticket-status-select">
            ${STATUS_CHAMADO.map(s => `<option ${s === (c.status || 'Aberto') ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </label>
      ` : ''}

      <h4 style="margin-top:18px">Descrição</h4>
      <p style="white-space:pre-wrap">${Sanitize.html(c.descricao || '')}</p>

      <h4 style="margin-top:18px">Conversa</h4>
      <ul class="history-list" id="ticket-thread">
        ${mensagens.map(m => `
          <li><strong>${Sanitize.html(m.autorNome || m.autor || '')}</strong> ${m.autorPerfil ? `<em>(${Sanitize.html(m.autorPerfil)})</em>` : ''} — ${fmtDataHora(m.data)}<br>${Sanitize.html(m.texto || '')}</li>
        `).join('') || '<li>Nenhuma resposta ainda.</li>'}
      </ul>

      <form id="ticket-reply-form" style="margin-top:14px">
        <label class="full">${podeResponder ? 'Responder ao solicitante' : 'Adicionar uma mensagem'}
          <textarea name="texto" rows="3" placeholder="${podeResponder ? 'Escreva sua resposta...' : 'Alguma informação adicional?'}"></textarea>
        </label>
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" id="btn-close-ticket">Fechar</button>
          <button type="submit" class="btn btn-primary">Enviar</button>
        </div>
      </form>
    `);

    document.getElementById('btn-close-ticket').addEventListener('click', Modal.close);

    const statusSelect = document.getElementById('ticket-status-select');
    if (statusSelect) {
      statusSelect.addEventListener('change', () => this.changeStatus(c.id, statusSelect.value));
    }

    document.getElementById('ticket-reply-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const texto = Sanitize.input(String(fd.get('texto') || ''));
      if (!texto.trim()) return;
      this.addMessage(c.id, texto);
    });
  },

  async addMessage(ticketId, texto) {
    const list = this.getArray();
    const c = list.find(x => x && x.id === ticketId);
    if (!c) return;

    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;
    const podeResponder = this.podeResponder();

    c.mensagens = Array.isArray(c.mensagens) ? c.mensagens : [];
    c.mensagens.push({
      autor: user ? user.username : 'sistema',
      autorNome: user ? user.nome : 'Sistema',
      autorPerfil: podeResponder ? (user ? user.perfil : 'Suporte') : 'Solicitante',
      texto,
      data: new Date().toISOString()
    });
    c.atualizadoEm = new Date().toISOString();
    // Quando o suporte responde um chamado só "Aberto", ele avança sozinho
    // pra "Em Andamento" — evita ficar parado na fila por falta de alguém
    // trocar o status manualmente.
    if (podeResponder && c.status === 'Aberto') c.status = 'Em Andamento';

    const sucesso = await Store.set('chamados', list);
    if (!sucesso) { notifyTicket('Erro ao salvar a resposta no Supabase.', 'warn'); return; }

    if (typeof Audit !== 'undefined' && Audit.log) Audit.log('Chamado respondido', c.id);
    notifyTicket('Mensagem enviada.', 'success');
    this.viewThread(ticketId);
    this.renderTable();
  },

  async changeStatus(ticketId, novoStatus) {
    const list = this.getArray();
    const c = list.find(x => x && x.id === ticketId);
    if (!c || c.status === novoStatus) return;

    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;
    const statusAnterior = c.status;
    c.status = novoStatus;
    c.atualizadoEm = new Date().toISOString();
    c.mensagens = Array.isArray(c.mensagens) ? c.mensagens : [];
    c.mensagens.push({
      autor: user ? user.username : 'sistema',
      autorNome: user ? user.nome : 'Sistema',
      autorPerfil: 'Sistema',
      texto: `Status alterado de "${statusAnterior}" para "${novoStatus}".`,
      data: c.atualizadoEm
    });

    const sucesso = await Store.set('chamados', list);
    if (!sucesso) { notifyTicket('Erro ao atualizar o status no Supabase.', 'warn'); return; }

    if (typeof Audit !== 'undefined' && Audit.log) Audit.log('Status de chamado alterado', `${c.id}: ${statusAnterior} → ${novoStatus}`);
    notifyTicket('Status atualizado.', 'success');
    this.viewThread(ticketId);
    this.renderTable();
  },

  async deleteTicket(id) {
    if (!confirm('Confirma a exclusão do chamado ' + id + '? Esta ação não pode ser desfeita.')) return;
    await Store.remove('chamados', id);
    if (typeof Audit !== 'undefined' && Audit.log) Audit.log('Chamado excluído', id);
    notifyTicket('Chamado excluído.', 'warn');
    this.renderTable();
  }
};

// Helper interno para evitar erros caso o toast não esteja disponível
function notifyTicket(msg, type = 'info') {
  if (typeof toast === 'function') toast(msg, type);
  else alert(`[${type.toUpperCase()}]: ${msg}`);
}

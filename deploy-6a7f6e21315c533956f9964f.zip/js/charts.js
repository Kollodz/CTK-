/* ============================================================================
   charts.js
   Motor de gráficos 100% nativo (Canvas 2D), sem nenhuma dependência externa.

   MOTIVO DESTA MUDANÇA: o sistema antes dependia do Chart.js carregado via
   CDN (cdnjs.cloudflare.com). Em redes corporativas que bloqueiam acesso a
   domínios externos (comum em ambientes que abrem o sistema a partir de um
   drive de rede, como visto em campo), a biblioteca simplesmente não carrega
   e a variável global `Chart` fica indefinida — o que travava a função de
   renderização de TODOS os gráficos do Dashboard, deixando os cartões em
   branco. Este motor próprio elimina essa dependência: o Dashboard agora
   funciona 100% offline, sempre, em qualquer rede.

   TOOLTIPS: cada função de desenho registra "regiões de acerto" (hit regions)
   em coordenadas CSS (não em pixels de device) e liga um único listener de
   mousemove/mouseleave por canvas. Ao passar o mouse sobre uma barra, fatia,
   ponto de linha ou ponto de dispersão, um tooltip flutuante compartilhado
   (uma única div reaproveitada) mostra o conteúdo detalhado — resolvendo a
   ilegibilidade dos rótulos apontada em campo.
   ============================================================================ */

const MiniChart = {

  _dpr() { return window.devicePixelRatio || 1; },

  _prepare(canvas) {
    const dpr = this._dpr();
    const cssW = canvas.clientWidth || canvas.parentElement.clientWidth || 320;
    const cssH = canvas.clientHeight || 240;
    canvas.width = cssW * dpr;
    canvas.height = cssH * dpr;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);
    return { ctx, w: cssW, h: cssH };
  },

  _theme() {
    const dark = document.body.classList.contains('dark');
    return {
      text: dark ? '#E7ECF4' : '#33455E',
      grid: dark ? '#2A3550' : '#E9E5DD',
      dark
    };
  },

  _truncate(ctx, text, maxWidth) {
    if (ctx.measureText(text).width <= maxWidth) return text;
    let t = text;
    while (t.length > 1 && ctx.measureText(t + '…').width > maxWidth) t = t.slice(0, -1);
    return t + '…';
  },

  empty(canvas, msg = 'Sem dados para exibir') {
    const { ctx, w, h } = this._prepare(canvas);
    const theme = this._theme();
    ctx.fillStyle = theme.text;
    ctx.font = '12px -apple-system, Segoe UI, Roboto, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(msg, w / 2, h / 2);
  },

  /* --------------------------- Tooltip flutuante compartilhado --------------- */

  _tooltipEl() {
    let el = document.getElementById('minichart-tooltip');
    if (!el) {
      el = document.createElement('div');
      el.id = 'minichart-tooltip';
      el.className = 'chart-tooltip';
      document.body.appendChild(el);
    }
    return el;
  },

  // title: string; rows: array de [rótulo, valor]
  tooltipHtml(title, rows) {
    const rowsHtml = rows.map(([k, v]) => `<div class="ct-row"><span class="ct-key">${Sanitize.html(k)}</span><span class="ct-val">${Sanitize.html(v)}</span></div>`).join('');
    return `<div class="ct-title">${Sanitize.html(title)}</div>${rowsHtml}`;
  },

  // regions: array de objetos com uma chave .tooltip (HTML já pronto)
  // hitTest(mx, my, region) => boolean, em coordenadas CSS relativas ao canvas
  _bindTooltip(canvas, regions) {
    const tip = this._tooltipEl();
    const hitTest = canvas._hitTest;
    const onMove = (e) => {
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const hit = regions.find(r => hitTest(mx, my, r));
      if (hit) {
        tip.innerHTML = hit.tooltip;
        tip.style.display = 'block';
        const tw = tip.offsetWidth, th = tip.offsetHeight;
        let left = e.clientX + 16, top = e.clientY + 16;
        if (left + tw > window.innerWidth - 8) left = e.clientX - tw - 16;
        if (top + th > window.innerHeight - 8) top = e.clientY - th - 16;
        tip.style.left = left + 'px';
        tip.style.top = top + 'px';
        canvas.style.cursor = 'pointer';
      } else {
        tip.style.display = 'none';
        canvas.style.cursor = 'default';
      }
    };
    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('mouseleave', () => { tip.style.display = 'none'; canvas.style.cursor = 'default'; });
  },

  /* --------------------------- Bar chart (vertical/horizontal) --------------- */
  bar(canvas, { labels, values, color = '#3c547c', horizontal = false, valueFormatter = (v) => v, tooltip = null }) {
    if (!labels.length || values.every(v => !v)) return this.empty(canvas);
    const { ctx, w, h } = this._prepare(canvas);
    const theme = this._theme();
    ctx.font = '11.5px -apple-system, Segoe UI, Roboto, sans-serif';

    const maxVal = Math.max(1, ...values);
    const padLeft = horizontal ? 100 : 40;
    const padRight = horizontal ? 54 : 16, padTop = 14, padBottom = horizontal ? 12 : 50;
    const plotW = w - padLeft - padRight;
    const plotH = h - padTop - padBottom;
    const regions = [];

    ctx.strokeStyle = theme.grid;
    ctx.fillStyle = theme.text;
    ctx.lineWidth = 1;

    if (horizontal) {
      const barH = Math.min(26, plotH / labels.length - 10);
      const step = plotH / labels.length;
      for (let g = 0; g <= 4; g++) {
        const x = padLeft + (plotW * g / 4);
        ctx.beginPath(); ctx.moveTo(x, padTop); ctx.lineTo(x, h - padBottom); ctx.stroke();
      }
      labels.forEach((label, i) => {
        const y = padTop + step * i + (step - barH) / 2;
        const barW = (values[i] / maxVal) * plotW;
        ctx.fillStyle = color;
        ctx.fillRect(padLeft, y, Math.max(1, barW), barH);
        ctx.fillStyle = theme.text;
        ctx.textAlign = 'right';
        ctx.fillText(this._truncate(ctx, label, padLeft - 10), padLeft - 8, y + barH / 2 + 4);
        ctx.textAlign = 'left';
        ctx.fillText(valueFormatter(values[i]), padLeft + barW + 6, y + barH / 2 + 4);
        regions.push({
          x: 0, y, w: w, h: barH,
          tooltip: tooltip ? tooltip(i) : this.tooltipHtml(label, [['Valor', valueFormatter(values[i])]])
        });
      });
    } else {
      const step = plotW / labels.length;
      const barW = Math.min(50, step - 12);
      for (let g = 0; g <= 4; g++) {
        const y = padTop + (plotH * g / 4);
        ctx.beginPath(); ctx.moveTo(padLeft, y); ctx.lineTo(w - padRight, y); ctx.stroke();
      }
      labels.forEach((label, i) => {
        const x = padLeft + step * i + (step - barW) / 2;
        const barH = (values[i] / maxVal) * plotH;
        const y = h - padBottom - barH;
        ctx.fillStyle = color;
        ctx.fillRect(x, y, barW, Math.max(1, barH));
        ctx.fillStyle = theme.text;
        ctx.textAlign = 'center';
        ctx.font = '10.5px -apple-system, Segoe UI, Roboto, sans-serif';
        ctx.fillText(this._truncate(ctx, label, step), x + barW / 2, h - padBottom + 15);
        if (values[i]) ctx.fillText(valueFormatter(values[i]), x + barW / 2, y - 6);
        regions.push({
          x, y: padTop, w: barW, h: h - padBottom - padTop,
          tooltip: tooltip ? tooltip(i) : this.tooltipHtml(label, [['Valor', valueFormatter(values[i])]])
        });
      });
    }

    canvas._hitTest = (mx, my, r) => mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h;
    this._bindTooltip(canvas, regions);
  },

  /* --------------------------- Doughnut chart --------------------------------- */
  doughnut(canvas, { labels, values, colors, tooltip = null }) {
    if (!labels.length || values.every(v => !v)) return this.empty(canvas);
    const { ctx, w, h } = this._prepare(canvas);
    const theme = this._theme();
    const total = values.reduce((a, b) => a + b, 0) || 1;

    const legendH = Math.ceil(labels.length / 2) * 17 + 6;
    const cx = w / 2, cy = (h - legendH) / 2 + 4;
    const radius = Math.max(20, Math.min(cx, cy) - 8);
    const inner = radius * 0.58;
    const regions = [];

    let start = -Math.PI / 2;
    labels.forEach((label, i) => {
      const slice = (values[i] / total) * Math.PI * 2;
      const end = start + slice;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, radius, start, end);
      ctx.closePath();
      ctx.fillStyle = colors[i % colors.length];
      ctx.fill();
      regions.push({
        cx, cy, rInner: inner, rOuter: radius, startAngle: start, endAngle: end,
        tooltip: tooltip ? tooltip(i) : this.tooltipHtml(label, [['Quantidade', values[i]], ['% do total', round1((values[i] / total) * 100) + '%']])
      });
      start = end;
    });
    // furo central
    ctx.beginPath();
    ctx.arc(cx, cy, inner, 0, Math.PI * 2);
    ctx.fillStyle = theme.dark ? '#1A2438' : '#FFFFFF';
    ctx.fill();

    // legenda
    ctx.font = '11px -apple-system, Segoe UI, Roboto, sans-serif';
    ctx.textAlign = 'left';
    const cols = 2;
    const colW = w / cols;
    labels.forEach((label, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const lx = col * colW + 4;
      const ly = h - legendH + row * 17 + 11;
      ctx.fillStyle = colors[i % colors.length];
      ctx.fillRect(lx, ly - 7, 9, 9);
      ctx.fillStyle = theme.text;
      ctx.fillText(this._truncate(ctx, `${label} (${values[i]})`, colW - 18), lx + 13, ly);
    });

    canvas._hitTest = (mx, my, r) => {
      const dx = mx - r.cx, dy = my - r.cy;
      const dist = Math.hypot(dx, dy);
      if (dist < r.rInner || dist > r.rOuter) return false;
      let ang = Math.atan2(dy, dx);
      if (ang < -Math.PI / 2) ang += Math.PI * 2;
      return ang >= r.startAngle && ang < r.endAngle;
    };
    this._bindTooltip(canvas, regions);
  },

  /* --------------------------- Line chart -------------------------------------- */
  line(canvas, { labels, values, color = '#3c547c', fill = true, valueFormatter = (v) => v, tooltip = null }) {
    if (!labels.length) return this.empty(canvas);
    const { ctx, w, h } = this._prepare(canvas);
    const theme = this._theme();
    ctx.font = '11px -apple-system, Segoe UI, Roboto, sans-serif';

    const maxVal = Math.max(1, ...values);
    const padLeft = 64, padRight = 16, padTop = 18, padBottom = 28;
    const plotW = w - padLeft - padRight;
    const plotH = h - padTop - padBottom;
    const stepX = labels.length > 1 ? plotW / (labels.length - 1) : 0;

    ctx.strokeStyle = theme.grid;
    ctx.fillStyle = theme.text;
    for (let g = 0; g <= 4; g++) {
      const y = padTop + (plotH * g / 4);
      ctx.beginPath(); ctx.moveTo(padLeft, y); ctx.lineTo(w - padRight, y); ctx.stroke();
      ctx.textAlign = 'right';
      ctx.fillText(valueFormatter(Math.round(maxVal * (1 - g / 4))), padLeft - 8, y + 3);
    }

    const points = values.map((v, i) => ({ x: padLeft + stepX * i, y: padTop + plotH - (v / maxVal) * plotH }));

    if (fill) {
      ctx.beginPath();
      ctx.moveTo(points[0].x, padTop + plotH);
      points.forEach(p => ctx.lineTo(p.x, p.y));
      ctx.lineTo(points[points.length - 1].x, padTop + plotH);
      ctx.closePath();
      ctx.fillStyle = color + '26'; // ~15% opacity
      ctx.fill();
    }

    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    points.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.stroke();

    const regions = [];
    points.forEach((p, i) => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      regions.push({
        x: p.x, y: p.y, radius: 12,
        tooltip: tooltip ? tooltip(i) : this.tooltipHtml(labels[i], [['Valor', valueFormatter(values[i])]])
      });
    });

    ctx.fillStyle = theme.text;
    ctx.textAlign = 'center';
    labels.forEach((label, i) => ctx.fillText(label, padLeft + stepX * i, h - padBottom + 17));

    canvas._hitTest = (mx, my, r) => Math.hypot(mx - r.x, my - r.y) <= r.radius;
    this._bindTooltip(canvas, regions);
  },

  /* --------------------------- Scatter chart ------------------------------------ */
  scatter(canvas, { points, color = '#F59E0B', xLabel = '', yLabel = '', xMax = 5, tooltip = null }) {
    if (!points.length) return this.empty(canvas);
    const { ctx, w, h } = this._prepare(canvas);
    const theme = this._theme();
    ctx.font = '10.5px -apple-system, Segoe UI, Roboto, sans-serif';

    const padLeft = 64, padRight = 16, padTop = 14, padBottom = 36;
    const plotW = w - padLeft - padRight;
    const plotH = h - padTop - padBottom;
    const maxY = Math.max(1, ...points.map(p => p.y));

    ctx.strokeStyle = theme.grid;
    ctx.fillStyle = theme.text;
    for (let g = 0; g <= 4; g++) {
      const y = padTop + (plotH * g / 4);
      ctx.beginPath(); ctx.moveTo(padLeft, y); ctx.lineTo(w - padRight, y); ctx.stroke();
      ctx.textAlign = 'right';
      ctx.fillText(Math.round(maxY * (1 - g / 4)).toLocaleString('pt-BR'), padLeft - 8, y + 3);
    }
    ctx.beginPath(); ctx.moveTo(padLeft, padTop); ctx.lineTo(padLeft, h - padBottom); ctx.lineTo(w - padRight, h - padBottom); ctx.stroke();

    const regions = [];
    points.forEach((p, i) => {
      const x = padLeft + (p.x / xMax) * plotW;
      const y = padTop + plotH - (p.y / maxY) * plotH;
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fillStyle = color + 'CC';
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      regions.push({
        x, y, radius: 10,
        tooltip: tooltip ? tooltip(p, i) : this.tooltipHtml('Ponto', [['X', p.x], ['Y', p.y]])
      });
    });

    ctx.fillStyle = theme.text;
    ctx.textAlign = 'center';
    ctx.fillText(xLabel, padLeft + plotW / 2, h - 6);

    canvas._hitTest = (mx, my, r) => Math.hypot(mx - r.x, my - r.y) <= r.radius;
    this._bindTooltip(canvas, regions);
  }
};

/* ============================================================================
   chat-admin.js
   Módulo "Base do Chat" — tela onde Administrador/Gestor cadastram, editam
   e removem as respostas que o bot usa (rpa_chat_knowledge_base).

   Segue o mesmo padrão dos outros módulos do sistema (Users, Discovery):
   objeto com .render(container), usa window.Modal e window.toast globais
   já existentes em app.js.

   Integração (ver docs/CHATBOT_INTEGRACAO.md):
     1) <script src="js/chat-admin.js"></script> em index.html, junto dos
        outros módulos.
     2) Adicionar um <button class="nav-item" data-module="chatkb"> na
        sidebar (#sidebar-nav).
     3) Adicionar `chatkb: typeof ChatKB !== 'undefined' ? ChatKB : null,`
        no objeto `renderers` de js/app.js (dentro de App.navigate).
   ============================================================================ */

const ChatKB = {
  async render(container) {
    const user = typeof Auth !== 'undefined' ? Auth.currentUser() : null;
    const podeGerenciar = user && ['Administrador', 'Gestor'].includes(user.perfil);

    if (!podeGerenciar) {
      container.innerHTML = `
        <div class="module-header"><h2>Base do Chat</h2></div>
        <p class="empty-state">Apenas Administradores e Gestores podem gerenciar a base de respostas do chat.</p>`;
      return;
    }

    container.innerHTML = `
      <div class="module-header">
        <h2>Base do Chat (FAQ do Assistente)</h2>
        <p class="module-subtitle">Respostas usadas pelo bot do widget de suporte. Alterações aqui valem para a próxima pergunta feita ao assistente — sem precisar de deploy.</p>
        <div class="header-actions">
          <button class="btn btn-primary" id="btn-new-kb">+ Nova Resposta</button>
        </div>
      </div>
      <div id="chatkb-table-wrap"><div class="loading-state"><p>Carregando...</p></div></div>
    `;

    document.getElementById('btn-new-kb').addEventListener('click', () => this._openForm());

    await this._loadTable();
  },

  async _loadTable() {
    const wrap = document.getElementById('chatkb-table-wrap');
    const { data: entries, error } = await window.supabaseClient
      .from('rpa_chat_knowledge_base')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      wrap.innerHTML = `<p class="empty-state">Erro ao carregar: ${error.message}</p>`;
      return;
    }

    if (!entries || entries.length === 0) {
      wrap.innerHTML = '<p class="empty-state">Nenhuma resposta cadastrada ainda.</p>';
      return;
    }

    wrap.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Pergunta</th>
            <th>Palavras-chave</th>
            <th>Categoria</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${entries.map((e) => `
            <tr>
              <td>${this._esc(e.question)}</td>
              <td>${(e.question_keywords || []).map((k) => `<span class="tag">${this._esc(k)}</span>`).join(' ')}</td>
              <td>${this._esc(e.categoria || '-')}</td>
              <td>${e.ativo ? '<span class="badge badge-success">Ativo</span>' : '<span class="badge">Inativo</span>'}</td>
              <td class="table-actions">
                <button class="btn btn-sm" data-edit="${e.id}">Editar</button>
                <button class="btn btn-sm btn-danger" data-delete="${e.id}">Excluir</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;

    wrap.querySelectorAll('[data-edit]').forEach((btn) => {
      const entry = entries.find((e) => e.id === btn.dataset.edit);
      btn.addEventListener('click', () => this._openForm(entry));
    });
    wrap.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', () => this._delete(btn.dataset.delete));
    });
  },

  _openForm(entry) {
    const isEdit = !!entry;
    const html = `
      <form id="chatkb-form" class="form-grid">
        <label class="full">Pergunta (título de referência)
          <input type="text" name="question" required value="${entry ? this._esc(entry.question) : ''}">
        </label>
        <label class="full">Palavras-chave (separadas por vírgula)
          <input type="text" name="keywords" placeholder="ex: relatorio, prazo, dashboard" value="${entry ? (entry.question_keywords || []).join(', ') : ''}">
        </label>
        <label class="full">Resposta do bot
          <textarea name="answer" rows="5" required>${entry ? this._esc(entry.answer) : ''}</textarea>
        </label>
        <label>Categoria
          <input type="text" name="categoria" value="${entry ? this._esc(entry.categoria || '') : ''}">
        </label>
        <label class="checkbox-inline">
          <input type="checkbox" name="ativo" ${!entry || entry.ativo ? 'checked' : ''}> Ativo
        </label>
        <div class="form-actions full">
          <button type="submit" class="btn btn-primary">${isEdit ? 'Salvar alterações' : 'Cadastrar'}</button>
        </div>
      </form>
    `;

    Modal.open(isEdit ? 'Editar resposta' : 'Nova resposta', html);

    document.getElementById('chatkb-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const keywords = String(fd.get('keywords') || '')
        .split(',')
        .map((k) => k.trim())
        .filter(Boolean);

      const payload = {
        question: fd.get('question'),
        question_keywords: keywords,
        answer: fd.get('answer'),
        categoria: fd.get('categoria') || null,
        ativo: fd.get('ativo') === 'on',
        updated_at: new Date().toISOString(),
      };

      let error;
      if (isEdit) {
        ({ error } = await window.supabaseClient.from('rpa_chat_knowledge_base').update(payload).eq('id', entry.id));
      } else {
        const { data: authData } = await window.supabaseClient.auth.getUser();
        payload.created_by = authData?.user?.id ?? null;
        ({ error } = await window.supabaseClient.from('rpa_chat_knowledge_base').insert(payload));
      }

      if (error) {
        toast('Erro ao salvar: ' + error.message, 'warn');
        return;
      }

      toast(isEdit ? 'Resposta atualizada.' : 'Resposta cadastrada.');
      Modal.close();
      await this._loadTable();
    });
  },

  async _delete(id) {
    if (!confirm('Remover esta resposta da base do chat?')) return;
    const { error } = await window.supabaseClient.from('rpa_chat_knowledge_base').delete().eq('id', id);
    if (error) {
      toast('Erro ao excluir: ' + error.message, 'warn');
      return;
    }
    toast('Resposta removida.');
    await this._loadTable();
  },

  _esc(str) {
    return String(str ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  },
};

window.ChatKB = ChatKB;

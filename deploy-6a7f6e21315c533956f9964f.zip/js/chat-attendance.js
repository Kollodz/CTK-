/* ============================================================================
   chat-attendance.js
   Tela de "Atendimentos" — onde Administrador/Gestor veem as conversas que
   os usuários encaminharam pra eles (via "Falar com um Gestor" no widget) e
   respondem direto pelo sistema.

   Sem esse módulo, o transbordo do chat.widget.js grava tudo certinho no
   banco (assigned_to, status, mensagens) mas ninguém do lado do gestor tem
   onde ver — por isso "a mensagem não chegava". Este arquivo resolve isso:

   1) ChatAttendance.render(container) — tela principal (lista + conversa),
      ligada ao módulo "Atendimentos" do menu.
   2) Um selo (badge) com a contagem de conversas pendentes é injetado no
      próprio botão do menu, atualizado em tempo real — assim o gestor vê que
      chegou atendimento novo mesmo estando em outra tela do sistema.

   Segue o mesmo padrão dos outros módulos (Modal, toast, .data-table já
   usados em chat-admin.js).
   ============================================================================ */

const ChatAttendance = {
  _badgeChannel: null,
  _listChannel: null,
  _msgChannel: null,
  _selectedConversationId: null,
  _currentUser: null, // { id, nome, perfil }

  // ---------------------------------------------------------------------
  // Badge no menu — roda assim que o app carrega, independente da tela
  // atual, pra avisar o gestor de atendimento novo em qualquer lugar do
  // sistema (mesmo padrão de auto-inicialização do chat-widget.js).
  // ---------------------------------------------------------------------
  async initBadge() {
    const user = typeof Auth !== 'undefined' ? Auth.currentUser() : null;
    if (!user || !['Administrador', 'Gestor'].includes(user.perfil)) return;
    this._currentUser = { id: null, nome: user.nome || user.username, perfil: user.perfil };

    const { data: authData } = await window.supabaseClient.auth.getUser();
    if (!authData?.user) return;
    this._currentUser.id = authData.user.id;

    await this._refreshBadge();

    if (this._badgeChannel) window.supabaseClient.removeChannel(this._badgeChannel);
    this._badgeChannel = window.supabaseClient
      .channel('chat-attendance-badge')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rpa_chat_conversations' }, () => this._refreshBadge())
      .subscribe();
  },

  async _refreshBadge() {
    if (!this._currentUser) return;
    const client = window.supabaseClient;

    let query = client
      .from('rpa_chat_conversations')
      .select('id', { count: 'exact', head: true })
      .in('status', ['waiting_human', 'human']);

    if (this._currentUser.perfil !== 'Administrador') {
      query = query.eq('assigned_to', this._currentUser.id);
    }

    const { count } = await query;
    const navBtn = document.querySelector('[data-module="chatattendance"]');
    if (!navBtn) return;

    let badge = navBtn.querySelector('.chat-attendance-badge');
    if (!count) {
      if (badge) badge.remove();
      return;
    }
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'chat-attendance-badge';
      navBtn.appendChild(badge);
    }
    badge.textContent = count > 99 ? '99+' : String(count);
  },

  // ---------------------------------------------------------------------
  // Tela principal
  // ---------------------------------------------------------------------
  async render(container) {
    const user = typeof Auth !== 'undefined' ? Auth.currentUser() : null;
    const podeAtender = user && ['Administrador', 'Gestor'].includes(user.perfil);

    if (!podeAtender) {
      container.innerHTML = `
        <div class="module-header"><h2>Atendimentos</h2></div>
        <p class="empty-state">Apenas Administradores e Gestores acessam os atendimentos do chat.</p>`;
      return;
    }

    if (!this._currentUser?.id) {
      const { data: authData } = await window.supabaseClient.auth.getUser();
      this._currentUser = { id: authData?.user?.id, nome: user.nome || user.username, perfil: user.perfil };
    }

    container.innerHTML = `
      <div class="module-header">
        <h2>Atendimentos do Chat</h2>
        <p class="module-subtitle">Conversas que usuários encaminharam para você (ou para a equipe) pelo widget de suporte.</p>
      </div>
      <div class="chat-attendance-layout">
        <div class="chat-attendance-list" id="chat-attendance-list">
          <div class="loading-state"><p>Carregando...</p></div>
        </div>
        <div class="chat-attendance-conversation" id="chat-attendance-conversation">
          <div class="chat-attendance-empty">Selecione uma conversa na lista ao lado.</div>
        </div>
      </div>
    `;

    await this._loadList();
    this._subscribeListRealtime();
  },

  async _loadList() {
    const listEl = document.getElementById('chat-attendance-list');
    if (!listEl) return;

    const client = window.supabaseClient;
    let query = client
      .from('rpa_chat_conversations')
      .select('id, user_nome, status, assigned_to, updated_at')
      .in('status', ['waiting_human', 'human'])
      .order('updated_at', { ascending: false });

    if (this._currentUser.perfil !== 'Administrador') {
      query = query.eq('assigned_to', this._currentUser.id);
    }

    const { data: conversations, error } = await query;

    if (error) {
      listEl.innerHTML = `<p class="empty-state">Erro ao carregar: ${error.message}</p>`;
      return;
    }

    if (!conversations || conversations.length === 0) {
      listEl.innerHTML = '<p class="empty-state">Nenhum atendimento pendente no momento.</p>';
      return;
    }

    listEl.innerHTML = conversations.map((c) => `
      <button type="button" class="chat-attendance-item ${c.id === this._selectedConversationId ? 'active' : ''}" data-id="${c.id}">
        <span class="chat-attendance-item-status status-${c.status}"></span>
        <span class="chat-attendance-item-info">
          <strong>${this._esc(c.user_nome || 'Usuário')}</strong>
          <small>${c.status === 'waiting_human' ? 'Aguardando atendimento' : 'Em atendimento'} · ${this._timeAgo(c.updated_at)}</small>
        </span>
      </button>
    `).join('');

    listEl.querySelectorAll('.chat-attendance-item').forEach((btn) => {
      btn.addEventListener('click', () => this._openConversation(btn.dataset.id));
    });
  },

  async _openConversation(conversationId) {
    this._selectedConversationId = conversationId;
    await this._loadList(); // re-renderiza pra marcar o item ativo

    const client = window.supabaseClient;
    const { data: conversation } = await client
      .from('rpa_chat_conversations')
      .select('*')
      .eq('id', conversationId)
      .maybeSingle();

    const { data: messages } = await client
      .from('rpa_chat_messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });

    const panel = document.getElementById('chat-attendance-conversation');
    panel.innerHTML = `
      <div class="chat-attendance-header">
        <div>
          <strong>${this._esc(conversation?.user_nome || 'Usuário')}</strong>
          <div class="chat-attendance-header-status">${conversation?.status === 'waiting_human' ? 'Aguardando atendimento' : conversation?.status === 'human' ? 'Em atendimento' : conversation?.status}</div>
        </div>
        <button type="button" class="btn btn-sm btn-danger" id="chat-attendance-close-btn">Encerrar atendimento</button>
      </div>
      <div class="chat-attendance-messages" id="chat-attendance-messages"></div>
      <form class="chat-attendance-form" id="chat-attendance-form">
        <input type="text" id="chat-attendance-input" placeholder="Digite sua resposta..." autocomplete="off" />
        <button type="submit" class="btn btn-primary">Enviar</button>
      </form>
    `;

    const msgBox = document.getElementById('chat-attendance-messages');
    (messages || []).forEach((m) => this._appendMessage(msgBox, m));
    msgBox.scrollTop = msgBox.scrollHeight;

    document.getElementById('chat-attendance-close-btn').addEventListener('click', () => this._closeConversation(conversationId));
    document.getElementById('chat-attendance-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this._sendReply(conversationId);
    });

    this._subscribeConversationRealtime(conversationId);
  },

  async _sendReply(conversationId) {
    const input = document.getElementById('chat-attendance-input');
    const text = input.value.trim();
    if (!text) return;
    input.value = '';

    const client = window.supabaseClient;

    await client.from('rpa_chat_messages').insert({
      conversation_id: conversationId,
      sender_type: 'admin',
      sender_auth_uid: this._currentUser.id,
      sender_nome: this._currentUser.nome,
      content: text,
    });

    // Primeira resposta do gestor confirma o atendimento como "em andamento".
    await client
      .from('rpa_chat_conversations')
      .update({ status: 'human' })
      .eq('id', conversationId)
      .eq('status', 'waiting_human');

    const msgBox = document.getElementById('chat-attendance-messages');
    if (msgBox) {
      this._appendMessage(msgBox, { sender_type: 'admin', content: text });
      msgBox.scrollTop = msgBox.scrollHeight;
    }
  },

  async _closeConversation(conversationId) {
    if (!confirm('Encerrar este atendimento?')) return;
    await window.supabaseClient
      .from('rpa_chat_conversations')
      .update({ status: 'closed' })
      .eq('id', conversationId);

    await window.supabaseClient.from('rpa_chat_messages').insert({
      conversation_id: conversationId,
      sender_type: 'admin',
      sender_auth_uid: this._currentUser.id,
      sender_nome: this._currentUser.nome,
      content: 'Atendimento encerrado.',
    });

    this._selectedConversationId = null;
    document.getElementById('chat-attendance-conversation').innerHTML =
      '<div class="chat-attendance-empty">Selecione uma conversa na lista ao lado.</div>';
    await this._loadList();
  },

  _subscribeListRealtime() {
    if (this._listChannel) window.supabaseClient.removeChannel(this._listChannel);
    this._listChannel = window.supabaseClient
      .channel('chat-attendance-list')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rpa_chat_conversations' }, () => this._loadList())
      .subscribe();
  },

  _subscribeConversationRealtime(conversationId) {
    if (this._msgChannel) window.supabaseClient.removeChannel(this._msgChannel);
    this._msgChannel = window.supabaseClient
      .channel(`chat-attendance-conv-${conversationId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'rpa_chat_messages', filter: `conversation_id=eq.${conversationId}` },
        (payload) => {
          if (payload.new.sender_type === 'admin' && payload.new.sender_auth_uid === this._currentUser.id) return;
          const msgBox = document.getElementById('chat-attendance-messages');
          if (!msgBox) return;
          this._appendMessage(msgBox, payload.new);
          msgBox.scrollTop = msgBox.scrollHeight;
        }
      )
      .subscribe();
  },

  _appendMessage(container, msg) {
    const bubble = document.createElement('div');
    const who = msg.sender_type === 'admin' ? 'me' : msg.sender_type === 'bot' ? 'bot' : 'user';
    bubble.className = `chat-attendance-bubble chat-attendance-bubble-${who}`;
    bubble.textContent = msg.content;
    container.appendChild(bubble);
  },

  _timeAgo(iso) {
    const diffMs = Date.now() - new Date(iso).getTime();
    const min = Math.floor(diffMs / 60000);
    if (min < 1) return 'agora';
    if (min < 60) return `${min} min atrás`;
    const h = Math.floor(min / 60);
    if (h < 24) return `${h}h atrás`;
    return `${Math.floor(h / 24)}d atrás`;
  },

  _esc(str) {
    return String(str ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  },
};

// Auto-inicializa o badge assim que o app carrega, igual ao chat-widget.js.
function initChatAttendanceBadge() {
  if (!window.supabaseClient) {
    setTimeout(initChatAttendanceBadge, 300);
    return;
  }
  window.supabaseClient.auth.onAuthStateChange((_event, session) => {
    if (session?.user) ChatAttendance.initBadge();
  });
  window.supabaseClient.auth.getSession().then(({ data }) => {
    if (data?.session?.user) ChatAttendance.initBadge();
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initChatAttendanceBadge);
} else {
  initChatAttendanceBadge();
}

window.ChatAttendance = ChatAttendance;

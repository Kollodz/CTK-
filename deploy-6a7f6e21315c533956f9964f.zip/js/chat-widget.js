/* ============================================================================
   chat-widget.js
   Widget de Chatbot Híbrido do MB Automation — bolha flutuante com:
   1) Atendimento automático (bot) usando a Edge Function chat-bot, que por
      sua vez consulta a knowledge_base cadastrada pelo Adm.
   2) Transbordo: usuário escolhe um gestor/administrador ativo, a conversa
      muda de status e passa a ser sincronizada em tempo real via
      supabase.channel() com quem estiver atendendo.

   Depende de (já carregados antes deste script em index.html):
     - window.supabaseClient (js/supabaseClient.js)
     - Auth (js/auth.js) — pra saber o nome do usuário logado
   ============================================================================ */

const ChatWidget = {
  _conversationId: null,
  _channel: null,
  _open: false,
  _view: 'chat', // 'chat' | 'select-gestor'
  _currentUser: null, // { id, nome }
  _STALE_CONVERSATION_MS: 4 * 60 * 60 * 1000, // 4h parado = reinicia sozinha

  _functionUrl() {
    const base = (window.supabaseClient?.supabaseUrl || '').replace(/\/$/, '');
    return `${base}/functions/v1/chat-bot`;
  },

  async init() {
    if (document.getElementById('chat-widget-root')) return;
    this._injectMarkup();
    this._bindStaticEvents();

    // Monitora eventos de auth (Login, Logout, Troca de usuário)
    window.supabaseClient.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        if (this._currentUser && this._currentUser.id !== session.user.id) {
          this._deactivate();
        }
        await this._activateForUser(session.user);
      } else {
        this._deactivate();
      }
    });

    // Cobre o carregamento inicial da página com sessão persistida (F5)
    const { data } = await window.supabaseClient.auth.getSession();
    if (data?.session?.user) {
      await this._activateForUser(data.session.user);
    } else {
      this._deactivate();
    }
  },

  async _activateForUser(user) {
    const perfil = typeof Auth !== 'undefined' ? Auth.currentUser() : null;
    this._currentUser = {
      id: user.id,
      nome: (perfil && (perfil.nome || perfil.username)) || 'Usuário',
    };

    // Exibe a bolha do chat na tela
    const root = document.getElementById('chat-widget-root');
    if (root) root.classList.remove('hidden');

    // Se o painel já estiver aberto, sincroniza a conversa do usuário
    if (this._open) {
      await this._ensureConversation();
    }
  },

  _deactivate() {
    this._currentUser = null;
    this._conversationId = null;
    if (this._channel) {
      window.supabaseClient.removeChannel(this._channel);
      this._channel = null;
    }
    
    // Esconde a bolha e fecha o painel
    const root = document.getElementById('chat-widget-root');
    if (root) root.classList.add('hidden');
    
    const panel = document.getElementById('chat-widget-panel');
    if (panel) panel.classList.add('hidden');
    
    this._open = false;

    // Limpa a tela de mensagens
    const container = document.getElementById('chat-widget-messages');
    if (container) container.innerHTML = '';
  },

  _injectMarkup() {
    const root = document.createElement('div');
    root.id = 'chat-widget-root';
    root.className = 'chat-widget-root hidden';
    root.innerHTML = `
      <button id="chat-widget-toggle" class="chat-widget-toggle" aria-label="Abrir chat de suporte">
        <span class="chat-widget-toggle-icon">💬</span>
      </button>

      <div id="chat-widget-panel" class="chat-widget-panel hidden" role="dialog" aria-label="Chat de suporte MB Automation">
        <div class="chat-widget-header">
          <div>
            <strong>Suporte MB Automation</strong>
            <div id="chat-widget-status" class="chat-widget-status">Assistente virtual</div>
          </div>
          <button id="chat-widget-close" class="chat-widget-close" aria-label="Fechar chat">&times;</button>
        </div>

        <div class="chat-widget-toolbar">
          <button type="button" id="chat-widget-restart" class="chat-widget-restart-btn">↺ Reiniciar conversa</button>
        </div>

        <div id="chat-widget-messages" class="chat-widget-messages"></div>

        <div id="chat-widget-gestores" class="chat-widget-gestores hidden"></div>

        <form id="chat-widget-form" class="chat-widget-form">
          <button type="button" id="chat-widget-human-btn" class="chat-widget-human-btn">
            Falar com um Gestor
          </button>
          <div class="chat-widget-input-row">
            <input type="text" id="chat-widget-input" placeholder="Digite sua dúvida..." autocomplete="off" />
            <button type="submit" class="chat-widget-send">Enviar</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(root);
  },

  _bindStaticEvents() {
    document.getElementById('chat-widget-toggle').addEventListener('click', () => this._togglePanel());
    document.getElementById('chat-widget-close').addEventListener('click', () => this._togglePanel(false));
    document.getElementById('chat-widget-human-btn').addEventListener('click', () => this._showGestorPicker());
    document.getElementById('chat-widget-restart').addEventListener('click', () => this._restartConversation());
    document.getElementById('chat-widget-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this._sendMessage();
    });
  },

  async _togglePanel(force) {
    if (!this._currentUser) return; // Bloqueia abertura se deslogado

    this._open = typeof force === 'boolean' ? force : !this._open;
    document.getElementById('chat-widget-panel').classList.toggle('hidden', !this._open);
    if (this._open) {
      await this._ensureConversation();
    }
  },

  async _ensureConversation() {
    if (!this._currentUser) return;
    const client = window.supabaseClient;

    // Busca conversas ativas do usuário logado
    const { data: existing } = await client
      .from('rpa_chat_conversations')
      .select('id, status, updated_at')
      .eq('user_auth_uid', this._currentUser.id)
      .neq('status', 'closed')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    // Conversa parada há muito tempo sem nenhuma atividade (ninguém respondeu,
    // usuário sumiu etc.) é encerrada automaticamente e uma nova é iniciada —
    // evita o usuário ficar preso pra sempre numa conversa morta.
    let usable = existing;
    if (existing) {
      const lastActivityMs = new Date(existing.updated_at).getTime();
      const idleMs = Date.now() - lastActivityMs;
      if (idleMs > this._STALE_CONVERSATION_MS) {
        await client
          .from('rpa_chat_conversations')
          .update({ status: 'closed' })
          .eq('id', existing.id);
        usable = null;
      }
    }

    if (usable) {
      this._conversationId = usable.id;
      await this._loadHistory();
      this._setStatusLabel(usable.status);
    } else {
      // Cria uma nova conversa vinculada ao user_auth_uid atual
      const { data: created, error } = await client
        .from('rpa_chat_conversations')
        .insert({ user_auth_uid: this._currentUser.id, user_nome: this._currentUser.nome })
        .select()
        .single();

      if (error) {
        console.error('Erro ao criar conversa:', error);
        this._appendSystemNote('Não foi possível iniciar o atendimento agora. Tente novamente em instantes.');
        return;
      }

      this._conversationId = created.id;
      await this._loadHistory();
    }

    this._subscribeRealtime();
  },

  async _loadHistory() {
    const { data: messages } = await window.supabaseClient
      .from('rpa_chat_messages')
      .select('*')
      .eq('conversation_id', this._conversationId)
      .order('created_at', { ascending: true });

    const container = document.getElementById('chat-widget-messages');
    if (!container) return;
    container.innerHTML = '';

    // 1. Sempre exibe a mensagem de boas-vindas no topo ao carregar o chat
    this._appendMessage({
      sender_type: 'bot',
      content: `Olá, ${this._currentUser.nome}! Sou o assistente virtual do MB Automation. Como posso ajudar? Se preferir, clique em "Falar com um Gestor" para atendimento humano.`,
    }, false);

    // 2. Renderiza as mensagens trocadas anteriormente (se houver)
    (messages || []).forEach((m) => this._appendMessage(m, false));
    container.scrollTop = container.scrollHeight;
  },

  _subscribeRealtime() {
    if (this._channel) window.supabaseClient.removeChannel(this._channel);

    this._channel = window.supabaseClient
      .channel(`chat-conversation-${this._conversationId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'rpa_chat_messages',
          filter: `conversation_id=eq.${this._conversationId}`,
        },
        (payload) => {
          if (payload.new.sender_auth_uid === this._currentUser?.id && payload.new.sender_type === 'user') return;
          this._appendMessage(payload.new);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'rpa_chat_conversations',
          filter: `id=eq.${this._conversationId}`,
        },
        (payload) => this._setStatusLabel(payload.new.status)
      )
      .subscribe();
  },

  async _showGestorPicker() {
    this._view = 'select-gestor';
    const box = document.getElementById('chat-widget-gestores');
    box.classList.remove('hidden');
    box.innerHTML = '<div class="chat-widget-gestores-loading">Carregando gestores disponíveis...</div>';

    const { data: gestores, error } = await window.supabaseClient
      .from('rpa_chat_gestores_disponiveis')
      .select('*');

    if (error || !gestores || gestores.length === 0) {
      box.innerHTML = '<div class="chat-widget-gestores-empty">Nenhum gestor disponível no momento. Deixe sua mensagem que retornaremos assim que possível.</div>';
      return;
    }

    box.innerHTML = `
      <div class="chat-widget-gestores-title">Escolha com quem deseja falar:</div>
      <div class="chat-widget-gestores-list">
        ${gestores.map((g) => `
          <button type="button" class="chat-widget-gestor-card" data-auth-uid="${g.auth_uid}" data-nome="${g.nome}">
            <span class="chat-widget-gestor-status ${g.disponibilidade === 'online' ? 'online' : 'offline'}"></span>
            <span class="chat-widget-gestor-nome">${g.nome}</span>
            <span class="chat-widget-gestor-perfil">${g.perfil}</span>
          </button>
        `).join('')}
      </div>
    `;

    box.querySelectorAll('.chat-widget-gestor-card').forEach((btn) => {
      btn.addEventListener('click', () => this._assignGestor(btn.dataset.authUid, btn.dataset.nome));
    });
  },

  async _assignGestor(gestorAuthUid, gestorNome) {
    const client = window.supabaseClient;

    await client
      .from('rpa_chat_conversations')
      .update({ assigned_to: gestorAuthUid, status: 'waiting_human' })
      .eq('id', this._conversationId);

    await client.from('rpa_chat_messages').insert({
      conversation_id: this._conversationId,
      sender_type: 'bot',
      content: `Encaminhando para ${gestorNome}. Aguarde só um instante — assim que ${gestorNome} entrar na conversa, vocês falam por aqui mesmo.`,
    });

    document.getElementById('chat-widget-gestores').classList.add('hidden');
    this._view = 'chat';
    this._setStatusLabel('waiting_human');
  },

  _setStatusLabel(status) {
    const el = document.getElementById('chat-widget-status');
    const labels = {
      bot: 'Assistente virtual',
      waiting_human: 'Aguardando gestor...',
      human: 'Atendimento humano',
      closed: 'Conversa encerrada',
    };
    el.textContent = labels[status] || '';
  },

  async _sendMessage() {
    const input = document.getElementById('chat-widget-input');
    const text = input.value.trim();
    if (!text || !this._conversationId || !this._currentUser) return;
    input.value = '';

    this._appendMessage({ sender_type: 'user', content: text, sender_auth_uid: this._currentUser.id });

    const { data: conversation } = await window.supabaseClient
      .from('rpa_chat_conversations')
      .select('status')
      .eq('id', this._conversationId)
      .maybeSingle();

    if (conversation && conversation.status !== 'bot') {
      await window.supabaseClient.from('rpa_chat_messages').insert({
        conversation_id: this._conversationId,
        sender_type: 'user',
        sender_auth_uid: this._currentUser.id,
        content: text,
      });
      return;
    }

    try {
      const { data: sessionData } = await window.supabaseClient.auth.getSession();
      const token = sessionData?.session?.access_token;

      const res = await fetch(this._functionUrl(), {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ conversation_id: this._conversationId, message: text }),
      });

      if (!res.ok) throw new Error('Falha ao consultar o assistente.');

    } catch (err) {
      console.error('[ChatWidget] erro ao enviar mensagem:', err);
      this._appendSystemNote('Não consegui responder agora. Tente novamente ou fale com um gestor.');
    }
  },

  async _restartConversation() {
    if (!this._conversationId) return;
    if (!confirm('Encerrar a conversa atual e começar uma nova?')) return;

    await window.supabaseClient
      .from('rpa_chat_conversations')
      .update({ status: 'closed' })
      .eq('id', this._conversationId);

    if (this._channel) {
      window.supabaseClient.removeChannel(this._channel);
      this._channel = null;
    }
    this._conversationId = null;
    document.getElementById('chat-widget-gestores').classList.add('hidden');
    await this._ensureConversation();
  },

  _appendMessage(msg, scroll = true) {
    const container = document.getElementById('chat-widget-messages');
    if (!container) return;
    const bubble = document.createElement('div');
    const who = msg.sender_type === 'user' ? 'me' : msg.sender_type === 'admin' ? 'admin' : 'bot';
    bubble.className = `chat-widget-bubble chat-widget-bubble-${who}`;
    bubble.textContent = msg.content;
    container.appendChild(bubble);
    if (scroll) container.scrollTop = container.scrollHeight;
  },

  _appendSystemNote(text) {
    this._appendMessage({ sender_type: 'bot', content: text });
  },
};

function initChatWidget() {
  if (!window.supabaseClient) {
    setTimeout(initChatWidget, 200);
    return;
  }
  ChatWidget.init();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initChatWidget);
} else {
  initChatWidget();
}

window.ChatWidget = ChatWidget;
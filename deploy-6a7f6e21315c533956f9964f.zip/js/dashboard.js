/* ============================================================================
   dashboard.js
   Módulo 1 - Dashboard Executivo
   Gráficos renderizados pelo motor nativo MiniChart (charts.js), todos com
   tooltip detalhado ao passar o mouse — sem dependência externa, 100% offline.
   ============================================================================ */

const Dashboard = {

  async render(container) {
    const rawProjects = await Store.get('projects', []);
    const projects = Array.isArray(rawProjects) ? rawProjects : [];

    const producao = projects.filter(p => p.status === 'Produção');
    const rawDiscovery = await Store.get('discovery', []);
    const discoveryList = Array.isArray(rawDiscovery) ? rawDiscovery : [];
    const discovery = discoveryList.filter(d => !d.projetoGeradoId);
    const desenvolvimento = projects.filter(p => p.status === 'Desenvolvimento');
    const ativos = projects.filter(p => p.status !== 'Cancelado');

    let horasEconomizadasMes = 0, economiaMensal = 0, economiaAnual = 0, roiSum = 0, roiCount = 0, paybackSum = 0, paybackCount = 0;
    producao.forEach(p => {
      const bc = Calc.businessCase(p);
      horasEconomizadasMes += bc.horasEconomizadasMes;
      economiaMensal += bc.economiaMensal;
      economiaAnual += bc.economiaAnual;
      roiSum += bc.roiPercent; roiCount++;
      if (bc.paybackMeses) { paybackSum += bc.paybackMeses; paybackCount++; }
    });

    const taxaSucesso = ativos.length ? round1((producao.length / ativos.length) * 100) : 0;
    const totalAprovacoes = Object.keys({ sponsor: 1, ti: 1, seguranca: 1, compliance: 1, lgpd: 1 }).length;
    const totalmenteAprovados = ativos.filter(p => p.aprovacoes && Object.values(p.aprovacoes).filter(Boolean).length === totalAprovacoes).length;
    const taxaAprovacao = ativos.length ? round1((totalmenteAprovados / ativos.length) * 100) : 0;

    container.innerHTML = `
      <div class="module-header">
        <h2>Dashboard Executivo</h2>
        <p class="module-subtitle">Visão consolidada do portfólio de automações — passe o mouse sobre os gráficos para ver detalhes</p>
      </div>

      <div class="kpi-grid">
        ${kpiCard('Total de Projetos', projects.length, '📁')}
        ${kpiCard('Em Discovery', discovery.length, '🔎')}
        ${kpiCard('Em Desenvolvimento', desenvolvimento.length, '🛠️', 'kpi-blue')}
        ${kpiCard('Em Produção', producao.length, '✅', 'kpi-green')}
        ${kpiCard('Horas Economizadas/mês', horasEconomizadasMes.toLocaleString('pt-BR'), '⏱️')}
        ${kpiCard('Economia Mensal', formatBRL(economiaMensal), '💰', 'kpi-green')}
        ${kpiCard('Economia Anual', formatBRL(economiaAnual), '💵', 'kpi-green')}
        ${kpiCard('ROI Médio', (roiCount ? round1(roiSum / roiCount) : 0) + '%', '📈')}
        ${kpiCard('Payback Médio', (paybackCount ? round1(paybackSum / paybackCount) : 0) + ' meses', '⏳')}
        ${kpiCard('Taxa de Sucesso', taxaSucesso + '%', '🏆', 'kpi-blue')}
        ${kpiCard('Taxa de Aprovação', taxaAprovacao + '%', '🛡️')}
      </div>

      <div class="chart-grid">
        <div class="chart-card"><h3>Pipeline por Status</h3><canvas id="chart-status"></canvas></div>
        <div class="chart-card"><h3>Projetos por Área</h3><canvas id="chart-area"></canvas></div>
        <div class="chart-card"><h3>Economia por Área</h3><canvas id="chart-economia-area"></canvas></div>
        <div class="chart-card"><h3>Top 10 Projetos por Economia</h3><canvas id="chart-economia-projeto"></canvas></div>
        <div class="chart-card"><h3>ROI por Projeto (Top 10)</h3><canvas id="chart-roi-projeto"></canvas></div>
        <div class="chart-card chart-wide"><h3>Evolução da Economia Mensal (Acumulada)</h3><canvas id="chart-evolucao"></canvas></div>
        <div class="chart-card"><h3>Evolução Mensal de Projetos Cadastrados</h3><canvas id="chart-evolucao-projetos"></canvas></div>
        <div class="chart-card"><h3>Pipeline de Demandas (Funil)</h3><canvas id="chart-pipeline"></canvas></div>
        <div class="chart-card"><h3>Matriz Esforço x Benefício</h3><canvas id="chart-esforco-beneficio"></canvas></div>
      </div>
    `;

    // Pequeno delay para garantir que os canvases já têm largura/altura no layout antes de desenhar
    requestAnimationFrame(() => this.renderCharts(projects, producao, discovery));
  },

  renderCharts(projects, producao, discoveryList = []) {
    const palette = ['#3c547c', '#69aa02', '#BEF91B', '#C3CEE1', '#000E19', '#F59E0B', '#EF4444', '#94A3B8'];

    // Pipeline por status
    const statusOrder = ['Ideia', 'Triagem', 'Discovery', 'Business Case', 'Desenvolvimento', 'Testes', 'UAT', 'Implantação', 'Produção', 'Cancelado'];
    const statusCounts = statusOrder.map(s => s === 'Discovery' ? discoveryList.length : projects.filter(p => p.status === s).length);
MiniChart.bar(document.getElementById('chart-status'), {
  labels: statusOrder, values: statusCounts, color: '#3c547c',
  tooltip: (i) => {
    const isDiscovery = statusOrder[i] === 'Discovery';
    const nomes = isDiscovery ? discoveryList.map(d => d.nomeIdeia) : projects.filter(p => p.status === statusOrder[i]).map(p => p.nome);
        const lista = nomes.length ? (nomes.slice(0, 4).join(', ') + (nomes.length > 4 ? ` e mais ${nomes.length - 4}` : '')) : '—';
        return MiniChart.tooltipHtml(statusOrder[i], [['Quantidade', statusCounts[i]], ['Projetos', lista]]);
      }
    });

    // Projetos por área
    const areas = [...new Set(projects.map(p => p.area))];
    const areaCounts = areas.map(a => projects.filter(p => p.area === a).length);
    MiniChart.doughnut(document.getElementById('chart-area'), { labels: areas, values: areaCounts, colors: palette });

    // Economia por área (apenas produção)
    const economiaPorArea = areas.map(a => round0(producao.filter(p => p.area === a).reduce((sum, p) => sum + Calc.businessCase(p).economiaAnual, 0)));
    MiniChart.bar(document.getElementById('chart-economia-area'), {
      labels: areas, values: economiaPorArea, color: '#69aa02', valueFormatter: (v) => formatCompactBRL(v),
      tooltip: (i) => {
        const qtd = producao.filter(p => p.area === areas[i]).length;
        return MiniChart.tooltipHtml(areas[i], [['Economia anual', formatBRL(economiaPorArea[i])], ['Projetos em produção', qtd]]);
      }
    });

    // Top 10 projetos por economia
    const projByEconomia = [...projects]
      .map(p => ({ p, economia: Calc.businessCase(p).economiaAnual }))
      .sort((a, b) => b.economia - a.economia)
      .slice(0, 10);
    MiniChart.bar(document.getElementById('chart-economia-projeto'), {
      labels: projByEconomia.map(x => x.p.nome), values: projByEconomia.map(x => x.economia),
      color: '#69aa02', horizontal: true, valueFormatter: (v) => formatCompactBRL(v),
      tooltip: (i) => MiniChart.tooltipHtml(projByEconomia[i].p.nome, projectTooltipRows(projByEconomia[i].p))
    });

    // ROI por projeto (top 10)
    const projByRoi = [...projects]
      .map(p => ({ p, roi: Calc.businessCase(p).roiPercent }))
      .sort((a, b) => b.roi - a.roi)
      .slice(0, 10);
    MiniChart.bar(document.getElementById('chart-roi-projeto'), {
      labels: projByRoi.map(x => x.p.nome), values: projByRoi.map(x => x.roi),
      color: '#3c547c', horizontal: true, valueFormatter: (v) => v + '%',
      tooltip: (i) => MiniChart.tooltipHtml(projByRoi[i].p.nome, projectTooltipRows(projByRoi[i].p))
    });

    // Evolução da economia mensal acumulada (baseada na economia mensal atual dos projetos em produção)
    const meses = lastMonthsLabels(6);
    const totalMensal = producao.reduce((sum, p) => sum + Calc.businessCase(p).economiaMensal, 0);
    const evolucao = meses.map((_, idx) => round0(totalMensal * ((idx + 1) / meses.length)));
    MiniChart.line(document.getElementById('chart-evolucao'), {
      labels: meses, values: evolucao, color: '#69aa02', fill: true, valueFormatter: (v) => formatCompactBRL(v),
      tooltip: (i) => MiniChart.tooltipHtml(meses[i], [['Economia acumulada', formatBRL(evolucao[i])]])
    });

    // Evolução mensal de projetos cadastrados (contagem por mês de dataSolicitacao)
    const projPorMes = countProjectsByMonth(projects, 6);
    MiniChart.bar(document.getElementById('chart-evolucao-projetos'), {
      labels: meses, values: projPorMes, color: '#3c547c',
      tooltip: (i) => MiniChart.tooltipHtml(meses[i], [['Novos projetos', projPorMes[i]]])
    });

    // Pipeline de demandas (funil simplificado)
    const funilLabels = ['Ideia', 'Triagem', 'Discovery', 'Business Case', 'Desenvolvimento', 'Produção'];
    const funilData = funilLabels.map(s => s === 'Discovery' ? discoveryList.length : projects.filter(p => p.status === s).length);
    MiniChart.bar(document.getElementById('chart-pipeline'), {
      labels: funilLabels, values: funilData, color: '#3c547c', horizontal: true,
      tooltip: (i) => MiniChart.tooltipHtml(funilLabels[i], [['Quantidade', funilData[i]]])
    });

    // Matriz Esforço x Benefício (scatter) — esforço (1-8, campo de priorização) x economia anual
    const scatterData = projects.map(p => ({ x: Number(p.effort) || 3, y: Calc.businessCase(p).economiaAnual, p }));
    MiniChart.scatter(document.getElementById('chart-esforco-beneficio'), {
      points: scatterData, color: '#F59E0B', xLabel: 'Esforço (1 = baixo, 8 = alto)', xMax: 8,
      tooltip: (pt) => MiniChart.tooltipHtml(pt.p.nome, projectTooltipRows(pt.p))
    });
  }
};

function projectTooltipRows(p) {
  const bc = Calc.businessCase(p);
  const score = Calc.scoreCorporativo(p);
  return [
    ['Área', p.area || '-'],
    ['Status', p.status || '-'],
    ['Complexidade', p.complexidade || '-'],
    ['Score de Priorização', score],
    ['ROI', bc.roiPercent + '%'],
    ['Economia anual', formatBRL(bc.economiaAnual)],
    ['Horas econ./mês', bc.horasEconomizadasMes],
    ['Criado em', formatDateBR(p.dataSolicitacao)]
  ];
}

function formatDateBR(iso) {
  if (!iso) return '-';
  const parts = String(iso).slice(0, 10).split('-');
  if (parts.length !== 3) return iso;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

function countProjectsByMonth(projects, n) {
  const now = new Date();
  const buckets = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    buckets.push({ y: d.getFullYear(), m: d.getMonth(), count: 0 });
  }
  projects.forEach(p => {
    if (!p.dataSolicitacao) return;
    const parts = String(p.dataSolicitacao).slice(0, 10).split('-');
    if (parts.length !== 3) return;
    const y = Number(parts[0]), m = Number(parts[1]) - 1;
    const bucket = buckets.find(b => b.y === y && b.m === m);
    if (bucket) bucket.count++;
  });
  return buckets.map(b => b.count);
}

function kpiCard(label, value, icon, extraClass = '') {
  return `
    <div class="kpi-card ${extraClass}">
      <div class="kpi-icon">${icon}</div>
      <div class="kpi-content">
        <div class="kpi-value">${value}</div>
        <div class="kpi-label">${Sanitize.html(label)}</div>
      </div>
    </div>`;
}

function truncate(str, n) {
  return str.length > n ? str.slice(0, n - 1) + '…' : str;
}

function formatCompactBRL(n) {
  const v = Number(n) || 0;
  if (Math.abs(v) >= 1000000) return 'R$ ' + (v / 1000000).toFixed(1).replace('.', ',') + 'M';
  if (Math.abs(v) >= 1000) return 'R$ ' + (v / 1000).toFixed(1).replace('.', ',') + 'k';
  return 'R$ ' + v.toFixed(0);
}

function lastMonthsLabels(n) {
  const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  const now = new Date();
  const arr = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    arr.push(months[d.getMonth()] + '/' + String(d.getFullYear()).slice(-2));
  }
  return arr;
}
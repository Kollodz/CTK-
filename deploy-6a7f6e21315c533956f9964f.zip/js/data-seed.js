/* ============================================================================
   data-seed.js
   Dados de exemplo carregados na primeira execução do sistema.
   Também existem cópias equivalentes em /data/*.json apenas como referência
   de formato para integrações futuras (não são lidas via fetch por causa da
   restrição de CORS do protocolo file:// em navegadores).
   ============================================================================ */

const SEED_PROJECTS = [
  {
    id: 'PRJ-0001',
    nome: 'Automação de Conciliação Bancária',
    area: 'Financeiro',
    processo: 'Conciliação de extratos e lançamentos contábeis',
    solicitante: 'Ana Ferreira',
    sponsor: 'Diretoria Financeira',
    responsavel: 'Carlos Souza',
    dataSolicitacao: '2026-01-10',
    dataAprovacao: '2026-01-20',
    status: 'Produção',
    complexidade: 'Média',
    tecnologia: 'UiPath',
    impacto: 5, urgencia: 4, volume: 5, riscoScore: 2, alinhamento: 5,
    reach: 800, confidence: 90, effort: 3,
    horasAtuais: 4, horasPorExecucao: 0.3, execucoesPorDia: 12, execucoesPorSemana: 60,
    valorHora: 65,
    aprovacoes: { sponsor: true, ti: true, seguranca: true, compliance: true, lgpd: true },
    historico: [
      { data: '2026-01-10', evento: 'Solicitação registrada' },
      { data: '2026-01-20', evento: 'Aprovado pelo Sponsor' },
      { data: '2026-03-15', evento: 'Entrou em produção' }
    ]
  },
  {
    id: 'PRJ-0002',
    nome: 'Emissão Automática de Notas Fiscais',
    area: 'Comercial',
    processo: 'Emissão de NF-e a partir de pedidos aprovados',
    solicitante: 'Bruno Lima',
    sponsor: 'Diretoria Comercial',
    responsavel: 'Marina Alves',
    dataSolicitacao: '2026-02-01',
    dataAprovacao: '2026-02-10',
    dataPrevisaoFinalizacao: '2026-08-15',
    status: 'Desenvolvimento',
    complexidade: 'Alta',
    tecnologia: 'Power Automate Desktop',
    impacto: 4, urgencia: 5, volume: 4, riscoScore: 3, alinhamento: 4,
    reach: 500, confidence: 80, effort: 5,
    horasAtuais: 3, horasPorExecucao: 0.25, execucoesPorDia: 20, execucoesPorSemana: 100,
    valorHora: 60,
    aprovacoes: { sponsor: true, ti: true, seguranca: false, compliance: false, lgpd: true },
    historico: [
      { data: '2026-02-01', evento: 'Solicitação registrada' },
      { data: '2026-02-10', evento: 'Aprovado pelo Sponsor' }
    ]
  },
  {
    id: 'PRJ-0003',
    nome: 'Validação de Cadastro de Fornecedores',
    area: 'Compras',
    processo: 'Checagem de documentos e status de fornecedores',
    solicitante: 'Rafael Nunes',
    sponsor: 'Diretoria de Suprimentos',
    responsavel: 'Carlos Souza',
    dataSolicitacao: '2026-03-05',
    dataAprovacao: '',
    dataPrevisaoFinalizacao: '2026-09-30',
    status: 'Business Case',
    complexidade: 'Baixa',
    tecnologia: 'Python',
    impacto: 3, urgencia: 2, volume: 3, riscoScore: 2, alinhamento: 3,
    reach: 200, confidence: 70, effort: 2,
    horasAtuais: 2, horasPorExecucao: 0.2, execucoesPorDia: 8, execucoesPorSemana: 40,
    valorHora: 55,
    aprovacoes: { sponsor: false, ti: false, seguranca: false, compliance: false, lgpd: false },
    historico: [{ data: '2026-03-05', evento: 'Solicitação registrada' }]
  },
  {
    id: 'PRJ-0004',
    nome: 'Robô de Onboarding de Colaboradores',
    area: 'Recursos Humanos',
    processo: 'Criação de acessos e envio de documentação admissional',
    solicitante: 'Juliana Costa',
    sponsor: 'Diretoria de RH',
    responsavel: 'Marina Alves',
    dataSolicitacao: '2026-01-25',
    dataAprovacao: '2026-02-05',
    dataPrevisaoFinalizacao: '2026-07-10',
    status: 'Testes',
    complexidade: 'Média',
    tecnologia: 'UiPath',
    impacto: 4, urgencia: 3, volume: 2, riscoScore: 2, alinhamento: 4,
    reach: 120, confidence: 85, effort: 3,
    horasAtuais: 1.5, horasPorExecucao: 0.4, execucoesPorDia: 3, execucoesPorSemana: 15,
    valorHora: 58,
    aprovacoes: { sponsor: true, ti: true, seguranca: true, compliance: true, lgpd: true },
    historico: [
      { data: '2026-01-25', evento: 'Solicitação registrada' },
      { data: '2026-02-05', evento: 'Aprovado pelo Sponsor' },
      { data: '2026-05-01', evento: 'Iniciados testes' }
    ]
  },
  {
    id: 'PRJ-0005',
    nome: 'Extração de Dados de Contratos',
    area: 'Jurídico',
    processo: 'Leitura e extração de cláusulas de contratos em PDF',
    solicitante: 'Fernanda Dias',
    sponsor: 'Diretoria Jurídica',
    responsavel: 'Carlos Souza',
    dataSolicitacao: '2026-04-01',
    dataAprovacao: '',
    status: 'Triagem',
    complexidade: 'Muito Alta',
    tecnologia: 'Python',
    impacto: 3, urgencia: 2, volume: 2, riscoScore: 4, alinhamento: 2,
    reach: 90, confidence: 50, effort: 8,
    horasAtuais: 5, horasPorExecucao: 0.5, execucoesPorDia: 4, execucoesPorSemana: 20,
    valorHora: 70,
    aprovacoes: { sponsor: false, ti: false, seguranca: false, compliance: false, lgpd: false },
    historico: [{ data: '2026-04-01', evento: 'Solicitação registrada' }]
  },
  {
    id: 'PRJ-0006',
    nome: 'Baixa Automática de Pagamentos',
    area: 'Financeiro',
    processo: 'Baixa de títulos no ERP a partir de comprovantes',
    solicitante: 'Ana Ferreira',
    sponsor: 'Diretoria Financeira',
    responsavel: 'Marina Alves',
    dataSolicitacao: '2025-11-10',
    dataAprovacao: '2025-11-20',
    status: 'Produção',
    complexidade: 'Baixa',
    tecnologia: 'Power Automate',
    impacto: 5, urgencia: 5, volume: 5, riscoScore: 1, alinhamento: 5,
    reach: 600, confidence: 95, effort: 2,
    horasAtuais: 3, horasPorExecucao: 0.15, execucoesPorDia: 25, execucoesPorSemana: 125,
    valorHora: 65,
    aprovacoes: { sponsor: true, ti: true, seguranca: true, compliance: true, lgpd: true },
    historico: [
      { data: '2025-11-10', evento: 'Solicitação registrada' },
      { data: '2025-11-20', evento: 'Aprovado pelo Sponsor' },
      { data: '2026-01-05', evento: 'Entrou em produção' }
    ]
  },
  {
    id: 'PRJ-0007',
    nome: 'Monitoramento de SLA de Chamados',
    area: 'TI',
    processo: 'Alertas automáticos de chamados próximos do vencimento',
    solicitante: 'Rafael Nunes',
    sponsor: 'Diretoria de TI',
    responsavel: 'Carlos Souza',
    dataSolicitacao: '2026-05-01',
    dataAprovacao: '',
    status: 'Ideia',
    complexidade: 'Baixa',
    tecnologia: 'Power Automate',
    impacto: 2, urgencia: 3, volume: 3, riscoScore: 1, alinhamento: 3,
    reach: 150, confidence: 60, effort: 1,
    horasAtuais: 1, horasPorExecucao: 0.1, execucoesPorDia: 10, execucoesPorSemana: 50,
    valorHora: 55,
    aprovacoes: { sponsor: false, ti: false, seguranca: false, compliance: false, lgpd: false },
    historico: [{ data: '2026-05-01', evento: 'Solicitação registrada' }]
  },
  {
    id: 'PRJ-0008',
    nome: 'Cancelado - Robô de Cobrança WhatsApp',
    area: 'Financeiro',
    processo: 'Envio de cobranças via WhatsApp',
    solicitante: 'Bruno Lima',
    sponsor: 'Diretoria Financeira',
    responsavel: 'Marina Alves',
    dataSolicitacao: '2025-09-01',
    dataAprovacao: '',
    status: 'Cancelado',
    complexidade: 'Alta',
    tecnologia: 'Outro',
    impacto: 2, urgencia: 1, volume: 2, riscoScore: 5, alinhamento: 1,
    reach: 300, confidence: 40, effort: 6,
    horasAtuais: 2, horasPorExecucao: 0.1, execucoesPorDia: 15, execucoesPorSemana: 75,
    valorHora: 60,
    aprovacoes: { sponsor: false, ti: false, seguranca: false, compliance: false, lgpd: false },
    historico: [
      { data: '2025-09-01', evento: 'Solicitação registrada' },
      { data: '2025-10-15', evento: 'Cancelado por risco de LGPD' }
    ]
  }
];

const SEED_TEAM = [
  { id: 'DEV-01', nome: 'Carlos Souza', papel: 'Desenvolvedor', horasDisponiveis: 160, horasAlocadas: 140, horasConsumidas: 95 },
  { id: 'DEV-02', nome: 'Marina Alves', papel: 'Desenvolvedor', horasDisponiveis: 160, horasAlocadas: 150, horasConsumidas: 130 },
  { id: 'ANA-01', nome: 'Juliana Costa', papel: 'Analista', horasDisponiveis: 160, horasAlocadas: 100, horasConsumidas: 80 },
  { id: 'PO-01', nome: 'Fernanda Dias', papel: 'Product Owner', horasDisponiveis: 160, horasAlocadas: 90, horasConsumidas: 60 },
  { id: 'GST-01', nome: 'Rafael Nunes', papel: 'Gestor', horasDisponiveis: 160, horasAlocadas: 60, horasConsumidas: 55 }
];

const SEED_RISKS = [
  { id: 'RSK-0001', projetoId: 'PRJ-0002', risco: 'Indisponibilidade da API da SEFAZ', probabilidade: 3, impacto: 4, mitigacao: 'Implementar fila de reprocessamento com retentativas', responsavel: 'Marina Alves' },
  { id: 'RSK-0002', projetoId: 'PRJ-0005', risco: 'Baixa acurácia na extração de cláusulas variáveis', probabilidade: 4, impacto: 4, mitigacao: 'Validação humana amostral (human-in-the-loop)', responsavel: 'Carlos Souza' },
  { id: 'RSK-0003', projetoId: 'PRJ-0001', risco: 'Mudança no layout do extrato bancário', probabilidade: 2, impacto: 3, mitigacao: 'Monitoramento de falhas com alerta automático', responsavel: 'Carlos Souza' },
  { id: 'RSK-0004', projetoId: 'PRJ-0008', risco: 'Tratamento de dados pessoais sem base legal', probabilidade: 4, impacto: 5, mitigacao: 'Projeto cancelado até revisão jurídica', responsavel: 'Fernanda Dias' }
];

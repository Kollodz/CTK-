/* ============================================================================
   discovery.js
   Tela de Discovery Self-Service
   ============================================================================ */

const FREQUENCIA_OPCOES = ['Várias vezes por dia', 'Diariamente', 'Semanalmente', 'Mensalmente'];

// Bucket do Supabase Storage onde ficam salvas as gravações de tela do
// Discovery. Precisa existir (ver sql/004_discovery_gravacoes_storage.sql).
const DISCOVERY_GRAVACOES_BUCKET = 'discovery-gravacoes';

const Discovery = {
  view: 'form',
  step: 1,
  draft: {},
  lastResult: null,

  // Estado da gravação de tela (independente do step do wizard, pra não se
  // perder quando o usuário navega entre as etapas).
  recording: {
    status: 'idle', // idle | recording | uploading | done | error
    mediaRecorder: null,
    stream: null,
    chunks: [],
    startedAt: null,
    elapsedSeconds: 0,
    timerHandle: null,
    videoUrl: null,
    errorMsg: null
  },

  // Helpers defensivos para garantir retornos em Array
  getProjectsArray() {
    const raw = Store.get('projects', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.projects)) return raw.projects;
    return [];
  },

  getDiscoveryArray() {
    const raw = Store.get('discovery', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.discovery)) return raw.discovery;
    return [];
  },

  render(container) {
    if (!container) return;

    const podeVerTodas = typeof Auth !== 'undefined' && Auth.permissao && Auth.permissao('podeEditar');

    container.innerHTML = `
      <div class="module-header">
        <h2>💡 Discovery — Envie sua Ideia de Automação</h2>
        <p class="module-subtitle">Conte pra gente um processo repetitivo do seu dia a dia. Leva menos de 5 minutos.</p>
      </div>
      <div class="disc-tabs">
        <button class="disc-tab ${this.view === 'form' ? 'active' : ''}" id="disc-tab-form">📝 Nova Ideia</button>
        <button class="disc-tab ${this.view === 'list' ? 'active' : ''}" id="disc-tab-list">📋 ${podeVerTodas ? 'Todas as Ideias' : 'Minhas Ideias'}</button>
      </div>
      <div id="disc-content"></div>
    `;

    const tabForm = document.getElementById('disc-tab-form');
    if (tabForm) {
      tabForm.addEventListener('click', () => { 
        this.view = 'form'; this.step = 1; this.draft = {}; this.lastResult = null; this.resetRecording(); this.render(container); 
      });
    }

    const tabList = document.getElementById('disc-tab-list');
    if (tabList) {
      tabList.addEventListener('click', () => { 
        this.view = 'list'; this.render(container); 
      });
    }

    const contentEl = document.getElementById('disc-content');
    if (contentEl) {
      if (this.view === 'form') this.renderWizard(contentEl);
      else this.renderList(contentEl);
    }
  },

  renderWizard(el) {
    if (!el) return;
    if (this.lastResult) return this.renderFeedback(el);

    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;
    const d = this.draft;
    const pct = (this.step / 4) * 100;

    el.innerHTML = `
      <div class="wizard-card">
        ${this.recordingWidgetHtml()}
        <div class="wizard-progress-label">Etapa ${this.step} de 4</div>
        <div class="wizard-progress"><div class="wizard-progress-fill" style="width:${pct}%"></div></div>
        <form id="disc-step-form">
          ${this['stepHtml' + this.step](d, user)}
          <div class="wizard-actions">
            ${this.step > 1 ? '<button type="button" class="btn btn-ghost" id="disc-back">← Voltar</button>' : '<span></span>'}
            <button type="submit" class="btn btn-primary">${this.step < 4 ? 'Próximo →' : '✓ Enviar Ideia'}</button>
          </div>
        </form>
      </div>
    `;

    this.bindRecordingWidget(el);
    this.bindConditionalFields(el);

    const btnBack = document.getElementById('disc-back');
    if (btnBack) {
      btnBack.addEventListener('click', () => { 
        this.saveStep(); this.step--; this.renderWizard(el); 
      });
    }

    const stepForm = document.getElementById('disc-step-form');
    if (stepForm) {
      stepForm.addEventListener('click', (e) => {});
      stepForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!this.saveStep()) return;
        if (this.step < 4) { this.step++; this.renderWizard(el); }
        else this.finish(el);
      });
    }
  },

  bindConditionalFields(el) {
    if (!el) return;
    const usaSistemas = el.querySelectorAll('input[name="usaSistemas"]');
    if (usaSistemas.length) {
      const toggle = () => {
        const val = el.querySelector('input[name="usaSistemas"]:checked');
        const wrap = el.querySelector('#disc-quais-sistemas-wrap');
        if (wrap) wrap.classList.toggle('hidden', !val || val.value !== 'Sim');
      };
      usaSistemas.forEach(r => r.addEventListener('change', toggle));
      toggle();
    }
    const freq = el.querySelector('select[name="frequencia"]');
    if (freq) {
      const toggle = () => {
        const wrap = el.querySelector('#disc-vezes-dia-wrap');
        if (wrap) wrap.classList.toggle('hidden', freq.value !== 'Várias vezes por dia');
      };
      freq.addEventListener('change', toggle);
      toggle();
    }
    const areaSel = el.querySelector('select[name="areaSolicitante"]');
    if (areaSel) {
      const toggle = () => {
        const wrap = el.querySelector('#disc-area-outra-wrap');
        if (wrap) wrap.classList.toggle('hidden', areaSel.value !== 'Outra');
      };
      areaSel.addEventListener('change', toggle);
      toggle();
    }
  },

  resetRecording() {
    const r = this.recording;
    if (r.timerHandle) { clearInterval(r.timerHandle); r.timerHandle = null; }
    if (r.stream) { r.stream.getTracks().forEach(t => t.stop()); r.stream = null; }
    if (r.mediaRecorder && r.mediaRecorder.state !== 'inactive') {
      try { r.mediaRecorder.stop(); } catch (e) { /* ignora */ }
    }
    this.recording = {
      status: 'idle', mediaRecorder: null, stream: null, chunks: [],
      startedAt: null, elapsedSeconds: 0, timerHandle: null, videoUrl: null, errorMsg: null
    };
  },

  /* --------------------------- Gravação de tela --------------------------- */
  // Grava a tela (com áudio, se o navegador permitir) enquanto o solicitante
  // narra o processo, e envia o vídeo pro Supabase Storage — agiliza o
  // mapeamento porque quem preenche o Discovery não precisa descrever tudo
  // por escrito, só mostrar o processo acontecendo.

  recordingWidgetHtml() {
    const r = this.recording;
    const suportado = typeof navigator !== 'undefined' && navigator.mediaDevices && typeof navigator.mediaDevices.getDisplayMedia === 'function';

    if (!suportado) {
      return `
        <div class="disc-recording-widget">
          <p class="disc-recording-unsupported">🎥 Gravação de tela não é suportada neste navegador. Use Chrome, Edge ou Firefox atualizados.</p>
        </div>`;
    }

    const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

    let statusHtml = '';
    if (r.status === 'idle') {
      statusHtml = `<button type="button" class="btn btn-secondary" id="disc-rec-start">🎥 Gravar tela do processo</button>`;
    } else if (r.status === 'recording') {
      statusHtml = `
        <span class="disc-rec-live">🔴 Gravando… ${mmss(r.elapsedSeconds)}</span>
        <button type="button" class="btn btn-danger" id="disc-rec-stop">⏹ Parar e enviar</button>`;
    } else if (r.status === 'uploading') {
      statusHtml = `<span class="disc-rec-live">⬆️ Enviando gravação para o Supabase Storage…</span>`;
    } else if (r.status === 'done') {
      statusHtml = `
        <span class="disc-rec-ok">✅ Gravação anexada</span>
        <a href="${Sanitize.html(r.videoUrl)}" target="_blank" rel="noopener" class="btn btn-ghost">▶ Ver gravação</a>
        <button type="button" class="btn btn-ghost" id="disc-rec-redo">Gravar novamente</button>`;
    } else if (r.status === 'error') {
      statusHtml = `
        <span class="disc-rec-error">⚠️ ${Sanitize.html(r.errorMsg || 'Não foi possível concluir a gravação.')}</span>
        <button type="button" class="btn btn-ghost" id="disc-rec-redo">Tentar novamente</button>`;
    }

    return `
      <div class="disc-recording-widget">
        <div class="disc-recording-label">Prefere mostrar em vez de descrever? Grave a tela executando o processo (opcional).</div>
        <div class="disc-recording-controls">${statusHtml}</div>
      </div>`;
  },

  bindRecordingWidget(el) {
    if (!el) return;
    const btnStart = el.querySelector('#disc-rec-start');
    if (btnStart) btnStart.addEventListener('click', () => this.startRecording(el));

    const btnStop = el.querySelector('#disc-rec-stop');
    if (btnStop) btnStop.addEventListener('click', () => this.stopRecording());

    const btnRedo = el.querySelector('#disc-rec-redo');
    if (btnRedo) btnRedo.addEventListener('click', () => {
      this.recording.status = 'idle';
      this.recording.videoUrl = null;
      this.recording.errorMsg = null;
      delete this.draft.gravacaoUrl;
      delete this.draft.gravacaoPath;
      this.updateRecordingWidget(el);
    });
  },

  updateRecordingWidget(el) {
    const container = (el && el.querySelector) ? el.querySelector('.disc-recording-widget') : document.querySelector('.disc-recording-widget');
    if (!container) return;
    container.outerHTML = this.recordingWidgetHtml();
    const parent = container.parentElement || document.getElementById('disc-content');
    if (parent) this.bindRecordingWidget(parent);
  },

  async startRecording(el) {
    const r = this.recording;
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: { cursor: 'always' }, audio: true });
      r.stream = stream;
      r.chunks = [];
      r.mediaRecorder = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? 'video/webm;codecs=vp9' : 'video/webm' });

      r.mediaRecorder.ondataavailable = (e) => { if (e.data && e.data.size > 0) r.chunks.push(e.data); };
      r.mediaRecorder.onstop = () => this.finishRecording(el);

      // Se o usuário parar o compartilhamento pelo próprio navegador (botão
      // nativo "Parar apresentação"), trata como se tivesse clicado em Parar.
      stream.getVideoTracks()[0].addEventListener('ended', () => {
        if (r.mediaRecorder && r.mediaRecorder.state !== 'inactive') this.stopRecording();
      });

      r.mediaRecorder.start();
      r.status = 'recording';
      r.startedAt = Date.now();
      r.elapsedSeconds = 0;
      r.timerHandle = setInterval(() => {
        r.elapsedSeconds = Math.floor((Date.now() - r.startedAt) / 1000);
        this.updateRecordingWidget(el);
      }, 1000);

      this.updateRecordingWidget(el);
    } catch (e) {
      r.status = 'error';
      r.errorMsg = e && e.name === 'NotAllowedError' ? 'Permissão de gravação de tela negada.' : (e.message || 'Erro ao iniciar a gravação.');
      this.updateRecordingWidget(el);
    }
  },

  stopRecording() {
    const r = this.recording;
    if (r.timerHandle) { clearInterval(r.timerHandle); r.timerHandle = null; }
    if (r.mediaRecorder && r.mediaRecorder.state !== 'inactive') {
      r.mediaRecorder.stop();
    }
    if (r.stream) {
      r.stream.getTracks().forEach(t => t.stop());
    }
  },

  async finishRecording(el) {
    const r = this.recording;
    const blob = new Blob(r.chunks, { type: 'video/webm' });
    r.chunks = [];

    if (!blob.size) {
      r.status = 'idle';
      this.updateRecordingWidget(el);
      return;
    }

    r.status = 'uploading';
    this.updateRecordingWidget(el);

    try {
      if (!window.supabaseClient) throw new Error('Sem conexão com o Supabase — não é possível enviar a gravação.');

      const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;
      const fileName = `discovery/${(user && user.username) || 'anonimo'}-${Date.now()}.webm`;

      const { error: uploadError } = await window.supabaseClient
        .storage
        .from(DISCOVERY_GRAVACOES_BUCKET)
        .upload(fileName, blob, { contentType: 'video/webm', upsert: false });

      if (uploadError) throw uploadError;

      // O bucket é privado (achado de segurança da auditoria: gravações de
      // tela podem mostrar dados internos sensíveis). Por isso guardamos só
      // o CAMINHO do arquivo — o link de acesso é gerado sob demanda, com
      // validade curta, tanto aqui (prévia) quanto na listagem de ideias.
      const { data: signed, error: signError } = await window.supabaseClient
        .storage.from(DISCOVERY_GRAVACOES_BUCKET)
        .createSignedUrl(fileName, 3600);
      if (signError) throw signError;

      r.videoUrl = signed ? signed.signedUrl : null;
      r.status = 'done';
      this.draft.gravacaoPath = fileName;
      delete this.draft.gravacaoUrl;
    } catch (e) {
      r.status = 'error';
      const msg = (e && e.message) || String(e);
      r.errorMsg = /bucket/i.test(msg) || /not found/i.test(msg)
        ? 'O bucket "discovery-gravacoes" ainda não foi criado no Supabase Storage. Peça a um administrador para rodar sql/004_discovery_gravacoes_storage.sql.'
        : `Não foi possível enviar a gravação: ${msg}`;
      notify(r.errorMsg, 'warn');
    }

    this.updateRecordingWidget(el);
  },

  saveStep() {
    const form = document.getElementById('disc-step-form');
    if (!form) return false;

    const fd = new FormData(form);
    const obj = {};
    fd.forEach((v, k) => { obj[k] = Sanitize.input(String(v)); });
    delete obj.evidencia;

    const required = {
      1: ['nomeIdeia', 'areaSolicitante', 'nomeSolicitante', 'emailSolicitante'],
      2: ['descricaoAtual', 'processoPadronizado', 'usaSistemas'],
      3: ['frequencia', 'volumeCasos', 'tempoMedioMin'],
      4: ['exigeJulgamentoHumano', 'usaExcel', 'regrasDefinidas']
    }[this.step] || [];

    for (const k of required) {
      if (!obj[k] || !String(obj[k]).trim()) {
        if (typeof toast === 'function') toast('Preencha todos os campos obrigatórios desta etapa.', 'warn');
        return false;
      }
    }

    if (obj.areaSolicitante === 'Outra' && obj.areaOutra) {
      obj.areaSolicitante = Sanitize.input(obj.areaOutra);
    }

    if (this.step === 4) {
      const fileInput = form.querySelector('#disc-evidencia');
      if (fileInput && fileInput.files && fileInput.files.length) {
        obj.evidencias = Array.from(fileInput.files).map(f => Sanitize.input(f.name));
      }
    }

    Object.assign(this.draft, obj);
    return true;
  },

  finish(el) {
    const d = this.draft;
    const viabilidade = (typeof Calc !== 'undefined' && Calc.discoveryViabilidade) ? Calc.discoveryViabilidade(d) : { score: 0, classificacao: 'Baixa Viabilidade', selo: '⚠️' };
    const roi = (typeof Calc !== 'undefined' && Calc.discoveryROI) ? Calc.discoveryROI(d) : { roiPercent: 0, economiaAnual: 0, horasEconomizadasAno: 0, fteEconomizado: 0 };
    const status = viabilidade.classificacao === 'Baixa Viabilidade' ? 'Não Elegível' : 'Pré-Aprovado';

    const list = this.getDiscoveryArray();
    const id = 'DISC-' + String(list.length + 1).padStart(4, '0');
    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;
    const record = Object.assign({}, d, {
      id,
      viabilidadeScore: viabilidade.score,
      viabilidadeClasse: viabilidade.classificacao,
      viabilidadeSelo: viabilidade.selo,
      roiPercent: roi.roiPercent,
      economiaAnual: roi.economiaAnual,
      horasEconomizadasAno: roi.horasEconomizadasAno,
      fteEconomizado: roi.fteEconomizado,
      status,
      dataEnvio: new Date().toISOString(),
      criadoPor: user ? user.username : 'sistema',
      projetoGeradoId: null
    });
    list.push(record);
    Store.set('discovery', list);
    if (typeof Audit !== 'undefined' && Audit.log) {
      Audit.log('Ideia de Discovery enviada', id + ' - ' + record.nomeIdeia);
    }

    this.lastResult = record;
    this.renderFeedback(el);
  },

  renderFeedback(el) {
    if (!el) return;
    const r = this.lastResult;
    if (!r) return;

    const aprovado = r.status === 'Pré-Aprovado';
    const formattedEconomia = typeof formatBRL === 'function' ? formatBRL(r.economiaAnual) : `R$ ${r.economiaAnual}`;

    el.innerHTML = `
      <div class="wizard-card disc-feedback ${aprovado ? 'disc-feedback-ok' : 'disc-feedback-no'}">
        <div class="disc-selo">${Sanitize.html(r.viabilidadeSelo || '')}</div>
        <h3>${aprovado ? 'Sua ideia de automação foi pré-aprovada!' : 'Recebemos sua oportunidade de automação'}</h3>
        <p class="disc-feedback-msg">
          ${aprovado
            ? 'Recebemos sua oportunidade de automação e identificamos um alto potencial de ganho operacional. Sua solicitação seguirá para análise detalhada do CoE de Automação. Em breve entraremos em contato. Obrigado por contribuir com a transformação digital da empresa!'
            : 'Agradecemos o envio da sua ideia. Neste momento identificamos que a oportunidade ainda não atende aos critérios mínimos de automação. Isso não significa que ela não poderá ser automatizada futuramente — nosso time poderá auxiliá-lo a padronizar o processo e aumentar sua viabilidade. Obrigado pela participação!'}
        </p>
        <div class="disc-feedback-stats">
          <div><strong>Score de Viabilidade</strong><span>${r.viabilidadeScore}/100 — ${Sanitize.html(r.viabilidadeClasse || '')}</span></div>
          <div><strong>Horas economizadas/ano (estimado)</strong><span>${r.horasEconomizadasAno}h</span></div>
          <div><strong>Economia anual estimada</strong><span>${formattedEconomia}</span></div>
          <div><strong>ROI estimado</strong><span>${r.roiPercent}%</span></div>
        </div>
        <p class="disc-feedback-note">📧 Esta confirmação é exibida na tela — o sistema não envia e-mail automático (não há servidor de e-mail neste ambiente 100% local).</p>
        <button class="btn btn-primary" id="disc-nova">Enviar outra ideia</button>
      </div>
    `;

    const btnNova = document.getElementById('disc-nova');
    if (btnNova) {
      btnNova.addEventListener('click', () => {
        this.lastResult = null; this.step = 1; this.draft = {};
        this.resetRecording();
        this.renderWizard(el);
      });
    }
  },

  stepHtml1(d, user) {
    const projects = this.getProjectsArray();
    const areasExistentes = [...new Set(projects.filter(p => p && p.area).map(p => p.area))];
    const areasPadrao = ['Financeiro', 'Comercial', 'Compras', 'Recursos Humanos', 'Jurídico', 'TI', 'Logística', 'Supply Chain','CoE'];
    const areas = [...new Set([...areasExistentes, ...areasPadrao])].sort();

    return `
      <div class="wizard-step-title">1. Identificação da Oportunidade</div>
      <div class="form-grid">
        <label class="full">Nome da sua ideia
          <input required name="nomeIdeia" value="${Sanitize.html(d.nomeIdeia || '')}" placeholder="Ex.: Automatizar emissão de relatório diário">
        </label>
        <label>Área solicitante
          <select name="areaSolicitante">
            <option value="">Selecione...</option>
            ${areas.map(a => `<option ${d.areaSolicitante === a ? 'selected' : ''}>${Sanitize.html(a)}</option>`).join('')}
            <option value="Outra" ${d.areaSolicitante === 'Outra' ? 'selected' : ''}>Outra</option>
          </select>
        </label>
        <label id="disc-area-outra-wrap" class="hidden">Qual área?
          <input name="areaOutra" value="${Sanitize.html(d.areaOutra || '')}">
        </label>
        <label>Seu nome
          <input required name="nomeSolicitante" value="${Sanitize.html(d.nomeSolicitante || (user ? user.nome : ''))}">
        </label>
        <label>Seu e-mail
          <input required type="email" name="emailSolicitante" value="${Sanitize.html(d.emailSolicitante || '')}" placeholder="voce@empresa.com">
        </label>
      </div>
    `;
  },

  stepHtml2(d) {
    return `
      <div class="wizard-step-title">2. Entendendo o Processo</div>
      <div class="form-grid">
        <label class="full">O que você faz hoje?
          <textarea required name="descricaoAtual" rows="3" placeholder="Descreva rapidamente as atividades.">${Sanitize.html(d.descricaoAtual || '')}</textarea>
        </label>
        <div class="full radio-field">
          <span>Esse processo segue sempre os mesmos passos?</span>
          ${simNaoRadios('processoPadronizado', d.processoPadronizado)}
        </div>
        <div class="full radio-field">
          <span>Você utiliza sistemas para executar essa atividade?</span>
          ${simNaoRadios('usaSistemas', d.usaSistemas)}
        </div>
        <label class="full hidden" id="disc-quais-sistemas-wrap">Quais sistemas?
          <input name="quaisSistemas" value="${Sanitize.html(d.quaisSistemas || '')}">
        </label>
      </div>
    `;
  },

  stepHtml3(d) {
    return `
      <div class="wizard-step-title">3. Esforço Atual</div>
      <div class="form-grid">
        <label>Quantas vezes esse processo acontece?
          <select name="frequencia">
            <option value="">Selecione...</option>
            ${FREQUENCIA_OPCOES.map(f => `<option ${d.frequencia === f ? 'selected' : ''}>${Sanitize.html(f)}</option>`).join('')}
          </select>
        </label>
        <label id="disc-vezes-dia-wrap" class="hidden">Quantas vezes por dia?
          <input type="number" min="1" name="vezesPorDia" value="${d.vezesPorDia || 1}">
        </label>
        <label>Quantos casos são processados (por ocorrência)?
          <input required type="number" min="0" step="0.1" name="volumeCasos" value="${d.volumeCasos || ''}" placeholder="Ex.: 100 pedidos">
        </label>
        <label>Tempo médio por caso (minutos)
          <input required type="number" min="0" step="0.1" name="tempoMedioMin" value="${d.tempoMedioMin || ''}" placeholder="Ex.: 5">
        </label>
      </div>
    `;
  },

  stepHtml4(d) {
    return `
      <div class="wizard-step-title">4. Análise de Automação</div>
      <div class="form-grid">
        <div class="radio-field">
          <span>Há necessidade de julgamento humano?</span>
          ${simNaoRadios('exigeJulgamentoHumano', d.exigeJulgamentoHumano)}
        </div>
        <div class="radio-field">
          <span>Existem arquivos Excel envolvidos?</span>
          ${simNaoRadios('usaExcel', d.usaExcel)}
        </div>
        <div class="radio-field full">
          <span>Existem regras claramente definidas?</span>
          ${simNaoRadios('regrasDefinidas', d.regrasDefinidas)}
        </div>
        <label class="full">Deseja anexar evidências? (PDF, Excel, Word ou imagem)
          <input type="file" id="disc-evidencia" name="evidencia" multiple accept=".pdf,.xlsx,.xls,.doc,.docx,.png,.jpg,.jpeg">
        </label>
        <p class="disc-upload-note full">⚠️ Por limitação de armazenamento local, apenas o <strong>nome</strong> dos arquivos fica registrado como referência — o conteúdo não é salvo no sistema. Envie o arquivo real pelo canal indicado pela sua área de RPA, se necessário.</p>
        <label class="full">Comentários adicionais (opcional)
          <textarea name="comentarios" rows="2">${Sanitize.html(d.comentarios || '')}</textarea>
        </label>
      </div>
    `;
  },

  renderList(el) {
    if (!el) return;
    const podeVerTodas = typeof Auth !== 'undefined' && Auth.permissao && Auth.permissao('podeEditar');
    // Administrador, Gestor e Desenvolvedor são exatamente os perfis com
    // podeEditar:true (ver PERFIS em auth.js) — por isso reaproveitamos o
    // mesmo flag para liberar editar/ver detalhes/excluir nesta tela.
    const podeGerenciar = podeVerTodas;
    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;

    let list = this.getDiscoveryArray().slice().reverse();
    if (!podeVerTodas && user) list = list.filter(d => d && d.criadoPor === user.username);

    const formatData = (d) => typeof formatDateBR === 'function' ? formatDateBR(d) : d;

    el.innerHTML = `
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr>
            <th>ID</th><th>Ideia</th><th>Área</th><th>Solicitante</th><th>Viabilidade</th><th>ROI Est.</th><th>Status</th><th>Data</th><th>Gravação</th>${podeVerTodas ? '<th>Conversão</th>' : ''}${podeGerenciar ? '<th>Ações</th>' : ''}
          </tr></thead>
          <tbody>
            ${list.map(d => {
              if (!d) return '';
              return `
              <tr>
                <td>${Sanitize.html(d.id || '')}</td>
                <td>${Sanitize.html(d.nomeIdeia || '')}</td>
                <td>${Sanitize.html(d.areaSolicitante || '')}</td>
                <td>${Sanitize.html(d.nomeSolicitante || '')}</td>
                <td>${Sanitize.html(d.viabilidadeSelo || '')} ${d.viabilidadeScore || 0}/100</td>
                <td>${d.roiPercent || 0}%</td>
                <td><span class="badge ${d.status === 'Pré-Aprovado' ? 'badge-capacity-disponivel' : (d.status === 'Convertido' ? 'badge-perfil-gestor' : 'badge-status-cancelado')}">${Sanitize.html(d.status || '')}</span></td>
                <td>${formatData(d.dataEnvio)}</td>
                <td>${d.gravacaoPath ? `<button type="button" class="icon-btn" data-ver-gravacao="${Sanitize.html(d.gravacaoPath)}" title="Ver gravação">▶ Ver</button>` : '—'}</td>
                ${podeVerTodas ? `<td>${d.projetoGeradoId ? `<span class="badge badge-capacity-disponivel">→ ${Sanitize.html(d.projetoGeradoId)}</span>` : `<button class="btn btn-secondary" data-conv="${d.id}">Converter em Projeto</button>`}</td>` : ''}
                ${podeGerenciar ? `<td class="row-actions">
                  <button type="button" class="icon-btn" data-view="${Sanitize.html(d.id)}" title="Ver detalhes">🔍</button>
                  <button type="button" class="icon-btn" data-edit="${Sanitize.html(d.id)}" title="Editar">✏️</button>
                  <button type="button" class="icon-btn" data-del="${Sanitize.html(d.id)}" title="Excluir">🗑️</button>
                </td>` : ''}
              </tr>`;
            }).join('') || `<tr><td colspan="${podeVerTodas ? 11 : 9}" class="empty-state">Nenhuma ideia enviada ainda.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;

    el.querySelectorAll('[data-conv]').forEach(b => b.addEventListener('click', () => this.convertToProject(b.dataset.conv)));
    el.querySelectorAll('[data-ver-gravacao]').forEach(b => b.addEventListener('click', () => this.verGravacao(b.dataset.verGravacao)));
    el.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => this.viewDetails(b.dataset.view)));
    el.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => this.openEditForm(b.dataset.edit)));
    el.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => this.deleteDiscovery(b.dataset.del)));
  },

  async verGravacao(path) {
    if (!window.supabaseClient) { notify('Sem conexão com o banco de dados.', 'warn'); return; }
    const { data, error } = await window.supabaseClient
      .storage.from(DISCOVERY_GRAVACOES_BUCKET)
      .createSignedUrl(path, 3600);
    if (error || !data) {
      notify('Não foi possível abrir a gravação: ' + (error ? error.message : 'erro desconhecido'), 'warn');
      return;
    }
    window.open(data.signedUrl, '_blank');
  },

  viewDetails(id) {
    const d = this.getDiscoveryArray().find(x => x && String(x.id) === String(id));
    if (!d) return;
    const formatData = (v) => typeof formatDateBR === 'function' ? formatDateBR(v) : v;

    Modal.open(`${d.id} — ${Sanitize.html(d.nomeIdeia || '')}`, `
      <div class="detail-grid">
        <div><strong>Área:</strong> ${Sanitize.html(d.areaSolicitante || '')}</div>
        <div><strong>Solicitante:</strong> ${Sanitize.html(d.nomeSolicitante || '')}</div>
        <div><strong>E-mail:</strong> ${Sanitize.html(d.emailSolicitante || '')}</div>
        <div><strong>Status:</strong> ${Sanitize.html(d.status || '')}</div>
        <div><strong>Data de envio:</strong> ${formatData(d.dataEnvio) || '—'}</div>
        <div><strong>Viabilidade:</strong> ${Sanitize.html(d.viabilidadeSelo || '')} (${d.viabilidadeScore || 0}/100)</div>
        <div><strong>ROI Estimado:</strong> ${d.roiPercent || 0}%</div>
        <div><strong>Frequência:</strong> ${Sanitize.html(d.frequencia || '—')}</div>
        <div><strong>Volume de casos:</strong> ${d.volumeCasos ?? '—'}</div>
        <div><strong>Tempo médio (min):</strong> ${d.tempoMedioMin ?? '—'}</div>
        <div><strong>Usa sistemas?</strong> ${Sanitize.html(d.usaSistemas || '—')} ${d.quaisSistemas ? '— ' + Sanitize.html(d.quaisSistemas) : ''}</div>
        <div><strong>Exige julgamento humano?</strong> ${Sanitize.html(d.exigeJulgamentoHumano || '—')}</div>
        <div><strong>Usa Excel?</strong> ${Sanitize.html(d.usaExcel || '—')}</div>
        <div><strong>Regras definidas?</strong> ${Sanitize.html(d.regrasDefinidas || '—')}</div>
        <div><strong>Projeto gerado:</strong> ${d.projetoGeradoId ? Sanitize.html(d.projetoGeradoId) : '—'}</div>
      </div>
      <h4 style="margin-top:16px">Descrição do processo atual</h4>
      <p>${Sanitize.html(d.descricaoAtual || 'Sem descrição.')}</p>
      ${d.comentarios ? `<h4 style="margin-top:16px">Comentários</h4><p>${Sanitize.html(d.comentarios)}</p>` : ''}
      <div class="form-actions"><button class="btn btn-ghost" id="btn-close-detail">Fechar</button></div>
    `);
    document.getElementById('btn-close-detail').addEventListener('click', Modal.close);
  },

  openEditForm(id) {
    const list = this.getDiscoveryArray();
    const d = list.find(x => x && String(x.id) === String(id));
    if (!d) return;

    Modal.open(`Editar Ideia — ${d.id}`, `
      <form id="disc-edit-form" class="form-grid">
        <label class="full">Nome da ideia
          <input required name="nomeIdeia" value="${Sanitize.html(d.nomeIdeia || '')}">
        </label>
        <label>Área solicitante
          <input name="areaSolicitante" value="${Sanitize.html(d.areaSolicitante || '')}">
        </label>
        <label>Solicitante
          <input name="nomeSolicitante" value="${Sanitize.html(d.nomeSolicitante || '')}">
        </label>
        <label>E-mail
          <input type="email" name="emailSolicitante" value="${Sanitize.html(d.emailSolicitante || '')}">
        </label>
        <label>Status
          <select name="status">
            ${['Em Análise', 'Pré-Aprovado', 'Reprovado', 'Convertido'].map(s => `<option ${d.status === s ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </label>
        <label>Volume de casos
          <input type="number" min="0" step="0.1" name="volumeCasos" value="${d.volumeCasos ?? ''}">
        </label>
        <label>Tempo médio por caso (min)
          <input type="number" min="0" step="0.1" name="tempoMedioMin" value="${d.tempoMedioMin ?? ''}">
        </label>
        <label class="full">Descrição do processo atual
          <textarea name="descricaoAtual" rows="3">${Sanitize.html(d.descricaoAtual || '')}</textarea>
        </label>
        <label class="full">Comentários adicionais
          <textarea name="comentarios" rows="2">${Sanitize.html(d.comentarios || '')}</textarea>
        </label>
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" id="btn-cancel-disc-edit">Cancelar</button>
          <button type="submit" class="btn btn-primary">Salvar</button>
        </div>
      </form>
    `);

    document.getElementById('btn-cancel-disc-edit').addEventListener('click', Modal.close);
    document.getElementById('disc-edit-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const raw = {};
      fd.forEach((v, k) => raw[k] = v);

      const payload = {
        ...d,
        nomeIdeia: Sanitize.input(raw.nomeIdeia),
        areaSolicitante: Sanitize.input(raw.areaSolicitante),
        nomeSolicitante: Sanitize.input(raw.nomeSolicitante),
        emailSolicitante: Sanitize.input(raw.emailSolicitante),
        status: raw.status,
        volumeCasos: raw.volumeCasos === '' ? d.volumeCasos : Number(raw.volumeCasos),
        tempoMedioMin: raw.tempoMedioMin === '' ? d.tempoMedioMin : Number(raw.tempoMedioMin),
        descricaoAtual: Sanitize.input(raw.descricaoAtual),
        comentarios: Sanitize.input(raw.comentarios)
      };

      const sucesso = await Store.set('discovery', payload);
      if (!sucesso) {
        notify('Erro ao atualizar a ideia no banco de dados. Verifique o console.', 'warn');
        return;
      }

      if (typeof Audit !== 'undefined' && Audit.log) {
        await Audit.log('Ideia de Discovery editada', payload.id + ' - ' + payload.nomeIdeia);
      }

      Modal.close();
      notify('Ideia atualizada com sucesso.', 'success');
      const contentEl = document.getElementById('disc-content');
      if (contentEl) this.renderList(contentEl);
    });
  },

  async deleteDiscovery(id) {
    const d = this.getDiscoveryArray().find(x => x && String(x.id) === String(id));
    if (!d) return;
    if (!confirm(`Confirma a exclusão da ideia "${d.nomeIdeia}" (${d.id})? Esta ação não pode ser desfeita.`)) return;

    const sucesso = await Store.remove('discovery', id);
    if (!sucesso) {
      notify('Não foi possível excluir a ideia no banco de dados. Verifique o console.', 'warn');
      return;
    }

    if (typeof Audit !== 'undefined' && Audit.log) {
      await Audit.log('Ideia de Discovery excluída', id + ' - ' + (d.nomeIdeia || ''));
    }

    notify('Ideia excluída.', 'warn');
    const contentEl = document.getElementById('disc-content');
    if (contentEl) this.renderList(contentEl);
  },

  convertToProject(discoveryId) {
    const discList = this.getDiscoveryArray();
    const d = discList.find(x => x && x.id === discoveryId);
    if (!d) return;
    if (!confirm(`Converter "${d.nomeIdeia}" em um novo projeto no pipeline?`)) return;

    const settings = Store.get('settings', {});
    const freqAnual = (typeof Calc !== 'undefined' && Calc.discoveryFrequenciaAnual) ? Calc.discoveryFrequenciaAnual(d) : 252;
    const casosAno = (Number(d.volumeCasos) || 0) * freqAnual;

    const hExec = typeof round2 === 'function' ? round2((Number(d.tempoMedioMin) || 0) / 60) : ((Number(d.tempoMedioMin) || 0) / 60);
    const execDia = typeof round2 === 'function' ? round2(casosAno / 252) : (casosAno / 252);
    const execSem = Math.max(1, Math.round(casosAno / 52));

    const reachVal = typeof round0 === 'function' ? round0(casosAno) : Math.round(casosAno);

    const projects = this.getProjectsArray();
    const newId = 'PRJ-' + String(projects.length + 1).padStart(4, '0');
    const novo = {
      id: newId,
      nome: d.nomeIdeia,
      area: d.areaSolicitante,
      processo: d.descricaoAtual,
      solicitante: d.nomeSolicitante,
      sponsor: '',
      responsavel: '',
      data_solicitacao: new Date().toISOString().slice(0, 10),
      data_aprovacao: '',
      status: 'Triagem',
      complexidade: 'Média',
      tecnologia: 'Power Automate',
      impacto: 3, urgencia: 3, volume: 3, alinhamento: 3,
      reach: reachVal, confidence: d.viabilidadeScore || 50, effort: 3,
      // Nomes das colunas reais do Supabase (rpa_projetos) — os mesmos usados
      // em projects.js ao salvar o formulário. Salvar em camelCase aqui fazia
      // esses projetos (nascidos do Discovery) chegarem ao banco sem essas
      // colunas preenchidas, e a economia aparecia zerada em todo o sistema.
      risco: 3,
      horas_gastas_atual: hExec,
      horas_economizadas: hExec,
      execucoes_dia: execDia,
      execucoes_semana: execSem,
      valor_hora: settings.valorHoraPadrao || 65,
      aprovacoes: { sponsor: false, ti: false, seguranca: false, compliance: false, lgpd: false },
      historico: [
        { data: new Date().toISOString().slice(0, 10), evento: `Gerado a partir do Discovery ${d.id} (viabilidade: ${d.viabilidadeClasse})` }
      ]
    };
    projects.push(novo);
    Store.set('projects', projects);
    if (typeof StatusHistory !== 'undefined' && StatusHistory.log) StatusHistory.log(newId, null, 'Triagem');

    d.status = 'Convertido';
    d.projetoGeradoId = newId;
    Store.set('discovery', discList);

    if (typeof Audit !== 'undefined' && Audit.log) {
      Audit.log('Ideia convertida em projeto', d.id + ' → ' + newId);
    }

    if (typeof toast === 'function') {
      toast(`Projeto ${newId} criado a partir da ideia. Complete os dados na tela de Projetos.`);
    }

    const contentEl = document.getElementById('disc-content');
    if (contentEl) this.renderList(contentEl);
  }
};

function simNaoRadios(name, current) {
  return `
    <div class="radio-options">
      <label class="radio-opt"><input type="radio" name="${name}" value="Sim" ${current === 'Sim' ? 'checked' : ''}> Sim</label>
      <label class="radio-opt"><input type="radio" name="${name}" value="Não" ${current === 'Não' ? 'checked' : ''}> Não</label>
    </div>
  `;
}
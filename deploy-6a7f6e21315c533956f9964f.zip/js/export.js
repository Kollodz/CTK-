/* ============================================================================
   export.js
   Módulo 11 - Exportações (Excel, CSV, JSON, PDF) + Base de Dados Compartilhada

   A partir desta versão, os arquivos Excel (.xlsx) são gerados e lidos com a
   biblioteca SheetJS (carregada via CDN no index.html), em vez do truque de
   HTML disfarçado de .xls usado antes. Motivo da troca: o truque antigo não
   é um formato de verdade — funciona quando o próprio Excel abre o arquivo,
   mas outras ferramentas (inclusive o próprio SheetJS) não sabem separar as
   "abas" corretamente, o que causava dados de todas as abas se misturando na
   importação. Gerando um .xlsx binário de verdade, o arquivo funciona igual
   não importa quem/o que abrir — inclusive se você editar no Excel e salvar
   de novo, o formato continua sendo o mesmo.

   DEPENDÊNCIA EXTERNA: diferente do resto do sistema (gráficos, etc., que são
   100% nativos), esta função específica de Excel precisa da biblioteca SheetJS
   carregada via CDN. Se a rede bloquear o domínio do CDN, os botões de Excel
   mostram um aviso claro em vez de travar silenciosamente — CSV, JSON e PDF
   continuam funcionando normalmente, pois não dependem de nenhuma biblioteca.
   Veja DOCUMENTACAO_TECNICA.md para instruções de como hospedar a biblioteca
   localmente e eliminar essa dependência de internet por completo.
   ============================================================================ */

/* ============================================================================
   export.js
   Módulo 11 - Exportações (Excel, CSV, JSON, PDF) + Base de Dados Compartilhada
   ============================================================================ */

const Exporter = {

  // Helper seguro para exibir avisos sem crashar caso a função toast() não exista
  _notify(message, type = 'info') {
    if (typeof toast === 'function') {
      toast(message, type);
    } else if (typeof Toast === 'object' && typeof Toast.show === 'function') {
      Toast.show(message, type);
    } else if (typeof showToast === 'function') {
      showToast(message, type);
    } else {
      console.log(`[${type.toUpperCase()}] ${message}`);
      if (type === 'warn' || type === 'error') alert(message);
    }
  },

  _checkXLSX() {
    if (typeof XLSX === 'undefined') {
      this._notify('A biblioteca de Excel (SheetJS) não carregou — verifique sua conexão com a internet e tente novamente. CSV, JSON e PDF continuam funcionando normalmente.', 'warn');
      return false;
    }
    return true;
  },

  // Busca segura no Store tentando tanto a chave simples quanto com o prefixo 'rpa_' usado no Supabase
  _getStoreList(key) {
    let rawData = Store.get(key) || Store.get(`rpa_${key}`) || Store.get(key.replace('rpa_', ''));
    if (!rawData) return [];
    if (Array.isArray(rawData)) return rawData;
    if (typeof rawData === 'object') return Object.values(rawData);
    return [];
  },

  buildRows() {
    return this._getStoreList('projects').map(p => {
      const bc = typeof Calc !== 'undefined' && Calc.businessCase ? Calc.businessCase(p) : {};
      return {
        ID: p.id || '', Nome: p.nome || '', Area: p.area || '', Status: p.status || '', Complexidade: p.complexidade || '',
        Tecnologia: p.tecnologia || '', Responsavel: p.responsavel || '', Sponsor: p.sponsor || '',
        Execucoes_Semana: p.execucoesPorSemana ?? '',
        ScoreCorporativo: typeof Calc !== 'undefined' && Calc.scoreCorporativo ? Calc.scoreCorporativo(p) : 0, 
        ROI_Percent: bc.roiPercent || 0,
        Payback_Meses: bc.paybackMeses || 0, Economia_Mensal: bc.economiaMensal || 0, Economia_Anual: bc.economiaAnual || 0,
        TCO: bc.tco || 0, VPL: bc.vpl || 0
      };
    });
  },

  exportExcel() {
    if (!this._checkXLSX()) return;
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(this.buildRows()), 'Projetos');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(this._getStoreList('team')), 'Capacidade');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(this._getStoreList('risks')), 'Riscos');
    XLSX.writeFile(wb, 'relatorio_rpa_' + dateStamp() + '.xlsx');
    if (typeof Audit !== 'undefined') Audit.log('Exportação Excel realizada');
    this._notify('Excel exportado com sucesso (abas: Projetos, Capacidade, Riscos).');
  },

  exportCSV() {
    const rows = this.buildRows();
    if (!rows.length) { this._notify('Não há dados para exportar.', 'warn'); return; }
    const headers = Object.keys(rows[0]);
    const csv = [headers.join(';')].concat(
      rows.map(r => headers.map(h => `"${String(r[h] ?? '').replace(/"/g, '""')}"`).join(';'))
    ).join('\n');
    downloadBlob('\ufeff' + csv, 'relatorio_rpa_' + dateStamp() + '.csv', 'text/csv;charset=utf-8;');
    if (typeof Audit !== 'undefined') Audit.log('Exportação CSV realizada');
    this._notify('CSV exportado com sucesso.');
  },

  exportJSON() {
    const payload = {
      exportadoEm: new Date().toISOString(),
      projects: this._getStoreList('projects'),
      team: this._getStoreList('team'),
      risks: this._getStoreList('risks')
    };
    downloadBlob(JSON.stringify(payload, null, 2), 'relatorio_rpa_' + dateStamp() + '.json', 'application/json');
    if (typeof Audit !== 'undefined') Audit.log('Exportação JSON realizada');
    this._notify('JSON exportado com sucesso.');
  },

  exportPDF() {
    const printable = document.getElementById('report-printable');
    if (!printable) { this._notify('Abra o módulo de Relatórios antes de exportar em PDF.', 'warn'); return; }
    const w = window.open('', '_blank');
    w.document.write(`
      <html><head><title>Relatório RPA</title>
      <style>
        body{font-family:Arial,sans-serif;padding:24px;color:#1e293b}
        table{width:100%;border-collapse:collapse;margin:12px 0}
        th,td{border:1px solid #cbd5e1;padding:6px 8px;font-size:13px;text-align:left}
        th{background:#f1f5f9}
        h3{margin-top:20px}
      </style></head><body>
      <h2>Relatório Executivo - Portfólio de RPA</h2>
      <p>Gerado em ${new Date().toLocaleString('pt-BR')}</p>
      ${printable.innerHTML}
      </body></html>
    `);
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 300);
    if (typeof Audit !== 'undefined') Audit.log('Exportação PDF realizada');
  },

  exportLGPD() {
    const user = typeof Auth !== 'undefined' ? Auth.currentUser() : { username: 'usuario' };
    const logs = typeof Audit !== 'undefined' ? Audit.all().filter(l => l.usuario === user.username) : [];
    const payload = { usuario: user, exportadoEm: new Date().toISOString(), logsRelacionados: logs };
    downloadBlob(JSON.stringify(payload, null, 2), 'dados_titular_' + user.username + '.json', 'application/json');
    if (typeof Audit !== 'undefined') Audit.log('Exportação de dados do titular (LGPD)', user.username);
    this._notify('Dados do titular exportados.');
  },

  _projectFieldOrder() {
    return ['id', 'nome', 'area', 'processo', 'solicitante', 'sponsor', 'responsavel',
      'dataSolicitacao', 'dataAprovacao', 'dataPrevisaoFinalizacao', 'status', 'complexidade', 'tecnologia',
      'impacto', 'urgencia', 'volume', 'riscoScore', 'alinhamento', 'reach', 'confidence', 'effort',
      'horasAtuais', 'horasPorExecucao', 'execucoesPorDia', 'execucoesPorSemana', 'valorHora'];
  },

  flattenProject(p) {
    if (!p || typeof p !== 'object') return {};
    const row = {};
    this._projectFieldOrder().forEach(k => { row[k] = p[k] ?? ''; });
    const ap = p.aprovacoes || {};
    row.aprovacao_sponsor = ap.sponsor ? 'Sim' : 'Não';
    row.aprovacao_ti = ap.ti ? 'Sim' : 'Não';
    row.aprovacao_seguranca = ap.seguranca ? 'Sim' : 'Não';
    row.aprovacao_compliance = ap.compliance ? 'Sim' : 'Não';
    row.aprovacao_lgpd = ap.lgpd ? 'Sim' : 'Não';
    row.historico_json = JSON.stringify(p.historico || []);
    return row;
  },

  unflattenProject(row) {
    const p = {};
    this._projectFieldOrder().forEach(k => { p[k] = row[k] ?? ''; });
    ['impacto', 'urgencia', 'volume', 'riscoScore', 'alinhamento', 'reach', 'confidence', 'effort', 'horasAtuais', 'horasPorExecucao', 'execucoesPorDia', 'execucoesPorSemana', 'valorHora'].forEach(k => {
      p[k] = Number(row[k]) || 0;
    });
    ['dataSolicitacao', 'dataAprovacao', 'dataPrevisaoFinalizacao'].forEach(k => {
      p[k] = normalizeExcelDate(row[k]);
    });
    p.aprovacoes = {
      sponsor: row.aprovacao_sponsor === 'Sim',
      ti: row.aprovacao_ti === 'Sim',
      seguranca: row.aprovacao_seguranca === 'Sim',
      compliance: row.aprovacao_compliance === 'Sim',
      lgpd: row.aprovacao_lgpd === 'Sim'
    };
    try { p.historico = JSON.parse(row.historico_json || '[]'); } catch (e) { p.historico = []; }
    return p;
  },

  _sheetNameByKey: {
    projetos: 'TB_PROJETOS', discovery: 'TB_DISCOVERY', usuarios: 'TB_USUARIOS',
    status_historico: 'TB_STATUS_HISTORICO', parametros: 'TB_PARAMETROS',
    capacidade: 'TB_CAPACIDADE', riscos: 'TB_RISCOS'
  },

  exportDatabase() {
    if (!this._checkXLSX()) return;

    const projects = this._getStoreList('projects').map(p => this.flattenProject(p));
    const discovery = this._getStoreList('discovery').map(d => Object.assign({}, d, { evidencias_json: JSON.stringify(d.evidencias || []) }));
    const usuarios = this._getStoreList('users').map(u => ({
      username: u.username, nome: u.nome, perfil: u.perfil,
      passwordHash: u.passwordHash || '', passwordSalt: u.passwordSalt || ''
    }));
    const statusHist = this._getStoreList('status_historico');
    const settings = Store.get('settings') || Store.get('rpa_settings') || {};
    const parametros = [
      { chave: 'valorHoraPadrao', valor: settings.valorHoraPadrao || '' },
      { chave: 'custoProjetoPadrao', valor: settings.custoProjetoPadrao || '' },
      { chave: 'empresa', valor: settings.empresa || '' }
    ];
    const team = this._getStoreList('team');
    const risks = this._getStoreList('risks');

    const dataByKey = { projetos: projects, discovery, usuarios, status_historico: statusHist, parametros, capacidade: team, riscos: risks };

    const wb = XLSX.utils.book_new();
    Object.keys(this._sheetNameByKey).forEach(key => {
      const rows = dataByKey[key];
      const ws = (rows && rows.length) ? XLSX.utils.json_to_sheet(rows) : XLSX.utils.aoa_to_sheet([['(sem dados)']]);
      XLSX.utils.book_append_sheet(wb, ws, this._sheetNameByKey[key]);
    });

    XLSX.writeFile(wb, 'Banco_RPA.xlsx');

    const settingsUpdated = Store.get('settings') || {};
    settingsUpdated.ultimaExportacaoBase = new Date().toISOString();
    Store.set('settings', settingsUpdated);

    if (typeof Audit !== 'undefined') Audit.log('Base de dados compartilhada exportada', 'Banco_RPA.xlsx');
    this._notify('Banco_RPA.xlsx gerado com sucesso!');
  },

  parseDatabaseFile(file) {
    if (!this._checkXLSX()) return Promise.reject(new Error('Biblioteca de Excel indisponível.'));

    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Não foi possível ler o arquivo.'));
      reader.onload = () => {
        try {
          const data = new Uint8Array(reader.result);
          const wb = XLSX.read(data, { type: 'array', cellDates: true });

          const nameToKey = {};
          Object.entries(this._sheetNameByKey).forEach(([key, name]) => { nameToKey[name.toLowerCase()] = key; });

          const tables = {};
          wb.SheetNames.forEach(sheetName => {
            const key = nameToKey[sheetName.trim().toLowerCase()];
            if (!key) return;
            tables[key] = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '' });
          });

          if (!tables.projetos) {
            throw new Error(`Nenhuma aba "TB_PROJETOS" encontrada neste arquivo. Abas encontradas: ${wb.SheetNames.join(', ') || '(nenhuma)'}.`);
          }

          const projects = tables.projetos.map(r => this.unflattenProject(r));
          const discovery = (tables.discovery || []).map(r => {
            try { r.evidencias = JSON.parse(r.evidencias_json || '[]'); } catch (e) { r.evidencias = []; }
            return r;
          });
          const statusHist = tables.status_historico || null;
          const team = tables.capacidade || null;
          const risks = tables.riscos ? tables.riscos.map(r => Object.assign({}, r, {
            probabilidade: Number(r.probabilidade) || 1, impacto: Number(r.impacto) || 1
          })) : null;
          const parametros = tables.parametros || null;
          const usuarios = (tables.usuarios || []).filter(u => u.username && u.passwordHash && u.passwordSalt);

          resolve({ projects, discovery, statusHist, team, risks, parametros, usuarios, fileName: file.name });
        } catch (err) {
          reject(err);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  },

  commitDatabaseImport(parsed) {
    Store.set('projects', parsed.projects);
    Store.set('discovery', parsed.discovery);
    if (parsed.statusHist) Store.set('status_historico', parsed.statusHist);
    if (parsed.team) Store.set('team', parsed.team);
    if (parsed.risks) Store.set('risks', parsed.risks);
    if (parsed.parametros) {
      const settings = Store.get('settings') || {};
      parsed.parametros.forEach(r => {
        if (r.chave === 'valorHoraPadrao') settings.valorHoraPadrao = Number(r.valor) || settings.valorHoraPadrao;
        if (r.chave === 'custoProjetoPadrao') settings.custoProjetoPadrao = Number(r.valor) || settings.custoProjetoPadrao;
        if (r.chave === 'empresa') settings.empresa = r.valor || settings.empresa;
      });
      settings.ultimaImportacaoBase = new Date().toISOString();
      Store.set('settings', settings);
    }

    let usuariosSincronizados = 0;
    if (parsed.usuarios && parsed.usuarios.length) {
      const usuariosAtuais = this._getStoreList('users');
      parsed.usuarios.forEach(novo => {
        const existente = usuariosAtuais.find(u => u.username && String(u.username).toLowerCase() === String(novo.username).toLowerCase());
        if (existente) {
          existente.nome = novo.nome || existente.nome;
          existente.perfil = novo.perfil || existente.perfil;
          existente.passwordHash = novo.passwordHash;
          existente.passwordSalt = novo.passwordSalt;
        } else {
          usuariosAtuais.push({
            username: novo.username, nome: novo.nome || novo.username,
            perfil: novo.perfil || 'Visualizador',
            passwordHash: novo.passwordHash, passwordSalt: novo.passwordSalt
          });
        }
        usuariosSincronizados++;
      });
      Store.set('users', usuariosAtuais);
    }

    if (typeof Audit !== 'undefined') Audit.log('Base de dados compartilhada importada', parsed.fileName);
    return { projetos: parsed.projects.length, discovery: parsed.discovery.length, usuarios: usuariosSincronizados };
  }
};

function downloadBlob(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function dateStamp() {
  return new Date().toISOString().slice(0, 10);
}

function normalizeExcelDate(value) {
  if (!value && value !== 0) return '';

  if (value instanceof Date && !isNaN(value)) {
    const y = value.getUTCFullYear();
    const m = String(value.getUTCMonth() + 1).padStart(2, '0');
    const d = String(value.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  if (typeof value === 'number') {
    const epoch = Date.UTC(1899, 11, 30);
    const ms = epoch + value * 86400000;
    return normalizeExcelDate(new Date(ms));
  }

  const str = String(value).trim();
  if (!str) return '';
  const isoMatch = str.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (isoMatch) return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;
  const brMatch = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (brMatch) return `${brMatch[3]}-${brMatch[2].padStart(2, '0')}-${brMatch[1].padStart(2, '0')}`;
  return str;
}

function escapeXml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
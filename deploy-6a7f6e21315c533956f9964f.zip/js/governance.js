/* ============================================================================
   governance.js
   Módulo 8 - Governança de RPA
   ============================================================================ */

const APROVACOES_LABELS = {
  sponsor: 'Sponsor', ti: 'TI', seguranca: 'Segurança', compliance: 'Compliance', lgpd: 'LGPD'
};

const Governance = {
  // Helper defensivo para garantir retorno sempre como Array
  getProjectsArray() {
    const raw = Store.get('projects', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.projects)) return raw.projects;
    return [];
  },

  render(container) {
    if (!container) return;

    // Busca garantida como Array antes do .filter
    const projects = this.getProjectsArray().filter(p => p && p.status !== 'Cancelado');

    container.innerHTML = `
      <div class="module-header">
        <h2>Governança de RPA</h2>
        <p class="module-subtitle">Controle de aprovações obrigatórias por projeto</p>
      </div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr>
            <th>Projeto</th><th>Sponsor</th><th>TI</th><th>Segurança</th><th>Compliance</th><th>LGPD</th><th>Status Geral</th>
          </tr></thead>
          <tbody>
            ${projects.map(p => {
              if (!p) return '';
              const ap = p.aprovacoes || {};
              const total = Object.keys(APROVACOES_LABELS).length;
              const aprovadas = Object.keys(APROVACOES_LABELS).filter(k => ap[k]).length;
              const completo = aprovadas === total;
              return `<tr>
                <td>${Sanitize.html(p.id || '')} — ${Sanitize.html(p.nome || 'Sem nome')}</td>
                ${Object.keys(APROVACOES_LABELS).map(k => `
                  <td class="approval-cell">
                    <button class="approval-toggle ${ap[k] ? 'approved' : ''}" data-project="${p.id}" data-key="${k}" ${Auth.permissao('podeAprovar') ? '' : 'disabled'}>
                      ${ap[k] ? '✅' : '⬜'}
                    </button>
                  </td>`).join('')}
                <td><span class="badge ${completo ? 'badge-capacity-disponivel' : 'badge-capacity-sobrecarregado'}">${aprovadas}/${total}</span></td>
              </tr>`;
            }).join('') || `<tr><td colspan="7" class="empty-state">Nenhum projeto ativo.</td></tr>`}
          </tbody>
        </table>
      </div>
      <div class="info-box">Somente perfis <strong>Administrador</strong> e <strong>Gestor</strong> podem registrar aprovações. Toda alteração é registrada na trilha de auditoria.</div>
    `;

    if (Auth.permissao('podeAprovar')) {
      container.querySelectorAll('.approval-toggle').forEach(btn => {
        btn.addEventListener('click', () => this.toggleApproval(btn.dataset.project, btn.dataset.key));
      });
    }
  },

  toggleApproval(projectId, key) {
    const list = this.getProjectsArray();
    const p = list.find(x => x && x.id === projectId);
    if (!p) return;
    p.aprovacoes = p.aprovacoes || {};
    p.aprovacoes[key] = !p.aprovacoes[key];
    p.historico = p.historico || [];
    p.historico.push({
      data: new Date().toISOString().slice(0, 10),
      evento: `Aprovação de ${APROVACOES_LABELS[key]} ${p.aprovacoes[key] ? 'concedida' : 'revogada'}`
    });
    Store.set('projects', list);
    Audit.log('Aprovação alterada', `${p.id} - ${APROVACOES_LABELS[key]}: ${p.aprovacoes[key] ? 'aprovado' : 'revogado'}`);
    toast('Aprovação atualizada.');
    const container = document.getElementById('module-container');
    if (container) Governance.render(container);
  }
};
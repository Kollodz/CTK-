/* ============================================================================
   kanban.js
   Módulo 7 - Kanban de Projetos (drag and drop)
   ============================================================================ */

const KANBAN_COLUMNS = ['Ideia', 'Triagem', 'Discovery', 'Business Case', 'Desenvolvimento', 'Testes', 'UAT', 'Produção'];

const Kanban = {
  // Helper defensivo para garantir retorno como Array válido
  getProjectsArray() {
    const raw = Store.get('projects', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.projects)) return raw.projects;
    return [];
  },

  render(container) {
    if (!container) return;

    // Busca garantida como Array antes do .filter
    const projects = this.getProjectsArray().filter(p => p && p.status !== 'Cancelado');

    container.innerHTML = `
      <div class="module-header">
        <h2>Kanban de Projetos</h2>
        <p class="module-subtitle">Arraste os cards entre colunas para atualizar o status. Alterações são salvas automaticamente.</p>
      </div>
      <div class="kanban-board">
        ${KANBAN_COLUMNS.map(col => `
          <div class="kanban-column" data-status="${col}">
            <div class="kanban-col-title">${col} <span class="kanban-count">${projects.filter(p => p && p.status === col).length}</span></div>
            <div class="kanban-cards" data-dropzone="${col}">
              ${projects.filter(p => p && p.status === col).map(p => `
                <div class="kanban-card" draggable="${Auth.permissao('podeEditar')}" data-id="${p.id}">
                  <div class="kanban-card-id">${Sanitize.html(p.id || '')}</div>
                  <div class="kanban-card-title">${Sanitize.html(p.nome || 'Sem nome')}</div>
                  <div class="kanban-card-meta">${Sanitize.html(p.area || '-')} · ${Sanitize.html(p.complexidade || '-')}</div>
                </div>`).join('')}
            </div>
          </div>
        `).join('')}
      </div>
    `;

    if (!Auth.permissao('podeEditar')) return;

    let draggedId = null;
    container.querySelectorAll('.kanban-card').forEach(card => {
      card.addEventListener('dragstart', () => {
        draggedId = card.dataset.id;
        card.classList.add('dragging');
      });
      card.addEventListener('dragend', () => card.classList.remove('dragging'));
    });

    container.querySelectorAll('.kanban-cards').forEach(zone => {
      zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('drag-over'); });
      zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
      zone.addEventListener('drop', (e) => {
        e.preventDefault();
        zone.classList.remove('drag-over');
        if (!draggedId) return;
        
        const list = this.getProjectsArray();
        const p = list.find(x => x && x.id === draggedId);
        if (p && p.status !== zone.dataset.dropzone) {
          const antigo = p.status;
          p.status = zone.dataset.dropzone;
          p.historico = p.historico || [];
          p.historico.push({ data: new Date().toISOString().slice(0, 10), evento: `Status alterado de ${antigo} para ${p.status} (Kanban)` });
          
          Store.set('projects', list);
          if (typeof StatusHistory !== 'undefined') StatusHistory.log(p.id, antigo, p.status);
          Audit.log('Status alterado via Kanban', `${p.id}: ${antigo} → ${p.status}`);
          toast(`${p.id} movido para ${p.status}`);
          
          const targetContainer = document.getElementById('module-container');
          if (targetContainer) Kanban.render(targetContainer);
        }
      });
    });
  }
};
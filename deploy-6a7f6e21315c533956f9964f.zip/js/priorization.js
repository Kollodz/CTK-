/* ============================================================================
   priorization.js
   Módulo 3 - Motor de Priorização Automática
   ============================================================================ */

const Priorization = {
  // Helper defensivo para garantir que 'projects' venha como Array válido
  getProjectsArray() {
    const raw = Store.get('projects', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.projects)) return raw.projects;
    return [];
  },

  render(container) {
    if (!container) return;

    // Busca garantida como Array antes de aplicar o .filter
    const projects = this.getProjectsArray().filter(p => p && p.status !== 'Cancelado');

    const ranked = projects.map(p => {
      const corp = Calc.scoreCorporativo(p) || 0;
      const classe = Calc.classificacaoPrioridade(corp) || 'Baixa';
      return {
        p,
        ice: Calc.scoreICE(p) || 0,
        rice: Calc.scoreRICE(p) || 0,
        corp,
        classe,
        badgeClass: String(classe).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      };
    }).sort((a, b) => b.corp - a.corp);

    container.innerHTML = `
      <div class="module-header">
        <h2>Priorização Automática</h2>
        <p class="module-subtitle">Ranking de projetos por Score Corporativo (combina ICE, RICE, risco, ROI e alinhamento estratégico)</p>
      </div>

      <div class="legend-row">
        <span class="badge badge-priority-critica">Crítica ≥ 75</span>
        <span class="badge badge-priority-alta">Alta ≥ 55</span>
        <span class="badge badge-priority-media">Média ≥ 35</span>
        <span class="badge badge-priority-baixa">Baixa &lt; 35</span>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead><tr>
            <th>#</th><th>Projeto</th><th>Área</th><th>Status</th>
            <th>ICE</th><th>RICE</th><th>Score Corporativo</th><th>Classificação</th>
          </tr></thead>
          <tbody>
            ${ranked.map((r, idx) => `
              <tr>
                <td>${idx + 1}</td>
                <td>${Sanitize.html(r.p.nome || 'Sem nome')}</td>
                <td>${Sanitize.html(r.p.area || '-')}</td>
                <td>${Sanitize.html(r.p.status || '-')}</td>
                <td>${r.ice}</td>
                <td>${r.rice}</td>
                <td><strong>${r.corp}</strong>
                  <div class="score-bar"><div class="score-bar-fill" style="width:${Math.min(100, Math.max(0, r.corp))}%"></div></div>
                </td>
                <td><span class="badge badge-priority-${r.badgeClass}">${Sanitize.html(r.classe)}</span></td>
              </tr>`).join('') || `<tr><td colspan="8" class="empty-state">Nenhum projeto ativo para priorizar.</td></tr>`}
          </tbody>
        </table>
      </div>

      <div class="info-box">
        <strong>Como o Score Corporativo é calculado:</strong>
        Impacto (20%) + Urgência (15%) + Volume (15%) + Risco invertido (15%) + Alinhamento Estratégico (15%) + ROI normalizado (20%), em escala 0–100.
        ICE = Impacto × Confiança × Facilidade. RICE = (Reach × Impacto × Confiança) ÷ Esforço.
      </div>
    `;
  }
};
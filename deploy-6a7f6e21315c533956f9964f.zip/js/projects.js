/* ============================================================================
   projects.js
   Módulo 2 - Cadastro e Gestão de Projetos (Integrado ao Supabase)
   ============================================================================ */

const STATUS_LIST = ['Ideia', 'Triagem', 'Discovery', 'Business Case', 'Desenvolvimento', 'Testes', 'UAT', 'Implantação', 'Produção', 'Cancelado'];
const COMPLEXIDADE_LIST = ['Baixa', 'Média', 'Alta', 'Muito Alta'];
const TECNOLOGIA_LIST = ['Power Automate', 'Power Automate Desktop', 'UiPath', 'Automation Anywhere', 'Python', 'VBA', 'Outro','Power BI','Relatórios', 'Outros'];

// Helper interno para evitar erros caso o toast não esteja importado globalmente
const notify = (msg, type = 'info') => {
  if (typeof toast === 'function') {
    toast(msg, type);
  } else {
    alert(`[${type.toUpperCase()}]: ${msg}`);
  }
};

const Projects = {
  filtro: { area: '', status: '', busca: '' },

  async render(container) {
    const rawProjects = await Store.get('projects', []);
    const projects = Array.isArray(rawProjects) ? rawProjects : [];
    const areas = [...new Set(projects.map(p => p.area).filter(Boolean))];

    container.innerHTML = `
      <div class="module-header">
        <h2>Cadastro de Projetos</h2>
        <p class="module-subtitle">Gerencie o portfólio de oportunidades de automação</p>
        <div class="header-actions">
          ${Auth.permissao('podeEditar') ? '<button class="btn btn-primary" id="btn-new-project">+ Novo Projeto</button>' : ''}
        </div>
      </div>

      <div class="filter-bar">
        <input type="text" id="f-busca" placeholder="Buscar por nome ou ID..." value="${Sanitize.html(this.filtro.busca)}">
        <select id="f-area"><option value="">Todas as Áreas</option>${areas.map(a => `<option ${a === this.filtro.area ? 'selected' : ''}>${Sanitize.html(a)}</option>`).join('')}</select>
        <select id="f-status"><option value="">Todos os Status</option>${STATUS_LIST.map(s => `<option ${s === this.filtro.status ? 'selected' : ''}>${s}</option>`).join('')}</select>
      </div>

      <div class="table-wrap">
        <table class="data-table" id="projects-table"></table>
      </div>
    `;

    document.getElementById('f-busca').addEventListener('input', (e) => { this.filtro.busca = e.target.value; this.renderTable(); });
    document.getElementById('f-area').addEventListener('change', (e) => { this.filtro.area = e.target.value; this.renderTable(); });
    document.getElementById('f-status').addEventListener('change', (e) => { this.filtro.status = e.target.value; this.renderTable(); });
    if (Auth.permissao('podeEditar')) {
      document.getElementById('btn-new-project').addEventListener('click', () => this.openForm());
    }

    await this.renderTable();
  },

  async renderTable() {
    const rawProjects = await Store.get('projects', []);
    let projects = Array.isArray(rawProjects) ? rawProjects : [];

    if (this.filtro.area) projects = projects.filter(p => p.area === this.filtro.area);
    if (this.filtro.status) projects = projects.filter(p => p.status === this.filtro.status);
    if (this.filtro.busca) {
      const q = this.filtro.busca.toLowerCase();
      projects = projects.filter(p => (p.nome && p.nome.toLowerCase().includes(q)) || (p.id && p.id.toLowerCase().includes(q)));
    }

    const table = document.getElementById('projects-table');
    table.innerHTML = `
      <thead><tr>
        <th>ID</th><th>Nome</th><th>Área</th><th>Status</th><th>Complexidade</th><th>Tecnologia</th><th>Responsável</th><th>Ações</th>
      </tr></thead>
      <tbody>
        ${projects.map(p => `
          <tr>
            <td>${p.id}</td>
            <td>${Sanitize.html(p.nome)}</td>
            <td>${Sanitize.html(p.area)}</td>
            <td><span class="badge badge-status-${slug(p.status || 'ideia')}">${p.status || 'Ideia'}</span></td>
            <td>${p.complexidade || '—'}</td>
            <td>${Sanitize.html(p.tecnologia)}</td>
            <td>${Sanitize.html(p.responsavel)}</td>
            <td class="row-actions">
              <button class="icon-btn" data-view="${p.id}" title="Ver detalhes">🔍</button>
              ${Auth.permissao('podeEditar') ? `<button class="icon-btn" data-edit="${p.id}" title="Editar">✏️</button>` : ''}
              ${Auth.permissao('podeExcluir') ? `<button class="icon-btn" data-del="${p.id}" title="Excluir">🗑️</button>` : ''}
            </td>
          </tr>`).join('') || `<tr><td colspan="8" class="empty-state">Nenhum projeto encontrado com os filtros atuais.</td></tr>`}
      </tbody>
    `;

    table.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => this.viewDetails(b.dataset.view)));
    table.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => this.openForm(b.dataset.edit)));
    table.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => this.deleteProject(b.dataset.del)));
  },

  async openForm(id = null) {
    const rawProjects = await Store.get('projects', []);
    const projects = Array.isArray(rawProjects) ? rawProjects : [];
    const settings = (await Store.get('settings')) || { valorHoraPadrao: 50 };
    const p = id ? projects.find(x => x.id === id) : {};
    const isEdit = !!id;

    Modal.open(isEdit ? `Editar Projeto — ${p.id}` : 'Novo Projeto', `
      <form id="project-form" class="form-grid">
        <label>Nome do Projeto<input required name="nome" value="${Sanitize.html(p.nome || '')}"></label>
        <label>Área<input required name="area" value="${Sanitize.html(p.area || '')}"></label>
        <label>Processo<input name="processo" value="${Sanitize.html(p.processo || '')}"></label>
        <label>Solicitante<input name="solicitante" value="${Sanitize.html(p.solicitante || '')}"></label>
        <label>Sponsor<input name="sponsor" value="${Sanitize.html(p.sponsor || '')}"></label>
        <label>Responsável<input name="responsavel" value="${Sanitize.html(p.responsavel || '')}"></label>
        <label>Data Solicitação<input type="date" name="dataSolicitacao" value="${p.data_solicitacao || p.dataSolicitacao || ''}"></label>
        <label>Data Aprovação<input type="date" name="dataAprovacao" value="${p.data_aprovacao || p.dataAprovacao || ''}"></label>
        <label>Previsão de Finalização<input type="date" name="dataPrevisaoFinalizacao" value="${p.previsao_finalizacao || p.dataPrevisaoFinalizacao || ''}"></label>
        <label>Status<select name="status">${STATUS_LIST.map(s => `<option ${p.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
        <label>Complexidade<select name="complexidade">${COMPLEXIDADE_LIST.map(s => `<option ${p.complexidade === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
        <label>Tecnologia<select name="tecnologia">${TECNOLOGIA_LIST.map(s => `<option ${p.tecnologia === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>

        <div class="form-section-title">Priorização (escala 1 a 5, exceto onde indicado)</div>
        <label>Impacto<input type="number" min="1" max="5" name="impacto" value="${p.impacto ?? 3}"></label>
        <label>Urgência<input type="number" min="1" max="5" name="urgencia" value="${p.urgencia ?? 3}"></label>
        <label>Volume<input type="number" min="1" max="5" name="volume" value="${p.volume ?? 3}"></label>
        <label>Risco<input type="number" min="1" max="5" name="riscoScore" value="${p.risco ?? p.riscoScore ?? 3}"></label>
        <label>Alinhamento Estratégico<input type="number" min="1" max="5" name="alinhamento" value="${p.alinhamento ?? 3}"></label>
        <label>Reach (pessoas/mês)<input type="number" min="0" name="reach" value="${p.reach ?? 100}"></label>
        <label>Confidence (%)<input type="number" min="0" max="100" name="confidence" value="${p.confidence ?? 70}"></label>
        <label>Effort (1 fácil - 8 difícil)<input type="number" min="1" max="8" name="effort" value="${p.effort ?? 3}"></label>

        <div class="form-section-title">Business Case</div>
        <label>Horas gastas atualmente (por execução)<input type="number" step="0.1" name="horasAtuais" value="${p.horas_gastas_atual ?? p.horasAtuais ?? 1}"></label>
        <label>Horas economizadas por execução<input type="number" step="0.1" name="horasPorExecucao" value="${p.horas_economizadas ?? p.horasPorExecucao ?? 0.3}"></label>
        <label>Execuções por dia (informativo)<input type="number" step="0.1" name="execucoesPorDia" value="${p.execucoes_dia ?? p.execucoesPorDia ?? 5}"></label>
        <label>Execuções por Semana<input required type="number" min="1" step="1" name="execucoesPorSemana" value="${p.execucoes_semana ?? p.execucoesPorSemana ?? 25}" placeholder="Ex.: 5"></label>
        <label>Valor Hora (R$)<input type="number" step="0.01" name="valorHora" value="${p.valor_hora ?? p.valorHora ?? settings.valorHoraPadrao}"></label>

        <div class="form-actions">
          <button type="button" class="btn btn-ghost" id="btn-cancel-form">Cancelar</button>
          <button type="submit" class="btn btn-primary">Salvar</button>
        </div>
      </form>
    `);

    document.getElementById('btn-cancel-form').addEventListener('click', Modal.close);
    document.getElementById('project-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const rawData = {};
      fd.forEach((v, k) => rawData[k] = v);

      const execucoesSemana = Number(rawData.execucoesPorSemana);
      if (!Number.isInteger(execucoesSemana) || execucoesSemana < 1) {
        notify('Execuções por Semana deve ser um número inteiro maior ou igual a 1.', 'warn');
        return;
      }

      // Payload mapeado diretamente para as colunas do Supabase
      const payload = {
        nome: Sanitize.input(rawData.nome),
        area: Sanitize.input(rawData.area),
        processo: Sanitize.input(rawData.processo),
        solicitante: Sanitize.input(rawData.solicitante),
        sponsor: Sanitize.input(rawData.sponsor),
        responsavel: Sanitize.input(rawData.responsavel),
        data_solicitacao: rawData.dataSolicitacao || null,
        data_aprovacao: rawData.dataAprovacao || null,
        previsao_finalizacao: rawData.dataPrevisaoFinalizacao || null,
        status: rawData.status || 'Ideia',
        complexidade: rawData.complexidade,
        tecnologia: rawData.tecnologia,
        impacto: Number(rawData.impacto) || 0,
        urgencia: Number(rawData.urgencia) || 0,
        volume: Number(rawData.volume) || 0,
        risco: Number(rawData.riscoScore) || 0,
        alinhamento: Number(rawData.alinhamento) || 0,
        reach: Number(rawData.reach) || 0,
        confidence: Number(rawData.confidence) || 0,
        effort: Number(rawData.effort) || 0,
        horas_gastas_atual: Number(rawData.horasAtuais) || 0,
        horas_economizadas: Number(rawData.horasPorExecucao) || 0,
        execucoes_dia: Number(rawData.execucoesPorDia) || 0,
        execucoes_semana: execucoesSemana,
        valor_hora: Number(rawData.valorHora) || 0,
        atualizado_em: new Date().toISOString()
      };

      const list = (await Store.get('projects', [])) || [];

      if (isEdit) {
        payload.id = p.id;
        const target = list.find(x => x.id === p.id);
        const statusAnterior = target ? target.status : null;

        const sucesso = await Store.set('projects', payload);
        if (!sucesso) {
          notify('Erro ao atualizar projeto no banco de dados. Verifique o console.', 'warn');
          return;
        }

        if (statusAnterior && statusAnterior !== payload.status) {
          await StatusHistory.log(payload.id, statusAnterior, payload.status);
        }
        await Audit.log('Projeto editado', payload.id + ' - ' + payload.nome);
      } else {
        payload.id = 'PRJ-' + String(list.length + 1).padStart(4, '0');
        payload.dados = {
          aprovacoes: { sponsor: false, ti: false, seguranca: false, compliance: false, lgpd: false },
          historico: [{ data: new Date().toISOString().slice(0, 10), evento: 'Solicitação registrada' }]
        };

        const sucesso = await Store.set('projects', payload);
        if (!sucesso) {
          notify('Erro ao salvar novo projeto no Supabase. Verifique se criou as colunas SQL.', 'warn');
          return;
        }

        await Audit.log('Projeto criado', payload.id + ' - ' + payload.nome);
      }

      Modal.close();
      notify(isEdit ? 'Projeto atualizado com sucesso.' : 'Projeto criado com sucesso.', 'success');
      await App.navigate('projects');
    });
  },

  async viewDetails(id) {
    const rawProjects = await Store.get('projects', []);
    const p = (Array.isArray(rawProjects) ? rawProjects : []).find(x => x.id === id);
    if (!p) return;

    // A normalização snake_case → camelCase agora acontece de forma central
    // em Store._writeCache (storage.js), então "p" já chega pronto para o Calc.
    const bc = Calc ? Calc.businessCase(p) : { roiPercent: 0, paybackMeses: 0, economiaAnual: 0 };
    const score = Calc ? Calc.scoreCorporativo(p) : 0;
    const classif = Calc ? Calc.classificacaoPrioridade(score) : '—';

    Modal.open(`${p.id} — ${Sanitize.html(p.nome)}`, `
      <div class="detail-grid">
        <div><strong>Área:</strong> ${Sanitize.html(p.area)}</div>
        <div><strong>Status:</strong> ${p.status || 'Ideia'}</div>
        <div><strong>Complexidade:</strong> ${p.complexidade || '—'}</div>
        <div><strong>Tecnologia:</strong> ${Sanitize.html(p.tecnologia)}</div>
        <div><strong>Responsável:</strong> ${Sanitize.html(p.responsavel)}</div>
        <div><strong>Sponsor:</strong> ${Sanitize.html(p.sponsor)}</div>
        <div><strong>Previsão de Finalização:</strong> ${p.previsao_finalizacao || p.dataPrevisaoFinalizacao ? formatDateBR(p.previsao_finalizacao || p.dataPrevisaoFinalizacao) : '—'}</div>
        <div><strong>Score Corporativo:</strong> ${score} (${classif})</div>
        <div><strong>ROI:</strong> ${bc.roiPercent}%</div>
        <div><strong>Payback:</strong> ${bc.paybackMeses ?? '-'} meses</div>
        <div><strong>Economia Anual:</strong> ${formatBRL(bc.economiaAnual)}</div>
      </div>
      <h4 style="margin-top:16px">Histórico</h4>
      <ul class="history-list">
        ${((p.dados && p.dados.historico) || p.historico || []).map(h => `<li><strong>${h.data}</strong> — ${Sanitize.html(h.evento)}</li>`).join('') || '<li>Sem histórico registrado.</li>'}
      </ul>
      <div class="form-actions"><button class="btn btn-ghost" id="btn-close-detail">Fechar</button></div>
    `);
    document.getElementById('btn-close-detail').addEventListener('click', Modal.close);
  },

  async deleteProject(id) {
    if (!confirm('Confirma a exclusão do projeto ' + id + '? Esta ação não pode ser desfeita.')) return;
    await Store.remove('projects', id);
    await Audit.log('Projeto excluído', id);
    notify('Projeto excluído.', 'warn');
    await this.renderTable();
  }
};

function slug(str) {
  if (!str) return 'ideia';
  return str.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, '-');
}
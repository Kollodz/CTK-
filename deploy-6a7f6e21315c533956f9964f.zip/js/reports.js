/* ============================================================================
   reports.js
   Módulo 12 - Relatórios Executivos
   ============================================================================ */

const Reports = {
  // Helpers defensivos para garantir retornos em Array
  getProjectsArray() {
    const raw = Store.get('projects', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.projects)) return raw.projects;
    return [];
  },

  getTeamArray() {
    const raw = Store.get('team', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.team)) return raw.team;
    return [];
  },

  getRisksArray() {
    const raw = Store.get('risks', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.risks)) return raw.risks;
    return [];
  },

  render(container) {
    if (!container) return;

    const projects = this.getProjectsArray();
    const team = this.getTeamArray();
    const risks = this.getRisksArray();

    const ranked = projects.filter(p => p && p.status !== 'Cancelado')
      .map(p => ({ p, corp: typeof Calc !== 'undefined' && Calc.scoreCorporativo ? Calc.scoreCorporativo(p) : 0 }))
      .sort((a, b) => b.corp - a.corp);

    const totalEconomiaAnual = projects.filter(p => p && p.status === 'Produção')
      .reduce((s, p) => {
        const econ = (typeof Calc !== 'undefined' && Calc.businessCase) ? Calc.businessCase(p).economiaAnual : 0;
        return s + (Number(econ) || 0);
      }, 0);

    const formattedEconomia = typeof formatBRL === 'function' ? formatBRL(totalEconomiaAnual) : `R$ ${totalEconomiaAnual}`;

    container.innerHTML = `
      <div class="module-header">
        <h2>Relatórios Executivos</h2>
        <p class="module-subtitle">Consolidado do portfólio para apresentação à liderança</p>
        <div class="header-actions">
          <button class="btn btn-secondary" id="btn-export-excel">📊 Exportar Excel</button>
          <button class="btn btn-secondary" id="btn-export-csv">📄 Exportar CSV</button>
          <button class="btn btn-secondary" id="btn-export-json">🗂️ Exportar JSON</button>
          <button class="btn btn-secondary" id="btn-export-pdf">🖨️ Exportar PDF</button>
        </div>
      </div>

      <div id="report-printable">
        <h3>1. Pipeline</h3>
        <p>${projects.length} projetos no portfólio, sendo ${projects.filter(p => p && p.status === 'Produção').length} em produção,
        ${projects.filter(p => p && p.status === 'Desenvolvimento').length} em desenvolvimento e
        ${projects.filter(p => p && p.status === 'Cancelado').length} cancelados.</p>

        <h3>2. Economia e ROI</h3>
        <p>Economia anual consolidada (projetos em produção): <strong>${formattedEconomia}</strong></p>

        <h3>3. Ranking de Prioridade (Top 10)</h3>
        <table class="data-table">
          <thead><tr><th>#</th><th>Projeto</th><th>Área</th><th>Score</th></tr></thead>
          <tbody>
            ${ranked.slice(0, 10).map((r, i) => `<tr><td>${i + 1}</td><td>${Sanitize.html(r.p.nome || '')}</td><td>${Sanitize.html(r.p.area || '')}</td><td>${r.corp}</td></tr>`).join('') || '<tr><td colspan="4">Nenhum projeto encontrado.</td></tr>'}
          </tbody>
        </table>

        <h3>4. Capacidade da Equipe</h3>
        <table class="data-table">
          <thead><tr><th>Membro</th><th>Papel</th><th>% Alocação</th></tr></thead>
          <tbody>
            ${team.map(m => {
              if (!m) return '';
              const percent = m.horasDisponiveis ? (typeof round1 === 'function' ? round1((m.horasAlocadas / m.horasDisponiveis) * 100) : Math.round((m.horasAlocadas / m.horasDisponiveis) * 100)) : 0;
              return `<tr><td>${Sanitize.html(m.nome || '')}</td><td>${Sanitize.html(m.papel || '')}</td><td>${percent}%</td></tr>`;
            }).join('') || '<tr><td colspan="3">Nenhum membro cadastrado.</td></tr>'}
          </tbody>
        </table>

        <h3>5. Riscos Críticos e Altos</h3>
        <table class="data-table">
          <thead><tr><th>Projeto</th><th>Risco</th><th>Nível</th></tr></thead>
          <tbody>
            ${risks.filter(r => {
              if (!r) return false;
              const nivel = typeof Calc !== 'undefined' && Calc.nivelRisco ? Calc.nivelRisco(r.probabilidade, r.impacto) : '';
              return ['Crítico', 'Alto'].includes(nivel);
            }).map(r => {
              const proj = projects.find(p => p && p.id === r.projetoId);
              const nivel = typeof Calc !== 'undefined' && Calc.nivelRisco ? Calc.nivelRisco(r.probabilidade, r.impacto) : '';
              return `<tr><td>${proj ? Sanitize.html(proj.nome || '') : Sanitize.html(r.projetoId || '')}</td><td>${Sanitize.html(r.risco || '')}</td><td>${Sanitize.html(nivel || '')}</td></tr>`;
            }).join('') || '<tr><td colspan="3">Nenhum risco crítico ou alto no momento.</td></tr>'}
          </tbody>
        </table>
      </div>
    `;

    const btnExcel = document.getElementById('btn-export-excel');
    if (btnExcel) btnExcel.addEventListener('click', () => typeof Exporter !== 'undefined' && Exporter.exportExcel());

    const btnCSV = document.getElementById('btn-export-csv');
    if (btnCSV) btnCSV.addEventListener('click', () => typeof Exporter !== 'undefined' && Exporter.exportCSV());

    const btnJSON = document.getElementById('btn-export-json');
    if (btnJSON) btnJSON.addEventListener('click', () => typeof Exporter !== 'undefined' && Exporter.exportJSON());

    const btnPDF = document.getElementById('btn-export-pdf');
    if (btnPDF) btnPDF.addEventListener('click', () => typeof Exporter !== 'undefined' && Exporter.exportPDF());
  }
};
/* ============================================================================
   risks.js
   Módulo 10 - Gestão de Riscos
   ============================================================================ */

const Risks = {
  // Helpers defensivos para garantir retornos em Array
  getRisksArray() {
    const raw = Store.get('risks', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.risks)) return raw.risks;
    return [];
  },

  getProjectsArray() {
    const raw = Store.get('projects', []);
    if (Array.isArray(raw)) return raw;
    if (raw && typeof raw === 'object' && Array.isArray(raw.projects)) return raw.projects;
    return [];
  },

  render(container) {
    if (!container) return;

    // Busca protegida para garantir listas válidas
    const risks = this.getRisksArray();
    const projects = this.getProjectsArray();

    container.innerHTML = `
      <div class="module-header">
        <h2>Gestão de Riscos</h2>
        <p class="module-subtitle">Matriz de riscos do portfólio de automações</p>
        <div class="header-actions">
          ${Auth.permissao('podeEditar') ? '<button class="btn btn-primary" id="btn-new-risk">+ Novo Risco</button>' : ''}
        </div>
      </div>

      <div class="risk-matrix">
        ${this.buildMatrix(risks)}
      </div>

      <div class="table-wrap" style="margin-top:24px">
        <table class="data-table">
          <thead><tr><th>Projeto</th><th>Risco</th><th>Probabilidade</th><th>Impacto</th><th>Nível</th><th>Mitigação</th><th>Responsável</th>${Auth.permissao('podeExcluir') ? '<th>Ações</th>' : ''}</tr></thead>
          <tbody>
            ${risks.map(r => {
              if (!r) return '';
              const proj = projects.find(p => p && p.id === r.projetoId);
              const nivel = Calc.nivelRisco(r.probabilidade, r.impacto);
              const badgeClass = String(nivel || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
              return `<tr>
                <td>${proj ? Sanitize.html(proj.nome || '') : Sanitize.html(r.projetoId || '')}</td>
                <td>${Sanitize.html(r.risco || '')}</td>
                <td>${r.probabilidade || 0}/5</td>
                <td>${r.impacto || 0}/5</td>
                <td><span class="badge badge-risk-${badgeClass}">${Sanitize.html(nivel || '')}</span></td>
                <td>${Sanitize.html(r.mitigacao || '')}</td>
                <td>${Sanitize.html(r.responsavel || '')}</td>
                ${Auth.permissao('podeExcluir') ? `<td class="row-actions"><button class="icon-btn" data-del="${r.id}" title="Excluir">🗑️</button></td>` : ''}
              </tr>`;
            }).join('') || `<tr><td colspan="8" class="empty-state">Nenhum risco cadastrado.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;

    if (Auth.permissao('podeEditar')) {
      const btnNew = document.getElementById('btn-new-risk');
      if (btnNew) btnNew.addEventListener('click', () => this.openForm());
    }
    if (Auth.permissao('podeExcluir')) {
      container.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => this.deleteRisk(b.dataset.del)));
    }
  },

  buildMatrix(risks) {
    // Garante que risks seja um array na construção da matriz
    const safeRisks = Array.isArray(risks) ? risks : this.getRisksArray();

    let html = '<div class="matrix-grid">';
    html += '<div class="matrix-corner"></div>';
    for (let i = 1; i <= 5; i++) html += `<div class="matrix-head">Impacto ${i}</div>`;
    for (let prob = 5; prob >= 1; prob--) {
      html += `<div class="matrix-head">Prob. ${prob}</div>`;
      for (let imp = 1; imp <= 5; imp++) {
        const nivel = Calc.nivelRisco(prob, imp);
        const cellClass = String(nivel || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        const count = safeRisks.filter(r => r && Number(r.probabilidade) === prob && Number(r.impacto) === imp).length;
        html += `<div class="matrix-cell matrix-${cellClass}">${count > 0 ? count : ''}</div>`;
      }
    }
    html += '</div>';
    return html;
  },

  openForm() {
    const projects = this.getProjectsArray();
    Modal.open('Novo Risco', `
      <form id="risk-form" class="form-grid">
        <label>Projeto<select name="projetoId">${projects.map(p => p ? `<option value="${p.id}">${Sanitize.html(p.id || '')} — ${Sanitize.html(p.nome || 'Sem nome')}</option>` : '').join('')}</select></label>
        <label>Descrição do Risco<input required name="risco"></label>
        <label>Probabilidade (1-5)<input type="number" min="1" max="5" name="probabilidade" value="3"></label>
        <label>Impacto (1-5)<input type="number" min="1" max="5" name="impacto" value="3"></label>
        <label>Mitigação<input name="mitigacao"></label>
        <label>Responsável<input name="responsavel"></label>
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" id="btn-cancel-risk">Cancelar</button>
          <button type="submit" class="btn btn-primary">Salvar</button>
        </div>
      </form>
    `);

    const btnCancel = document.getElementById('btn-cancel-risk');
    if (btnCancel) btnCancel.addEventListener('click', Modal.close);

    const form = document.getElementById('risk-form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const data = {};
        fd.forEach((v, k) => data[k] = Sanitize.input(String(v)));
        data.probabilidade = Number(data.probabilidade) || 1;
        data.impacto = Number(data.impacto) || 1;

        const list = this.getRisksArray();
        data.id = 'RSK-' + String(list.length + 1).padStart(4, '0');
        list.push(data);
        Store.set('risks', list);
        Audit.log('Risco cadastrado', data.id + ' - ' + data.risco);
        Modal.close();
        toast('Risco cadastrado.');
        const container = document.getElementById('module-container');
        if (container) Risks.render(container);
      });
    }
  },

  deleteRisk(id) {
    const list = this.getRisksArray();
    const target = list.find(x => x && x.id === id);
    if (!target) return;

    if (!confirm('Tem certeza que deseja excluir este registro? Esta ação não poderá ser desfeita.')) return;

    const updated = list.filter(x => x && x.id !== id);
    Store.set('risks', updated);
    Audit.log('Riscos: Risco excluído', target.id + ' - ' + target.risco);
    toast('Registro excluído.', 'warn');
    const container = document.getElementById('module-container');
    if (container) Risks.render(container);
  }
};
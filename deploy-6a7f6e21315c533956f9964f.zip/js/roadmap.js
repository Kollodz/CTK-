/* ============================================================================
   roadmap.js
   Módulo 6 - Roadmap (visual estilo Gantt em CSS puro)
   ============================================================================ */

const Roadmap = {
  filtro: { area: '' },

  // Helper para garantir retorno SEMPRE como um Array válido
  getProjectsArray() {
    const raw = Store.get('projects', []);
    if (Array.isArray(raw)) return raw;
    // Se o valor armazenado for objeto (ex: { projects: [...] }), tenta extrair ou limpa
    if (raw && typeof raw === 'object' && Array.isArray(raw.projects)) return raw.projects;
    return [];
  },

  // Helper interno defensivo para formatação e parse de datas
  parseDate(d) {
    if (!d) return null;
    const dateStr = typeof d === 'string' && d.length === 10 ? `${d}T00:00:00` : d;
    const date = new Date(dateStr);
    return isNaN(date.getTime()) ? null : date.getTime();
  },

  render(container) {
    if (!container) return;

    const projects = this.getProjectsArray().filter(p => p && p.status !== 'Cancelado' && p.dataSolicitacao);
    const areas = [...new Set(projects.map(p => p.area))].filter(Boolean);

    const safeSanitize = (str) => (typeof Sanitize !== 'undefined' && Sanitize.html) ? Sanitize.html(str) : String(str ?? '');

    container.innerHTML = `
      <div class="module-header">
        <h2>Roadmap</h2>
        <p class="module-subtitle">Cronograma visual do portfólio (Solicitação → Aprovação → Produção)</p>
      </div>
      <div class="filter-bar">
        <select id="rm-area">
          <option value="">Todas as Áreas</option>
          ${areas.map(a => `<option value="${safeSanitize(a)}" ${a === this.filtro.area ? 'selected' : ''}>${safeSanitize(a)}</option>`).join('')}
        </select>
      </div>
      <div class="legend-row">
        <span class="badge badge-gantt-planejado">Planejado</span>
        <span class="badge badge-gantt-execucao">Em Execução</span>
        <span class="badge badge-gantt-concluido">Concluído</span>
        <span class="badge badge-gantt-atrasado">Atrasado</span>
      </div>
      <p class="module-subtitle" style="margin-bottom:14px">
        Barras com listras claras = sem "Previsão de Finalização" cadastrada (estimativa automática de 90 dias). Preencha o campo no cadastro do projeto para uma data real aqui.
      </p>
      <div id="rm-content" class="gantt-wrap"></div>
    `;

    const selectArea = document.getElementById('rm-area');
    if (selectArea) {
      selectArea.addEventListener('change', (e) => { 
        this.filtro.area = e.target.value; 
        this.renderChart(); 
      });
    }
    
    this.renderChart();
  },

  renderChart() {
    let projects = this.getProjectsArray().filter(p => p && p.status !== 'Cancelado' && p.dataSolicitacao);
    if (this.filtro.area) {
      projects = projects.filter(p => p.area === this.filtro.area);
    }

    const el = document.getElementById('rm-content');
    if (!el) return;

    if (!projects.length) { 
      el.innerHTML = '<p class="empty-state">Nenhum projeto para exibir.</p>'; 
      return; 
    }

    const today = Date.now();

    const fimEstimadoOuReal = (p, start) => {
      const prev = this.parseDate(p.dataPrevisaoFinalizacao);
      if (prev) return prev;
      
      const aprov = this.parseDate(p.dataAprovacao);
      if (p.status === 'Produção' && aprov) return aprov + (60 * 86400000);
      
      return start + (90 * 86400000);
    };

    const projectsWithDates = projects.map(p => {
      const start = this.parseDate(p.dataSolicitacao) || today;
      let fim = fimEstimadoOuReal(p, start);

      if (fim < start) fim = start + (1 * 86400000);

      return { ...p, start, fim };
    });

    const dates = projectsWithDates.map(p => p.start);
    const minDate = Math.min(...dates, today);
    const maxDate = Math.max(today, ...projectsWithDates.map(p => p.fim));
    const span = (maxDate - minDate) || 1;

    const safeSanitize = (str) => (typeof Sanitize !== 'undefined' && Sanitize.html) ? Sanitize.html(str) : String(str ?? '');
    const safeTruncate = (str, len) => (typeof truncate === 'function') ? truncate(str, len) : (str && str.length > len ? str.slice(0, len) + '...' : str);
    const safeFormatDate = (d) => (typeof formatDateBR === 'function') ? formatDateBR(d) : (d ? new Date(d).toLocaleDateString('pt-BR') : '-');

    el.innerHTML = projectsWithDates.map(p => {
      const isConcluido = p.status === 'Produção';
      const temPrevisaoReal = !!p.dataPrevisaoFinalizacao;
      const atrasado = !isConcluido && p.fim < today;

      const leftPct = Math.max(0, Math.min(100, ((p.start - minDate) / span) * 100));
      const widthPct = Math.max(2, Math.min(100 - leftPct, ((p.fim - p.start) / span) * 100));

      let estado = 'planejado';
      if (isConcluido) estado = 'concluido';
      else if (atrasado) estado = 'atrasado';
      else if (['Desenvolvimento', 'Testes', 'UAT', 'Implantação'].includes(p.status)) estado = 'execucao';

      const tooltipTitle = `${p.status}${temPrevisaoReal ? ' — previsão: ' + safeFormatDate(p.dataPrevisaoFinalizacao) : ' — estimativa (sem previsão cadastrada)'}`;

      return `
        <div class="gantt-row">
          <div class="gantt-label" title="${safeSanitize(p.nome)}">${safeSanitize(safeTruncate(p.nome, 28))}</div>
          <div class="gantt-track">
            <div class="gantt-bar gantt-${estado} ${temPrevisaoReal ? '' : 'gantt-bar-estimado'}" style="left:${leftPct.toFixed(2)}%; width:${widthPct.toFixed(2)}%" title="${safeSanitize(tooltipTitle)}"></div>
          </div>
        </div>
      `;
    }).join('');
  }
};
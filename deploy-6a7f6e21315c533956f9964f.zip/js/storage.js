/* ============================================================================
   storage.js — cache local síncrono + sincronização real com o Supabase

   Store.get() continua síncrono de propósito (dezenas de telas no projeto
   chamam Store.get('projects') sem await) — ele lê de um cache em memória
   que é "aquecido" com os dados reais do Supabase logo após o login, via
   Store.warmUp(). Antes disso, o cache só existia se alguém tivesse gravado
   localmente antes — por isso em um navegador/computador novo a tela vinha
   vazia mesmo com dados no banco.

   Store.set() e Store.remove() gravam no cache local IMEDIATAMENTE (pra
   quem não dá await continuar funcionando igual antes) e devolvem uma
   Promise que só resolve depois da gravação no Supabase de verdade —
   quem der await consegue checar se a gravação real deu certo.
   ============================================================================ */

const Sanitize = {
  html(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  },
  input(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/<script[^>]*>.*?<\/script>/gi, '').trim();
  }
};

const TABLE_MAP = {
  'projects': 'rpa_projetos',
  'team': 'rpa_equipe',
  'risks': 'rpa_riscos',
  'settings': 'rpa_parametros',
  'discovery': 'rpa_discovery',
  'status_historico': 'rpa_status_historico',
  'users': 'rpa_usuarios',
  'audit_log': 'rpa_audit_log',
  'chamados': 'rpa_chamados'
};

const ARRAY_KEYS = ['projects', 'team', 'risks', 'discovery', 'users', 'audit_log', 'status_historico', 'chamados'];
const GENERIC_JSONB_KEYS = ['team', 'risks', 'discovery'];

const PROMOTED_COLUMNS = {
  discovery: ['gravacaoUrl']
};

function normalizeGenericRecord(row) {
  if (!row || typeof row !== 'object') return row;
  const { dados, ...rest } = row;
  return { ...rest, ...(dados && typeof dados === 'object' ? dados : {}) };
}
/**
 * Normaliza um registro de projeto vindo do Supabase (snake_case) para os
 * nomes camelCase que calc.js e as telas (Dashboard, Business Case,
 * Priorização, Relatórios, Detalhes) esperam. Sem isso, só o modal de
 * detalhes (projects.js → viewDetails) fazia essa conversão manualmente —
 * em todo o resto horasPorExecucao/execucoesPorSemana chegavam undefined e
 * o cálculo de horas/economia dava zero.
 *
 * Fica centralizado aqui (na escrita do cache) para que QUALQUER lugar que
 * chame Store.get('projects') já receba os dados prontos para o Calc,
 * sem precisar lembrar de converter.
 */
function normalizeProjectRecord(p) {
  if (!p || typeof p !== 'object') return p;
  return {
    ...p,
    horasAtuais: p.horas_gastas_atual ?? p.horasAtuais ?? 0,
    horasPorExecucao: p.horas_economizadas ?? p.horasPorExecucao ?? 0,
    execucoesPorDia: p.execucoes_dia ?? p.execucoesPorDia ?? 0,
    execucoesPorSemana: p.execucoes_semana ?? p.execucoesPorSemana ?? 0,
    valorHora: p.valor_hora ?? p.valorHora ?? 0,
    riscoScore: p.risco ?? p.riscoScore ?? 3,
    dataSolicitacao: p.data_solicitacao ?? p.dataSolicitacao ?? null,
    dataAprovacao: p.data_aprovacao ?? p.dataAprovacao ?? null
  };
}

// Campos camelCase que normalizeProjectRecord() adiciona e que NÃO existem
// como colunas no Supabase (são só espelho dos campos snake_case reais,
// pra uso interno do Calc). Precisam ser removidos antes de qualquer upsert,
// senão o Supabase rejeita a gravação por coluna inexistente.
const PROJECT_SYNTHETIC_FIELDS = ['horasAtuais', 'horasPorExecucao', 'execucoesPorDia', 'execucoesPorSemana', 'valorHora', 'riscoScore', 'dataSolicitacao', 'dataAprovacao'];

function notifyError(msg) {
  console.error('[Store]', msg);
  if (typeof toast === 'function') {
    toast(msg, 'warn');
  } else if (typeof Toast === 'object' && Toast && typeof Toast.show === 'function') {
    Toast.show(msg, 'warn');
  }
  // Se nada disso existir, ainda assim o erro fica visível no console
  // (bem melhor que o comportamento antigo, que engolia o erro em silêncio).
}

const Store = {
  PREFIX: 'rpa_',
  _cache: {},
  _warmedUp: false,

  _getTableName(key) {
    const cleanKey = key.replace(/^rpa_/, '');
    return TABLE_MAP[cleanKey] || `rpa_${cleanKey}`;
  },

  /**
   * Busca TODAS as tabelas do Supabase de uma vez e preenche o cache local.
   * Precisa ser chamado (com await) depois do login/restauração de sessão
   * e antes de renderizar qualquer módulo — é isso que "esquenta" o cache
   * pra calc.js, audit.js etc. lerem Store.get('settings') de forma síncrona
   * e já com dado real, sem precisar reescrever essas telas pra usar await.
   */
  async warmUp() {
    if (!window.supabaseClient) return false;

    const keys = Object.keys(TABLE_MAP);
    await Promise.all(keys.map(async (key) => {
      try {
        const tableName = TABLE_MAP[key];
        const { data, error } = await window.supabaseClient.from(tableName).select('*');

        if (error) {
          notifyError(`Não foi possível carregar "${tableName}" do banco: ${error.message}`);
          return;
        }

        if (key === 'settings') {
          // settings é um registro único, não uma lista
          const record = Array.isArray(data) ? (data[0] || {}) : (data || {});
          this._writeCache('settings', record);
        } else {
          this._writeCache(key, Array.isArray(data) ? data : []);
        }
      } catch (e) {
        notifyError(`Erro de conexão ao carregar dados de "${key}": ${e.message || e}`);
      }
    }));

    this._warmedUp = true;
    return true;
  },

  _writeCache(cleanKey, data) {
  if (cleanKey === 'projects') {
    data = Array.isArray(data) ? data.map(normalizeProjectRecord) : normalizeProjectRecord(data);
  } else if (GENERIC_JSONB_KEYS.includes(cleanKey)) {
    data = Array.isArray(data) ? data.map(normalizeGenericRecord) : normalizeGenericRecord(data);
  }
  this._cache[cleanKey] = data;
  try {
    const jsonString = JSON.stringify(data);
    localStorage.setItem(this.PREFIX + cleanKey, jsonString);
  } catch (e) {
    console.warn('Store: Não foi possível persistir cache local', e);
  }
},

  get(key, fallback = null) {
    const cleanKey = key.replace(/^rpa_/, '');

    if (this._cache[cleanKey] !== undefined) {
      return this._cache[cleanKey];
    }

    // Fallback pra antes do warmUp rodar (ex.: primeiro paint da tela de login)
    try {
      const raw = localStorage.getItem(`${this.PREFIX}${cleanKey}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed !== null && parsed !== undefined) {
          let result = ARRAY_KEYS.includes(cleanKey) && !Array.isArray(parsed) ? [parsed] : parsed;
          if (cleanKey === 'projects' && Array.isArray(result)) {
            result = result.map(normalizeProjectRecord);
          }
          return result;
        }
      }
    } catch (e) {
      console.warn(`[Store] Erro ao ler cache local '${key}':`, e);
    }

    return ARRAY_KEYS.includes(cleanKey) ? (fallback || []) : fallback;
  },

  /**
   * Grava local (síncrono) e sincroniza com o Supabase (assíncrono).
   * Retorna uma Promise<boolean> — true só se a gravação no Supabase
   * também deu certo. Quem não der await continua tendo o efeito local
   * imediato de antes.
   */
  async set(key, data) {
    const cleanKey = key.replace(/^rpa_/, '');
    let finalData = data;

    try {
      if (ARRAY_KEYS.includes(cleanKey) && typeof data === 'object' && data !== null && !Array.isArray(data)) {
        const currentList = this.get(cleanKey, []);
        const list = Array.isArray(currentList) ? [...currentList] : [];

        if (data.id) {
          const index = list.findIndex(item => String(item.id) === String(data.id));
          if (index !== -1) list[index] = { ...list[index], ...data };
          else list.push(data);
        } else {
          data.id = Date.now();
          list.push(data);
        }
        finalData = list;
      }

      this._writeCache(cleanKey, finalData);
    } catch (e) {
      notifyError(`Erro ao salvar localmente '${key}': ${e.message || e}`);
      return false;
    }

    return this._syncToSupabase(cleanKey, finalData);
  },

  async _syncToSupabase(key, data) {
    if (!window.supabaseClient) {
      notifyError('Sem conexão com o banco de dados — os dados só foram salvos neste navegador.');
      return false;
    }

    const tableName = this._getTableName(key);

    try {
      let itemsToSync = [];
      if (Array.isArray(data)) {
        itemsToSync = data.map((item, index) => this._prepareItem(item, index, key));
      } else if (typeof data === 'object' && data !== null) {
        itemsToSync = [this._prepareItem(data, 0, key)];
      }
      if (!itemsToSync.length) return true;

      const { error } = await window.supabaseClient
        .from(tableName)
        .upsert(itemsToSync, { onConflict: 'id' });

      if (error) {
        notifyError(`Não foi possível salvar em "${tableName}": ${error.message}`);
        return false;
      }
      return true;
    } catch (e) {
      notifyError(`Erro de conexão ao salvar em "${tableName}": ${e.message || e}`);
      return false;
    }
  },

  _prepareItem(item, index, key) {
  if (!item || typeof item !== 'object') return null;
  let clean = { ...item };

  if (key === 'projects') {
    PROJECT_SYNTHETIC_FIELDS.forEach(f => delete clean[f]);
  } else if (GENERIC_JSONB_KEYS.includes(key)) {
    const promoted = PROMOTED_COLUMNS[key] || [];
    const { id, ...fieldsRest } = clean;
    promoted.forEach(f => delete fieldsRest[f]);

    const wrapped = { id };
    promoted.forEach(f => {
      if (clean[f] !== undefined) wrapped[f] = clean[f];
    });
    wrapped.dados = fieldsRest;
    clean = wrapped;
  }

  if (!clean.id) {
    clean.id = Date.now() + index;
  } else if (typeof clean.id === 'string' && !isNaN(clean.id)) {
    clean.id = parseInt(clean.id, 10);
  }

  Object.keys(clean).forEach(k => {
    if (clean[k] === undefined || clean[k] === null) delete clean[k];
  });
  return clean;
},
  /** Força releitura de uma tabela específica direto do Supabase. */
  async fetchFromSupabase(key, fallback = null) {
    const cleanKey = key.replace(/^rpa_/, '');
    if (!window.supabaseClient) return this.get(cleanKey, fallback);

    const tableName = this._getTableName(cleanKey);

    try {
      const { data, error } = await window.supabaseClient.from(tableName).select('*');

      if (error) {
        notifyError(`Erro ao buscar "${tableName}": ${error.message}`);
        return this.get(cleanKey, fallback);
      }

      const finalData = cleanKey === 'settings'
        ? (Array.isArray(data) ? (data[0] || {}) : (data || {}))
        : (Array.isArray(data) ? data : []);

      this._writeCache(cleanKey, finalData);
      return finalData;
    } catch (e) {
      notifyError(`Erro de conexão ao carregar "${tableName}": ${e.message || e}`);
      return this.get(cleanKey, fallback);
    }
  },

  async remove(key, id) {
    const cleanKey = key.replace(/^rpa_/, '');

    try {
      const current = this.get(cleanKey, []);
      if (Array.isArray(current) && id) {
        this._writeCache(cleanKey, current.filter(item => String(item.id) !== String(id)));
      }
    } catch (e) {
      notifyError(`Erro ao remover localmente [${key}]: ${e.message || e}`);
    }

    if (!window.supabaseClient || !id) return true;

    const tableName = this._getTableName(cleanKey);
    try {
      const { error } = await window.supabaseClient.from(tableName).delete().eq('id', id);
      if (error) {
        notifyError(`Não foi possível remover em "${tableName}": ${error.message}`);
        return false;
      }
      return true;
    } catch (e) {
      notifyError(`Erro de conexão ao remover em "${tableName}": ${e.message || e}`);
      return false;
    }
  },

  /**
   * Grava SÓ a entrada nova (INSERT puro, sem "id" nenhum no payload) —
   * usado por logs (audit_log, status_historico), que são tabelas só de
   * inserção. Diferente de Store.set(), isto NUNCA reenvia a lista inteira
   * nem inventa um id do lado do cliente: o Postgres gera o id sozinho
   * (coluna uuid com gen_random_uuid(), ou bigserial). Foi esse "inventar
   * id" no caminho genérico que causava o erro
   * "invalid input syntax for type uuid" — um Date.now() não é um uuid.
   */
  async appendOnly(key, entry) {
    const cleanKey = key.replace(/^rpa_/, '');

    // Cache local: acrescenta a entrada nova sem reenviar tudo
    const current = this.get(cleanKey, []);
    this._writeCache(cleanKey, Array.isArray(current) ? [...current, entry] : [entry]);

    if (!window.supabaseClient) {
      notifyError('Sem conexão com o banco de dados — o registro só foi salvo neste navegador.');
      return false;
    }

    const tableName = this._getTableName(cleanKey);
    try {
      const { id, ...entrySemId } = entry; // garante que nenhum id "inventado" vá para o insert
      const { error } = await window.supabaseClient.from(tableName).insert(entrySemId);
      if (error) {
        notifyError(`Não foi possível salvar em "${tableName}": ${error.message}`);
        return false;
      }
      return true;
    } catch (e) {
      notifyError(`Erro de conexão ao salvar em "${tableName}": ${e.message || e}`);
      return false;
    }
  }
};

/* Módulo de Log e Auditoria */
const Audit = {
  async log(acao, detalhes = '') {
    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;
    const now = new Date();

    const newEntry = {
      usuario: user ? user.username : 'sistema',
      perfil: user ? user.perfil : '-',
      data: now.toLocaleDateString('pt-BR'),
      hora: now.toLocaleTimeString('pt-BR'),
      timestamp: now.toISOString(),
      acao,
      detalhes
    };

    await Store.appendOnly('audit_log', newEntry);
  },

  all() {
    return Store.get('audit_log', []);
  }
};

/* Módulo de Histórico de Status */
const StatusHistory = {
  async log(projetoId, statusAnterior, statusNovo) {
    const user = typeof Auth !== 'undefined' && Auth.currentUser ? Auth.currentUser() : null;

    const entry = {
      projeto_id: projetoId,
      status_anterior: statusAnterior || '-',
      status_novo: statusNovo,
      data: new Date().toISOString(),
      usuario: user ? user.username : 'sistema'
    };

    await Store.appendOnly('status_historico', entry);
  },

  all() {
    return Store.get('status_historico', []);
  }
};

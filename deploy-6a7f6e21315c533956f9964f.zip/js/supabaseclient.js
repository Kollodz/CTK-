/* supabaseClient.js */
const SUPABASE_URL = 'https://skcxxyeaavqtyorbignl.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrY3h4eWVhYXZxdHlvcmJpZ25sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODUyNzg1MDQsImV4cCI6MjEwMDg1NDUwNH0.dPEvodNYVe-fuG3Hp41fx-hDKVZW6lprddJXFcWdTOg';

// Inicializa o cliente garantindo captura de exceções de Storage
try {
  window.supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: {
      persistSession: true,   // necessário: sem isso a sessão do Supabase Auth some no F5
      autoRefreshToken: true,
      storageKey: 'rpa-governance-auth'
    }
  });
} catch (e) {
  console.error('Falha ao inicializar o Supabase:', e);
}
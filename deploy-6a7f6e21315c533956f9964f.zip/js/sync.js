/* ============================================================================
   sync.js
   Base de Dados Compartilhada — export/import do Banco_RPA.xlsx, para que
   usuários em computadores diferentes vejam os mesmos projetos (e possam
   logar com a mesma conta em qualquer máquina).
   ============================================================================ */

const Sync = {
  // Helper interno do objeto Sync para notificações sem poluir o escopo global
  notify(msg, type = 'info') {
    if (typeof toast === 'function') {
      toast(msg, type);
    } else if (typeof Toast === 'object' && typeof Toast.show === 'function') {
      Toast.show(msg, type);
    } else {
      alert(`[${type.toUpperCase()}]: ${msg}`);
    }
  },

  async render(container) {
    if (!Auth.permissao('podeEditar')) {
      container.innerHTML = `<div class="module-header"><h2>Base de Dados Compartilhada</h2></div><p class="empty-state">Acesso restrito a quem pode editar dados do sistema.</p>`;
      return;
    }

    const settings = (await Store.get('settings')) || {};
    const podeImportar = Auth.permissao('podeAprovar'); // Administrador e Gestor

    container.innerHTML = `
      <div class="module-header">
        <h2>🔄 Base de Dados Compartilhada</h2>
        <p class="module-subtitle">Compartilhe os mesmos projetos, riscos, equipe e usuários entre computadores diferentes</p>
      </div>

      <div class="info-box">
        <strong>Como funciona:</strong> este sistema sincroniza dados via Supabase / arquivo Excel.<br><br>
        1️⃣ Você clica em <strong>Exportar</strong> e salva o arquivo <code>Banco_RPA.xlsx</code> em uma pasta compartilhada.<br>
        2️⃣ A outra pessoa clica em <strong>Importar</strong>, selecionando esse mesmo arquivo — o sistema mostra um resumo do que será trazido antes de aplicar no banco.<br>
        3️⃣ Os dados serão atualizados e sincronizados no banco de dados.<br><br>
        ⚠️ <strong>Atenção:</strong> Ao importar, os registros locais/atuais do banco de dados serão sobrescritos pelas informações do arquivo.<br><br>
        ✏️ <strong>Pode editar o arquivo no Excel antes de reimportar.</strong> É um .xlsx de verdade — abra, ajuste o que precisar (menos os nomes das abas e colunas) e salve normalmente.
      </div>

      <div class="sync-grid">
        <div class="sync-card">
          <h3>📤 Exportar</h3>
          <p>Gera o <code>Banco_RPA.xlsx</code> com projetos (incluindo datas e a previsão de finalização), equipe, riscos, ideias de Discovery, usuários, histórico de status e parâmetros atuais.</p>
          ${settings.ultimaExportacaoBase ? `<p class="sync-timestamp">Última exportação: ${new Date(settings.ultimaExportacaoBase).toLocaleString('pt-BR')}</p>` : ''}
          <button class="btn btn-primary" id="btn-sync-export">📤 Exportar Banco_RPA.xlsx</button>
        </div>

        <div class="sync-card">
          <h3>📥 Importar</h3>
          <p>Lê um <code>Banco_RPA.xlsx</code> (gerado por este sistema ou editado no Excel) e atualiza os dados no Supabase.</p>
          ${settings.ultimaImportacaoBase ? `<p class="sync-timestamp">Última importação: ${new Date(settings.ultimaImportacaoBase).toLocaleString('pt-BR')}</p>` : ''}
          ${podeImportar ? `
            <input type="file" id="sync-import-file" accept=".xlsx,.xls" class="hidden">
            <button class="btn btn-secondary" id="btn-sync-import">📥 Selecionar arquivo e Importar</button>
          ` : `<p class="empty-state">Somente Administrador ou Gestor podem importar (isso sobrescreve os dados locais).</p>`}
        </div>
      </div>
    `;

    document.getElementById('btn-sync-export').addEventListener('click', () => Exporter.exportDatabase());

    if (podeImportar) {
      const fileInput = document.getElementById('sync-import-file');
      document.getElementById('btn-sync-import').addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', async () => {
        const file = fileInput.files[0];
        fileInput.value = ''; // permite selecionar o mesmo arquivo de novo depois
        if (!file) return;

        try {
          const parsed = await Exporter.parseDatabaseFile(file);
          
          const resumo = [
            parsed.projects ? `${parsed.projects.length} projetos` : null,
            parsed.discovery ? `${parsed.discovery.length} ideias de Discovery` : null,
            parsed.team ? `${parsed.team.length} membros de equipe` : null,
            parsed.risks ? `${parsed.risks.length} riscos` : null,
            parsed.usuarios && parsed.usuarios.length ? `${parsed.usuarios.length} usuários` : null
          ].filter(Boolean).join(', ');

          const confirmado = confirm(
            `Este arquivo contém: ${resumo || 'dados de importação'}.\n\n` +
            `Isso vai SUBSTITUIR os dados atuais do banco de dados pelos dados do arquivo. Deseja continuar?`
          );
          if (!confirmado) return;

          this.notify('Importando dados para o banco de dados... Por favor, aguarde.', 'info');

          // Aguarda a gravação no Supabase
          const res = await Exporter.commitDatabaseImport(parsed);
          
          this.notify(`Base importada com sucesso: ${res?.projetos ?? parsed.projects?.length ?? 0} projetos processados.`, 'success');
          
          if (typeof App !== 'undefined' && App.navigate) {
            App.navigate('sync');
          }
        } catch (err) {
          console.error('Erro na importação da base:', err);
          this.notify('Falha ao importar: ' + (err.message || 'Erro desconhecido ao processar arquivo'), 'warn');
        }
      });
    }
  }
};
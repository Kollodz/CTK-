/* ============================================================================
   users.js
   Módulo — Gestão de Usuários (cadastro e nível de permissão via Supabase)

   Mudou junto com o auth.js: criar usuário agora também cria uma conta real
   no Supabase Auth (signUp), porque é isso que autentica de verdade. Como
   signUp troca a sessão ativa do navegador para o usuário recém-criado, a
   gente guarda o token do admin ANTES e restaura DEPOIS — senão o admin
   seria deslogado toda vez que cadastrasse alguém.

   Limitação conhecida (arquitetura só-frontend, sem servidor próprio):
   excluir um usuário aqui remove o cadastro/perfil dele (rpa_usuarios), mas
   NÃO remove a conta em auth.users — isso só é possível com a chave de
   serviço (service role), que nunca deve ficar no navegador. Pra remover de
   vez, é preciso apagar manualmente em Supabase Dashboard > Authentication.
   ============================================================================ */

const PERFIL_LIST = ['Administrador', 'Gestor', 'Desenvolvedor', 'Visualizador', 'Usuário Solicitante'];

const PERFIL_DESCRICAO = {
  Administrador: 'Acesso total: edita, aprova, exclui e gerencia usuários.',
  Gestor: 'Edita e aprova projetos, mas não exclui nem gerencia usuários.',
  Desenvolvedor: 'Edita projetos, equipe e riscos, sem aprovar nem gerenciar usuários.',
  Visualizador: 'Apenas consulta — não pode editar nada no sistema.',
  'Usuário Solicitante': 'Acesso restrito apenas à tela de Discovery — para enviar novas ideias de automação, sem ver o restante do sistema.'
};

// AUTH_EMAIL_DOMAIN já é declarado em auth.js (que carrega antes deste
// arquivo) — reutilizamos a mesma constante aqui, sem redeclarar, porque
// declarar "const" com o mesmo nome duas vezes no mesmo escopo global é um
// erro fatal de sintaxe que travava este arquivo inteiro.

const Users = {
  async render(container) {
    const currentUser = Auth.currentUser();
    const currentUsername = currentUser ? currentUser.username : '';
    const isAdmin = currentUser && currentUser.perfil === 'Administrador';

    // Se não tiver perfil para gerenciar usuários, mostra só a própria ficha
    if (!isAdmin && !currentUser) {
      container.innerHTML = `
        <div class="module-header"><h2>Usuários</h2></div>
        <p class="empty-state">Sessão expirada. Faça login novamente.</p>`;
      return;
    }

    const { data: allUsers = [], error } = await window.supabaseClient.from('rpa_usuarios').select('*');
    if (error && typeof toast === 'function') toast('Erro ao carregar usuários: ' + error.message, 'warn');

    // Admin vê todos, demais veem apenas o próprio usuário
    const users = isAdmin
      ? (allUsers || [])
      : (allUsers || []).filter(u => u.username === currentUsername);

    container.innerHTML = `
      <div class="module-header">
        <h2>Gestão de Usuários</h2>
        <p class="module-subtitle">Cadastro de usuários e definição do nível de permissão de cada um</p>
        <div class="header-actions">
          ${isAdmin ? '<button class="btn btn-primary" id="btn-new-user">+ Novo Usuário</button>' : ''}
        </div>
      </div>

      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Usuário</th><th>Nome</th><th>Perfil</th><th>Ações</th></tr></thead>
          <tbody>
            ${(users || []).map(u => `
              <tr>
                <td>${Sanitize.html(u.username)}${u.username === currentUsername ? ' <span class="badge badge-capacity-disponivel">você</span>' : ''}</td>
                <td>${Sanitize.html(u.nome)}</td>
                <td><span class="badge badge-perfil-${typeof slug === 'function' ? slug(u.perfil) : u.perfil.toLowerCase()}">${u.perfil}</span></td>
                <td class="row-actions">
                  ${isAdmin ? `<button class="icon-btn" data-edit="${Sanitize.html(u.username)}" title="Editar">✏️</button>` : ''}
                  <button class="icon-btn" data-reset="${Sanitize.html(u.username)}" title="Alterar senha">🔑</button>
                  ${isAdmin ? `<button class="icon-btn" data-del="${Sanitize.html(u.username)}" title="Excluir">🗑️</button>` : ''}
                </td>
              </tr>`).join('') || `<tr><td colspan="4" class="empty-state">Nenhum usuário cadastrado.</td></tr>`}
          </tbody>
        </table>
      </div>

      <div class="info-box">
        <strong>Níveis de permissão:</strong><br>
        ${PERFIL_LIST.map(p => `• <strong>${p}</strong>: ${PERFIL_DESCRICAO[p]}`).join('<br>')}
      </div>
    `;

    if (isAdmin) {
      const btnNew = document.getElementById('btn-new-user');
      if (btnNew) btnNew.addEventListener('click', () => this.openForm());
      container.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => this.openForm(b.dataset.edit)));
      container.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => this.deleteUser(b.dataset.del)));
    }

    // Sempre permite alterar senha (próprio usuário ou admin)
    container.querySelectorAll('[data-reset]').forEach(b =>
      b.addEventListener('click', () => this.openChangePasswordDialog(b.dataset.reset, users))
    );
  },

  async openForm(username = null) {
    const { data: users = [] } = await window.supabaseClient.from('rpa_usuarios').select('*');
    const u = username ? users.find(x => x.username === username) : null;
    const isEdit = !!u;

    Modal.open(isEdit ? `Editar Usuário — ${Sanitize.html(u.username)}` : 'Novo Usuário', `
      <form id="user-form" class="form-grid">
        <label>Nome de usuário (login)
          <input required name="username" ${isEdit ? 'readonly' : ''} value="${isEdit ? Sanitize.html(u.username) : ''}" placeholder="ex: jsilva">
        </label>
        <label>Nome completo<input required name="nome" value="${isEdit ? Sanitize.html(u.nome) : ''}"></label>
        <label>Perfil de acesso
          <select name="perfil">${PERFIL_LIST.map(p => `<option ${u && u.perfil === p ? 'selected' : ''}>${p}</option>`).join('')}</select>
        </label>
        ${isEdit ? '' : `
        <label>E-mail (opcional — se deixar em branco, gera um automático interno)
          <input type="email" name="email" placeholder="ex: nome@empresa.com.br">
        </label>
        <label>Senha inicial
          <input type="password" name="senha" required minlength="6" placeholder="mínimo 6 caracteres" autocomplete="new-password">
        </label>`}
        ${isEdit ? '<p class="form-hint">Pra trocar a senha deste usuário, use o botão 🔑 "Enviar redefinição de senha" na listagem.</p>' : ''}
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" id="btn-cancel-user">Cancelar</button>
          <button type="submit" class="btn btn-primary">Salvar</button>
        </div>
      </form>
    `);

    document.getElementById('btn-cancel-user').addEventListener('click', Modal.close);

    document.getElementById('user-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const inputUsername = Sanitize.input(fd.get('username')).trim();
      const nome = Sanitize.input(fd.get('nome')).trim();
      const perfil = fd.get('perfil');
      const senha = fd.get('senha');
      const emailInformado = Sanitize.input(fd.get('email') || '').trim();

      if (!inputUsername || !nome) { if (typeof toast === 'function') toast('Preencha usuário e nome.', 'warn'); return; }

      if (isEdit) {
        const { error } = await window.supabaseClient
          .from('rpa_usuarios')
          .update({ nome, perfil })
          .eq('username', u.username);

        if (error) { if (typeof toast === 'function') toast('Erro ao atualizar usuário.', 'warn'); return; }
        if (typeof Audit !== 'undefined') await Audit.log('Usuário editado', u.username);
      } else {
        if (users.some(x => x.username.toLowerCase() === inputUsername.toLowerCase())) {
          if (typeof toast === 'function') toast('Já existe um usuário com esse login.', 'warn');
          return;
        }

        const created = await this._createUserWithAuth({ username: inputUsername, nome, perfil, senha, email: emailInformado });
        if (!created.ok) {
          if (typeof toast === 'function') toast(created.msg, 'warn');
          return;
        }
        if (typeof Audit !== 'undefined') await Audit.log('Usuário criado', inputUsername);
      }

      Modal.close();
      if (typeof toast === 'function') toast('Usuário salvo com sucesso.');
      if (typeof App !== 'undefined' && App.navigate) {
        App.navigate('users');
      } else {
        Users.render(document.getElementById('module-container'));
      }
    });
  },
async openChangePasswordDialog(targetUsername, users) {
  const currentUser = Auth.currentUser();
  const isAdmin = currentUser && currentUser.perfil === 'Administrador';
  const isSelf = currentUser && currentUser.username === targetUsername;

  const target = users.find(u => u.username === targetUsername);
  if (!target) return;

  // Se for o usuário logado ou qualquer perfil sem admin, fluxo de troca da própria senha
  if (isSelf || !isAdmin) {
    Modal.open('Alterar minha senha', `
      <form id="change-pass-form" class="form-grid">
        <label>Senha atual
          <input type="password" name="current" required>
        </label>
        <label>Nova senha
          <input type="password" name="new" required minlength="6">
        </label>
        <div class="form-actions">
          <button type="button" class="btn btn-ghost" id="btn-cancel-pass">Cancelar</button>
          <button type="submit" class="btn btn-primary">Salvar nova senha</button>
        </div>
      </form>
    `);

    document.getElementById('btn-cancel-pass').addEventListener('click', Modal.close);

    document.getElementById('change-pass-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const current = fd.get('current');
      const newer = fd.get('new');

      const result = await Auth.changeOwnPassword(current, newer);
      if (!result.ok) {
        if (typeof toast === 'function') toast(result.msg, 'warn');
        return;
      }

      if (typeof toast === 'function') toast('Senha alterada com sucesso.');
      Modal.close();
    });
  } else {
    // Administrador alterando senha de outro usuário – aqui, por segurança,
    // o ideal é combinar a senha com o usuário e ele mesmo usar o fluxo acima.
    Modal.open(`Alterar senha de ${Sanitize.html(targetUsername)}`, `
      <p class="form-hint">
        Por segurança, o administrador não altera diretamente a senha pelo navegador.
        Oriente o usuário a usar a opção "Alterar senha" com a senha atual fornecida.
      </p>
      <div class="form-actions">
        <button type="button" class="btn btn-primary" id="btn-ok-admin-msg">OK</button>
      </div>
    `);
    document.getElementById('btn-ok-admin-msg').addEventListener('click', Modal.close);
  }
},
  /**
   * Cria a conta real no Supabase Auth + a linha de perfil em rpa_usuarios,
   * preservando a sessão do admin que está criando o usuário (signUp troca
   * a sessão ativa do cliente, então guardamos o token do admin antes e
   * restauramos depois).
   */
  async _createUserWithAuth({ username, nome, perfil, senha, email: emailInformado }) {
    const client = window.supabaseClient;
    const email = emailInformado || `${username.toLowerCase()}@${AUTH_EMAIL_DOMAIN}`;

    const { data: { session: adminSession } } = await client.auth.getSession();

    const { data: signUpData, error: signUpErr } = await client.auth.signUp({
      email,
      password: senha,
      options: { data: { username } }
    });

    // Restaura a sessão do admin imediatamente, antes de qualquer outra chamada.
    if (adminSession) {
      await client.auth.setSession({
        access_token: adminSession.access_token,
        refresh_token: adminSession.refresh_token
      });
    }

    if (signUpErr) {
      return { ok: false, msg: 'Erro ao criar conta de acesso: ' + signUpErr.message };
    }

    const authUid = signUpData?.user?.id || null;

    const { error: insertErr } = await client
      .from('rpa_usuarios')
      .insert([{
        username,
        nome,
        perfil,
        email,
        auth_uid: authUid,
        precisaTrocarSenha: true  // nova coluna
  }]);

    if (insertErr) {
      return { ok: false, msg: 'Conta de acesso criada, mas houve erro ao salvar o perfil: ' + insertErr.message };
    }

    return { ok: true };
  },

  /**
   * Não temos como definir a senha de outra pessoa a partir do navegador
   * (isso exigiria a chave de serviço). O caminho seguro é enviar um link
   * de redefinição pro e-mail sintético — funciona se o projeto Supabase
   * tiver SMTP configurado; caso contrário, oriente o usuário a trocar a
   * própria senha pela tela de perfil após o primeiro login.
   */
  async sendPasswordReset(username, users) {
    const u = users.find(x => x.username === username);
    if (!u) return;
    const email = u.email || `${username.toLowerCase()}@${AUTH_EMAIL_DOMAIN}`;

    const { error } = await window.supabaseClient.auth.resetPasswordForEmail(email);
    if (error) {
      if (typeof toast === 'function') toast('Erro ao solicitar redefinição: ' + error.message, 'warn');
      return;
    }
    if (typeof toast === 'function') toast('Solicitação de redefinição enviada (depende do e-mail configurado no projeto Supabase).');
  },

  async deleteUser(username) {
    const { data: list = [] } = await window.supabaseClient.from('rpa_usuarios').select('*');
    const currentUsername = Auth.currentUser() ? Auth.currentUser().username : '';

    if (username === currentUsername) {
      if (typeof toast === 'function') toast('Você não pode excluir o próprio usuário logado.', 'warn');
      return;
    }

    const target = list.find(x => x.username === username);
    if (!target) return;

    const totalAdmins = list.filter(x => x.perfil === 'Administrador').length;
    if (target.perfil === 'Administrador' && totalAdmins <= 1) {
      if (typeof toast === 'function') toast('Não é possível excluir o único Administrador do sistema.', 'warn');
      return;
    }

    if (!confirm(`Confirma a exclusão do usuário "${username}"? Isso remove o perfil dele do sistema (o acesso é revogado), mas a conta de autenticação só pode ser apagada de vez pelo Supabase Dashboard. Esta ação não pode ser desfeita.`)) return;

    const { error } = await window.supabaseClient
      .from('rpa_usuarios')
      .delete()
      .eq('username', username);

    if (error) { if (typeof toast === 'function') toast('Erro ao excluir usuário.', 'warn'); return; }

    if (typeof Audit !== 'undefined') await Audit.log('Usuário excluído', username);
    if (typeof toast === 'function') toast('Usuário excluído.', 'warn');
    Users.render(document.getElementById('module-container'));
  }
};

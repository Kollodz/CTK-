-- ============================================================================
-- 001_fix_auth_rls.sql
-- Rode isso no SQL Editor do Supabase (Project > SQL Editor > New query).
-- É seguro rodar mais de uma vez (idempotente): se algo já existir, ele pula.
-- ============================================================================

-- 1) Coluna de e-mail sintético em rpa_usuarios (Supabase Auth exige e-mail,
--    mas o sistema continua usando "username" pra logar).
alter table public.rpa_usuarios
  add column if not exists email text;

update public.rpa_usuarios
  set email = lower(username) || '@rpa.local'
  where email is null;

-- Garante unicidade do e-mail (necessário pra casar 1:1 com auth.users)
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'rpa_usuarios_email_key'
  ) then
    alter table public.rpa_usuarios add constraint rpa_usuarios_email_key unique (email);
  end if;
end $$;

-- 2) Coluna auth_uid pra linkar cada linha de rpa_usuarios ao usuário real
--    criado em auth.users (preenchida pelo script de migração one-time).
alter table public.rpa_usuarios
  add column if not exists auth_uid uuid;

-- ============================================================================
-- 3) Row Level Security — a partir de agora só quem tem sessão autenticada
--    de verdade (via Supabase Auth) consegue ler/gravar. É isso que resolve
--    o "storage.js não se comunica com o Supabase": antes, o cliente nunca
--    virava "authenticated", então TODA leitura/escrita era barrada aqui.
-- ============================================================================
do $$
declare
  t text;
begin
  for t in select unnest(array[
    'rpa_projetos','rpa_equipe','rpa_riscos','rpa_parametros',
    'rpa_discovery','rpa_status_historico','rpa_usuarios','rpa_audit_log'
  ])
  loop
    execute format('alter table public.%I enable row level security;', t);

    execute format('drop policy if exists %I on public.%I;', t || '_select', t);
    execute format(
      'create policy %I on public.%I for select using (auth.role() = ''authenticated'');',
      t || '_select', t
    );

    execute format('drop policy if exists %I on public.%I;', t || '_insert', t);
    execute format(
      'create policy %I on public.%I for insert with check (auth.role() = ''authenticated'');',
      t || '_insert', t
    );

    execute format('drop policy if exists %I on public.%I;', t || '_update', t);
    execute format(
      'create policy %I on public.%I for update using (auth.role() = ''authenticated'') with check (auth.role() = ''authenticated'');',
      t || '_update', t
    );

    execute format('drop policy if exists %I on public.%I;', t || '_delete', t);
    execute format(
      'create policy %I on public.%I for delete using (auth.role() = ''authenticated'');',
      t || '_delete', t
    );
  end loop;
end $$;

-- ATENÇÃO: rode isso e depois execute o arquivo migrate-usuarios.html (na raiz
-- do projeto) ANTES de testar o login — ele cria a conta real no Supabase Auth
-- pra cada linha de rpa_usuarios usando a senha que já está lá.
-- Só depois disso rode o 002_remove_plaintext_passwords.sql.

-- ============================================================================
-- 001b_temp_open_migration.sql
-- Rode ISSO antes de abrir o migrate-usuarios.html.
-- Ele abre uma brecha temporária (só na tabela rpa_usuarios, só select e
-- update) pra permitir o script de migração rodar sem sessão autenticada
-- (já que ainda não existe nenhuma conta real no Supabase Auth ainda).
--
-- Assim que a migração terminar com sucesso, rode o 001c_lock_back_down.sql
-- pra fechar essa brecha de novo. NÃO deixe isso ativo em produção.
-- ============================================================================

drop policy if exists rpa_usuarios_temp_anon_select on public.rpa_usuarios;
create policy rpa_usuarios_temp_anon_select
  on public.rpa_usuarios for select
  using (true);

drop policy if exists rpa_usuarios_temp_anon_update on public.rpa_usuarios;
create policy rpa_usuarios_temp_anon_update
  on public.rpa_usuarios for update
  using (true)
  with check (true);

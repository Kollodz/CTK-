-- ============================================================================
-- 001c_lock_back_down.sql
-- Rode ISSO depois que o migrate-usuarios.html terminar e você confirmar
-- (no Supabase Dashboard > Authentication > Users) que todos os usuários
-- foram criados e têm auth_uid preenchido em rpa_usuarios.
--
-- Isso remove a brecha temporária aberta pelo 001b — a partir daqui,
-- rpa_usuarios volta a exigir sessão autenticada pra select/update, igual
-- às outras tabelas.
-- ============================================================================

drop policy if exists rpa_usuarios_temp_anon_select on public.rpa_usuarios;
drop policy if exists rpa_usuarios_temp_anon_update on public.rpa_usuarios;

-- Confira que ninguém ficou de fora antes de seguir pro 002:
select username, auth_uid from public.rpa_usuarios where auth_uid is null;

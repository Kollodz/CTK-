-- ============================================================================
-- 002_remove_plaintext_passwords.sql
-- SÓ RODE ISSO DEPOIS de:
--   1) rodar 001_fix_auth_rls.sql
--   2) abrir migrate-usuarios.html e confirmar que todos os usuários
--      foram criados no Supabase Auth (auth_uid preenchido pra todo mundo)
--   3) testar login com pelo menos um usuário de cada perfil
--
-- Depois disso, a senha não precisa (e não deve) mais existir em texto
-- puro na tabela — quem autentica de verdade agora é o Supabase Auth.
-- ============================================================================

-- Confirma que todo mundo já tem auth_uid antes de apagar a senha:
-- select username, auth_uid from public.rpa_usuarios where auth_uid is null;
-- (se essa consulta retornar alguma linha, NÃO rode o update abaixo ainda)

update public.rpa_usuarios set senha = null;

-- Opcional (mais radical): remover a coluna de vez.
-- alter table public.rpa_usuarios drop column if exists senha;

-- ============================================================================
-- 003_lookup_email_function.sql
-- Necessário porque agora aceitamos e-mail real (não só o sintético
-- usuario@rpa.local) na hora de criar usuários. Pra logar com "username",
-- o app precisa descobrir qual e-mail está associado ANTES de autenticar
-- (ou seja, sem sessão ainda) — e o RLS normal bloquearia essa consulta.
--
-- Esta função resolve isso com segurança: ela só devolve o e-mail
-- correspondente a um username (nada mais da tabela), e roda com
-- SECURITY DEFINER pra ignorar o RLS só nesse caso pontual e controlado.
-- ============================================================================

create or replace function public.rpa_lookup_email(p_username text)
returns text
language sql
security definer
set search_path = public
as $$
  select email from public.rpa_usuarios where lower(username) = lower(p_username) limit 1;
$$;

grant execute on function public.rpa_lookup_email(text) to anon, authenticated;

-- ============================================================================
-- 004_discovery_gravacoes_storage.sql
-- Rode isso no SQL Editor do Supabase (Project > SQL Editor > New query).
-- É seguro rodar mais de uma vez (idempotente).
--
-- Cria o bucket de Storage onde ficam as gravações de tela feitas na tela de
-- Discovery (Discovery → Nova Ideia → botão "Gravar tela do processo"), e a
-- coluna que guarda a URL do vídeo no registro de discovery.
-- ============================================================================

-- 1) Bucket público (o vídeo é acessado só pelo link salvo no registro, não
--    fica listado em lugar nenhum — "público" aqui só evita ter que gerar
--    signed URL toda vez que alguém abre a lista de ideias no Discovery).
insert into storage.buckets (id, name, public)
values ('discovery-gravacoes', 'discovery-gravacoes', true)
on conflict (id) do nothing;

-- 2) Só usuário autenticado (logado no sistema) pode enviar/ler gravações.
drop policy if exists "discovery_gravacoes_insert" on storage.objects;
create policy "discovery_gravacoes_insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'discovery-gravacoes');

drop policy if exists "discovery_gravacoes_select" on storage.objects;
create policy "discovery_gravacoes_select"
  on storage.objects for select to authenticated
  using (bucket_id = 'discovery-gravacoes');

drop policy if exists "discovery_gravacoes_delete" on storage.objects;
create policy "discovery_gravacoes_delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'discovery-gravacoes');

-- 3) Coluna que guarda a URL pública do vídeo no registro de Discovery.
--    Entre aspas porque a tabela rpa_discovery usa nomes de coluna em
--    camelCase (mesmo padrão de nomeIdeia, areaSolicitante etc.).
alter table public.rpa_discovery
  add column if not exists "gravacaoUrl" text;

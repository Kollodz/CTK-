-- ============================================================================
-- 005_chamados.sql
-- Rode isso no SQL Editor do Supabase (Project > SQL Editor > New query).
-- É seguro rodar mais de uma vez (idempotente).
--
-- Cria a tabela por trás da tela de Chamados (Help Desk). Segue o mesmo
-- modelo de segurança já usado nas outras tabelas do sistema (001_fix_auth_rls.sql):
-- qualquer usuário autenticado pode ler/gravar, e é a própria tela
-- (js/chamados.js) que filtra "só os meus chamados" para quem não é
-- Administrador/Gestor/Desenvolvedor — igual já acontece hoje em Discovery
-- com "Minhas Ideias" vs "Todas as Ideias".
-- ============================================================================

create table if not exists public.rpa_chamados (
  id text primary key,
  titulo text not null,
  categoria text,
  prioridade text,
  descricao text,
  status text not null default 'Aberto',
  solicitante text not null,
  "solicitanteNome" text,
  "criadoEm" timestamptz not null default now(),
  "atualizadoEm" timestamptz not null default now(),
  mensagens jsonb not null default '[]'::jsonb
);

alter table public.rpa_chamados enable row level security;

drop policy if exists rpa_chamados_select on public.rpa_chamados;
create policy rpa_chamados_select
  on public.rpa_chamados for select
  using (auth.role() = 'authenticated');

drop policy if exists rpa_chamados_insert on public.rpa_chamados;
create policy rpa_chamados_insert
  on public.rpa_chamados for insert
  with check (auth.role() = 'authenticated');

drop policy if exists rpa_chamados_update on public.rpa_chamados;
create policy rpa_chamados_update
  on public.rpa_chamados for update
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

drop policy if exists rpa_chamados_delete on public.rpa_chamados;
create policy rpa_chamados_delete
  on public.rpa_chamados for delete
  using (auth.role() = 'authenticated');

-- ============================================================================
-- 006_rls_por_perfil.sql
-- Corrige o Achado #1 (crítico) e #4 (alto) da auditoria de segurança:
-- hoje TODAS as tabelas usam "auth.role() = 'authenticated'" pra tudo —
-- ou seja, qualquer pessoa logada, de qualquer perfil, pode ler/editar/
-- excluir QUALQUER registro, inclusive se promover a Administrador.
-- Este script substitui isso por regras que respeitam o mesmo RBAC que já
-- existe em js/auth.js (PERFIS: podeEditar, podeExcluir, podeAprovar,
-- podeGerenciarUsuarios). É seguro rodar mais de uma vez (idempotente).
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Função auxiliar: perfil do usuário autenticado atual
-- ---------------------------------------------------------------------------
create or replace function public.rpa_perfil_atual()
returns text
language sql stable
security definer
set search_path = public
as $$
  select perfil from public.rpa_usuarios where auth_uid = auth.uid() limit 1;
$$;

grant execute on function public.rpa_perfil_atual() to authenticated;

-- ---------------------------------------------------------------------------
-- rpa_projetos / rpa_equipe / rpa_riscos
-- Leitura: qualquer autenticado. Criar/editar: podeEditar (Administrador,
-- Gestor, Desenvolvedor). Excluir: só Administrador (podeExcluir).
-- ---------------------------------------------------------------------------
do $$
declare
  t text;
begin
  foreach t in array array['rpa_projetos', 'rpa_equipe', 'rpa_riscos']
  loop
    execute format('drop policy if exists %I on public.%I;', t || '_select', t);
    execute format('create policy %I on public.%I for select using (auth.role() = ''authenticated'');', t || '_select', t);

    execute format('drop policy if exists %I on public.%I;', t || '_insert', t);
    execute format('create policy %I on public.%I for insert with check (rpa_perfil_atual() in (''Administrador'',''Gestor'',''Desenvolvedor''));', t || '_insert', t);

    execute format('drop policy if exists %I on public.%I;', t || '_update', t);
    execute format('create policy %I on public.%I for update using (rpa_perfil_atual() in (''Administrador'',''Gestor'',''Desenvolvedor'')) with check (rpa_perfil_atual() in (''Administrador'',''Gestor'',''Desenvolvedor''));', t || '_update', t);

    execute format('drop policy if exists %I on public.%I;', t || '_delete', t);
    execute format('create policy %I on public.%I for delete using (rpa_perfil_atual() = ''Administrador'');', t || '_delete', t);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- rpa_parametros: só Administrador mexe nas configurações do sistema
-- ---------------------------------------------------------------------------
drop policy if exists rpa_parametros_select on public.rpa_parametros;
create policy rpa_parametros_select on public.rpa_parametros for select using (auth.role() = 'authenticated');

drop policy if exists rpa_parametros_insert on public.rpa_parametros;
create policy rpa_parametros_insert on public.rpa_parametros for insert with check (rpa_perfil_atual() = 'Administrador');

drop policy if exists rpa_parametros_update on public.rpa_parametros;
create policy rpa_parametros_update on public.rpa_parametros for update using (rpa_perfil_atual() = 'Administrador') with check (rpa_perfil_atual() = 'Administrador');

drop policy if exists rpa_parametros_delete on public.rpa_parametros;
create policy rpa_parametros_delete on public.rpa_parametros for delete using (rpa_perfil_atual() = 'Administrador');

-- ---------------------------------------------------------------------------
-- rpa_discovery: qualquer autenticado pode enviar uma ideia; só vê as
-- próprias, exceto quem pode editar (Administrador/Gestor/Desenvolvedor),
-- que vê e converte todas — igual ao filtro que já existe na tela.
-- ---------------------------------------------------------------------------
drop policy if exists rpa_discovery_select on public.rpa_discovery;
create policy rpa_discovery_select
  on public.rpa_discovery for select
  using (
    "criadoPor" = rpa_username_atual()
    or rpa_perfil_atual() in ('Administrador', 'Gestor', 'Desenvolvedor')
  );

drop policy if exists rpa_discovery_insert on public.rpa_discovery;
create policy rpa_discovery_insert on public.rpa_discovery for insert with check (auth.role() = 'authenticated');

drop policy if exists rpa_discovery_update on public.rpa_discovery;
create policy rpa_discovery_update
  on public.rpa_discovery for update
  using (rpa_perfil_atual() in ('Administrador', 'Gestor', 'Desenvolvedor'))
  with check (rpa_perfil_atual() in ('Administrador', 'Gestor', 'Desenvolvedor'));

drop policy if exists rpa_discovery_delete on public.rpa_discovery;
create policy rpa_discovery_delete on public.rpa_discovery for delete using (rpa_perfil_atual() = 'Administrador');

-- Função auxiliar usada acima (username do usuário autenticado atual)
create or replace function public.rpa_username_atual()
returns text
language sql stable
security definer
set search_path = public
as $$
  select username from public.rpa_usuarios where auth_uid = auth.uid() limit 1;
$$;
grant execute on function public.rpa_username_atual() to authenticated;

-- ---------------------------------------------------------------------------
-- rpa_status_historico: log de mudança de status — todo autenticado lê e
-- insere; ninguém edita ou apaga (histórico é imutável).
-- ---------------------------------------------------------------------------
drop policy if exists rpa_status_historico_select on public.rpa_status_historico;
create policy rpa_status_historico_select on public.rpa_status_historico for select using (auth.role() = 'authenticated');

drop policy if exists rpa_status_historico_insert on public.rpa_status_historico;
create policy rpa_status_historico_insert on public.rpa_status_historico for insert with check (auth.role() = 'authenticated');

drop policy if exists rpa_status_historico_update on public.rpa_status_historico;
drop policy if exists rpa_status_historico_delete on public.rpa_status_historico;
-- (sem policy de update/delete = ninguém consegue, nem Administrador via API)

-- ---------------------------------------------------------------------------
-- rpa_audit_log (Achado #4): imutável. Leitura restrita a quem vê o painel
-- de segurança (Administrador e Gestor, igual à tela hoje). Sem update/delete
-- pra ninguém — um log que pode ser apagado por quem o gerou não serve
-- pra rastreabilidade.
-- ---------------------------------------------------------------------------
drop policy if exists rpa_audit_log_select on public.rpa_audit_log;
create policy rpa_audit_log_select
  on public.rpa_audit_log for select
  using (rpa_perfil_atual() in ('Administrador', 'Gestor'));

drop policy if exists rpa_audit_log_insert on public.rpa_audit_log;
create policy rpa_audit_log_insert on public.rpa_audit_log for insert with check (auth.role() = 'authenticated');

drop policy if exists rpa_audit_log_update on public.rpa_audit_log;
drop policy if exists rpa_audit_log_delete on public.rpa_audit_log;
-- (sem policy de update/delete = ninguém consegue apagar/alterar o log)

-- ---------------------------------------------------------------------------
-- rpa_usuarios: todo autenticado lê (a tela precisa listar nomes/perfis).
-- Update: Administrador edita qualquer linha; qualquer outra pessoa só edita
-- a PRÓPRIA linha, e só se o perfil enviado for igual ao que já está salvo
-- (ou seja, dá pra atualizar precisaTrocarSenha/nome, mas NÃO dá pra um
-- usuário comum mudar o próprio perfil pra "Administrador" via API).
-- ---------------------------------------------------------------------------
drop policy if exists rpa_usuarios_select on public.rpa_usuarios;
create policy rpa_usuarios_select on public.rpa_usuarios for select using (auth.role() = 'authenticated');

drop policy if exists rpa_usuarios_insert on public.rpa_usuarios;
create policy rpa_usuarios_insert on public.rpa_usuarios for insert with check (rpa_perfil_atual() = 'Administrador');

drop policy if exists rpa_usuarios_update on public.rpa_usuarios;
create policy rpa_usuarios_update
  on public.rpa_usuarios for update
  using (
    rpa_perfil_atual() = 'Administrador'
    or auth_uid = auth.uid()
  )
  with check (
    rpa_perfil_atual() = 'Administrador'
    or (auth_uid = auth.uid() and perfil = rpa_perfil_atual())
  );

drop policy if exists rpa_usuarios_delete on public.rpa_usuarios;
create policy rpa_usuarios_delete on public.rpa_usuarios for delete using (rpa_perfil_atual() = 'Administrador');

-- ---------------------------------------------------------------------------
-- rpa_chamados: já tinha uma boa regra de negócio pensada (dono vê o
-- próprio; Administrador/Gestor/Desenvolvedor veem e respondem todos) —
-- só estava usando "authenticated" genérico em vez de checar o perfil de
-- verdade. Troca pra usar rpa_perfil_atual().
-- ---------------------------------------------------------------------------
drop policy if exists rpa_chamados_select on public.rpa_chamados;
create policy rpa_chamados_select
  on public.rpa_chamados for select
  using (
    solicitante = rpa_username_atual()
    or rpa_perfil_atual() in ('Administrador', 'Gestor', 'Desenvolvedor')
  );

drop policy if exists rpa_chamados_insert on public.rpa_chamados;
create policy rpa_chamados_insert on public.rpa_chamados for insert with check (auth.role() = 'authenticated');

drop policy if exists rpa_chamados_update on public.rpa_chamados;
create policy rpa_chamados_update
  on public.rpa_chamados for update
  using (rpa_perfil_atual() in ('Administrador', 'Gestor', 'Desenvolvedor'))
  with check (rpa_perfil_atual() in ('Administrador', 'Gestor', 'Desenvolvedor'));

drop policy if exists rpa_chamados_delete on public.rpa_chamados;
create policy rpa_chamados_delete on public.rpa_chamados for delete using (rpa_perfil_atual() = 'Administrador');

-- ---------------------------------------------------------------------------
-- Achado #3: bucket de gravações de tela do Discovery deixa de ser público.
-- A partir de agora, a exibição precisa usar createSignedUrl() em vez de
-- link direto (o js/discovery.js já foi ajustado pra isso).
-- ---------------------------------------------------------------------------
update storage.buckets set public = false where id = 'discovery-gravacoes';

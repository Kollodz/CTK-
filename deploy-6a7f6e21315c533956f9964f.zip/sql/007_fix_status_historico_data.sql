-- ---------------------------------------------------------------------------
-- 007_fix_status_historico_data.sql
--
-- Corrige o erro:
--   POST .../rpa_status_historico 400 (Bad Request)
--   "Could not find the 'data' column of 'rpa_status_historico' in the
--   schema cache"
--
-- Causa raiz: js/storage.js (StatusHistory.log) grava um registro com o
-- campo "data" (data/hora do evento de mudança de status), mas a tabela
-- rpa_status_historico no Supabase nunca teve essa coluna criada — só
-- projeto_id, status_anterior, status_novo e usuario existiam. O restante
-- dos campos gravava normalmente; só "data" era rejeitado pelo PostgREST.
--
-- Basta adicionar a coluna. "if not exists" torna o script seguro para
-- rodar de novo sem erro caso a coluna já tenha sido criada manualmente.
-- ---------------------------------------------------------------------------
alter table public.rpa_status_historico
  add column if not exists data timestamptz not null default now();

-- Se o schema cache do PostgREST não atualizar sozinho (às vezes demora
-- alguns segundos), rode manualmente no SQL Editor do Supabase:
-- notify pgrst, 'reload schema';
notify pgrst, 'reload schema';
